plugins {
    id("com.android.application") version "8.13.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("dev.rikka.tools.refine") version "4.4.0" apply false
}
