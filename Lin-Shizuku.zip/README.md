# Lin-Shizuku

基于 Shizuku 13.5.4 与 Sui 的深度定制 Android 应用，使用 Jetpack Compose 构建现代化 UI。

## 版本信息

- **版本号**: 3.0.0-deepmod
- **版本代码**: 3000
- **包名**: `moe.shizuku.privileged.api`
- **最低 SDK**: Android 7.0 (API 24)
- **目标 SDK**: Android 14 (API 34)
- **编译 SDK**: Android 15 (API 35)

## 功能特性

### 核心功能
- **Shizuku 服务管理**: 启动/停止 Shizuku 服务，实时显示运行状态
- **多种启动方式**: 无线调试（免 Root）、ADB 连接电脑、本地 Shell、Root 启动
- **无线调试配对**: 内置 ADB 配对服务，支持 Android 11+ 无线调试配对
- **TCP 模式（脱离 WiFi 保持权限，thedjchi 特性）**: 无线调试成功启动一次后，自动将 adbd 切换到固定 TCP 端口（`adb tcpip`，默认 5555），之后即使关闭 WiFi / 无线调试，也可通过 127.0.0.1 本地回环停止/重启服务；设置中可开关并自定义端口
- **崩溃自动恢复（Watchdog）**: 服务进程异常退出后自动重新启动（Root 设备），首页状态轮询内置检测，用户手动停止 30 秒内不触发
- **增强开机自启**: Root 设备开机后延迟等待系统就绪，自动启动服务并重试 3 次（原版仅启动一次）
- **应用授权管理**: 管理所有应用的 Shizuku API 访问权限（允许/询问/拒绝）
- **特权终端**: Shizuku 运行时自动使用特权 Shell（adb/root 权限），否则回退本地 Shell
- **Shell 脚本模块**: 创建、编辑、执行 Shell 脚本，支持元数据和开关型脚本
- **Lin 模块系统**: 支持安装 ZIP/单文件模块，含 module.json 元数据解析

### 界面特性
- **首页真实功能适配（自 Shizuku 13.5.4 迁移）**: 状态卡片接入真实 Shizuku Binder（运行状态 / 服务版本 / 运行身份 root·shell·adb / SELinux 上下文），Binder 事件监听 + 3 秒轮询自动刷新；ROOT 启动卡片真实检测 su（迁移官方 `EnvironmentUtils.isRooted()`）、通过 `su -c` 执行启动脚本并流式回显终端输出、等待服务 Binder 就绪后自动刷新（迁移官方 `StarterActivity.startRoot()`）；服务运行于 root 时按钮切换为「重启」并显示 Sui 建议；停止按钮带确认对话框并调用 `Shizuku.exit()`；无线调试卡片「启动」按钮进入完整配对流程页；「已授权应用」数量实时统计（迁移官方 `AppsViewModel.grantedCount` 语义）。
- **无线调试配对流程（自 Stellar 迁移）**: 配对页由模拟步骤重写为 Stellar 式真实自动流程（迁移 `Stellar StarterViewModel` 无线分支 + `AdbWirelessHelper`）：检测 ADB 端口（系统端口 + mDNS 发现，15 秒超时）→ 检测配对状态（真实 ADB 握手探测）→ 未配对时引导开启无线调试 / 授权通知权限（Android 13+ 运行时请求）→ 启动 `AdbPairingService` 前台服务并在通知栏输入配对码 → 配对完成自动继续 → ADB 连接并执行启动脚本 → 按真实 shell 输出自动推进步骤（连接/验证/检查服务/启动进程）→ 等待 Binder 响应（监听 + 15 秒轮询）→ 启动完成 3 秒后自动返回；配对失败（SSL/连接异常）自动回到配对步骤重试，支持错误提示与重试、实时启动日志。
- **Jetpack Compose Material 3**: 现代化 Material You 设计
- **液态玻璃导航栏**: 底部导航栏采用玻璃拟态效果，选中项图标缩放动画 + 波纹反馈 + 触觉反馈
- **方向感知页面动画**: 子页面推入从右侧滑入（附带深度缩放 0.98），返回时向右滑出；Tab 切换使用淡入淡出 + 缩放；统一 FastOutSlowIn 缓动，时长 240–300ms 更顺滑
- **状态平滑过渡**: 首页运行状态文字与「停止」按钮使用 Crossfade / AnimatedVisibility 平滑切换，不再生硬跳变
- **返回栈管理**: 子页面支持多级返回，系统返回键逐级回退
- **二级页面过渡**: 脚本编辑/输出/浏览器页面使用自定义 Activity 切换动画
- **脉冲状态指示灯**: 首页服务状态指示灯带呼吸脉冲动画，运行时绿色脉冲，停止时红色
- **终端风格代码块**: 启动命令展示采用 macOS 风格终端窗口（红黄绿三色点 + 一键复制）
- **终端输出对话框**: 启动/诊断输出使用可滚动终端风格对话框，带加载指示器
- **图标容器**: 启动卡片图标使用圆角容器包裹，视觉层次更清晰
- **按压反馈统一**: 模块卡片所有操作按钮（执行/WebUI/删除/运行标签）统一按压缩放反馈
- **配对页主题适配**: 步骤指示器、警告卡片、日志卡片全面适配浅色/深色主题
- **终端视觉升级**: 终端窗口带标题栏（三色点 + shell 类型标识），输入框带 `$` 提示符
- **Stellar 风格配对流程**: 10 步垂直时间线（检测端口→配对状态→通知权限→无线配对→连接ADB→验证→检查服务→启动进程→Binder响应→启动完成），操作按钮嵌入对应步骤卡片，MIUI 警告内嵌配对步骤，启动日志卡片带一键复制
- **按压反馈**: 所有可点击卡片/设置项支持按压缩放 + 波纹效果
- **加载与空状态**: 统一的加载指示器、骨架屏和空状态提示组件
- **沉浸式系统栏**: 透明状态栏/导航栏，自动适配深浅色图标，Android 15 手势导航无对比边
- **动态颜色**: 支持 Android 12+ 壁纸动态取色
- **AMOLED 纯黑模式**: 夜间模式下可启用纯黑背景
- **多主题切换**: 跟随系统/总是开启/总是关闭/省电模式/夜晚时
- **多语言支持**: 简体中文、English、跟随系统
- **高刷新率**: 自动选择设备最高刷新率
- **隐藏后台**: 从最近任务列表中隐藏应用

### 设置选项
- 开机自动启动（Root）
- TCP 模式（脱离 WiFi 保持权限）+ 自定义 TCP 端口
- 崩溃自动恢复（Watchdog）
- 可信 WLAN 自动启动
- 电池优化白名单管理
- 外观主题定制
- 语言切换
- 隐私与性能设置

### Android 版本支持
- **minSdk 24（Android 7.0）~ targetSdk 35（Android 15）**
- **Android 17（API 37）兼容**: 本应用在 Android 17 设备上可正常运行（targetSdk 35 兼容模式）；未声明 `screenOrientation` / `resizeableActivity` 限制，不受 Android 17 大屏强制自适应影响；未使用明文流量，不受 `usesCleartextTraffic` 弃用计划影响。正式按 targetSdk 37 编译适配需升级 compileSdk 37（当前本地 SDK 仅至 android-35），已列入后续计划

## 项目结构

```
app/
├── build.gradle.kts              # 应用级构建配置
├── libs/
│   └── shizuku-server.jar        # Shizuku 服务端库
├── proguard-rules.pro            # 混淆规则
└── src/main/
    ├── AndroidManifest.xml        # 清单文件
    ├── assets/
    │   ├── rish                   # Rish 可执行文件
    │   └── rish_shizuku.dex      # Rish DEX
    ├── aidl/moe/shizuku/server/   # AIDL 接口定义
    │   ├── IRemoteProcess.aidl
    │   ├── IShizukuApplication.aidl
    │   ├── IShizukuService.aidl
    │   └── IShizukuServiceConnection.aidl
    ├── java/
    │   ├── moe/shizuku/
    │   │   ├── api/BinderContainer.java
    │   │   ├── manager/adb/        # ADB 协议实现
    │   │   │   ├── AdbClient.kt
    │   │   │   ├── AdbKey.kt
    │   │   │   ├── AdbMdns.kt
    │   │   │   ├── AdbMessage.kt
    │   │   │   ├── AdbPairingClient.kt
    │   │   │   ├── AdbPairingService.kt
    │   │   │   └── AdbProtocol.kt
    │   │   └── privileged/api/
    │   │       ├── MainActivity.kt           # 主 Activity
    │   │       ├── core/                      # 核心服务
    │   │       │   ├── BootReceiver.kt
    │   │       │   ├── EngineService.kt
    │   │       │   ├── LinShizukuProvider.kt
    │   │       │   ├── Prefs.kt
    │   │       │   ├── ShizukuApp.kt
    │   │       │   ├── ShizukuCompat.kt
    │   │       │   └── ShizukuManager.kt
    │   │       ├── data/                      # 数据模型
    │   │       ├── ui/                        # Compose UI
    │   │       │   ├── apps/AppsScreen.kt
    │   │       │   ├── auth/AuthAppsScreen.kt
    │   │       │   ├── battery/BatteryScreen.kt
    │   │       │   ├── browser/BrowserActivity.kt
    │   │       │   ├── home/HomeScreen.kt
    │   │       │   ├── modules/ModulesScreen.kt
    │   │       │   ├── pairing/PairingScreen.kt
    │   │       │   ├── settings/SettingsScreen.kt
    │   │       │   ├── terminal/TerminalScreen.kt
    │   │       │   ├── theme/Theme.kt
    │   │       │   └── widget/                # 自定义组件
    │   │       └── util/                      # 工具类
    │   └── rikka/
    │       ├── shizuku/                       # Shizuku 客户端 API
    │       ├── sui/Sui.java                   # Sui API
    │       └── core/                          # Rikka 核心工具
    ├── jniLibs/                               # 原生库（4 架构）
    │   ├── arm64-v8a/
    │   ├── armeabi-v7a/
    │   ├── x86/
    │   └── x86_64/
    └── res/                                   # 资源文件
build.gradle.kts                               # 项目级构建配置
settings.gradle.kts                            # 项目设置
gradle.properties                              # Gradle 属性
release.keystore                               # 签名密钥库
```

## 构建说明

### 环境要求
- JDK 17
- Android SDK (compileSdk 35, build-tools 34.0.0)
- Gradle 8.5

### 构建命令

```bash
# Debug 构建
./gradlew assembleDebug

# Release 构建（已配置签名）
./gradlew assembleRelease

# 清理
./gradlew clean
```

### 签名配置
Release 构建使用 `release.keystore` 签名：
- 别名: `shizuku-deepmod`
- 密码: `deepmod2026`

## 技术栈

- **语言**: Kotlin 1.9.22
- **UI 框架**: Jetpack Compose (Material 3)
- **构建系统**: Gradle 8.5 + AGP 8.2.2
- **最低支持**: Android 7.0 (API 24)
- **原生库**: libshizuku.so, libadb.so, librish.so, libtaskpropty.so
- **加密库**: Bouncy Castle, Conscrypt

## Shizuku 集成说明

本应用通过以下方式与 Shizuku 服务交互：

1. **Binder 接收**: 通过 `LinShizukuProvider`（继承自 `rikka.shizuku.ShizukuProvider`）接收 Shizuku 服务发送的 Binder
2. **API 调用**: 使用 `rikka.shizuku.Shizuku` 类进行 Binder 管理和权限检查
3. **特权执行**: 通过 `IShizukuService.newProcess()` AIDL 接口在 Shizuku 服务进程中执行 Shell 命令
4. **权限管理**: 通过 `getFlagsForUid` / `updateFlagsForUid` 管理应用的 Shizuku API 访问权限

## 本应用即 Shizuku 服务端（自托管架构）

本应用**本身就是 Shizuku 服务端**，而非单纯的客户端。其他 Shizuku 兼容应用
（使用官方 `dev.rikka.shizuku:api` 依赖）可直接连接本应用并请求权限：

| 组件 | 来源 | 作用 |
|---|---|---|
| `libs/shizuku-server.jar` | 官方 v13.5.4 server 编译产物 | `ShizukuService`（Binder 分发、权限校验、Shell 执行）、`ServiceStarter`、hidden API compat，共 141 个 class |
| `lib/<abi>/libshizuku.so` | 官方 native starter | PIE 可执行，被 `start.sh` 复制为 `/data/local/tmp/shizuku_starter` 后运行，拉起 `app_process` 加载服务 |
| `res/raw/start.sh` | 官方 v13.5.4 | ROOT/ADB 启动脚本（复制 starter → 执行 → 反馈状态） |
| `util/Starter.kt` | 官方移植 | 提取 starter 与 start.sh 到外部目录 |
| `core/LinShizukuProvider.kt` | 官方 `ShizukuProvider` 子类 | authorities=`moe.shizuku.privileged.api.shizuku`，向兼容应用分发 Binder |
| `aidl/moe/shizuku/server/*.aidl` | 官方 v13.5.4 | `IShizukuService` 等 AIDL 接口（getVersion/newProcess/updateFlagsForUid 等） |

启动链路：`Starter` 写文件 → ROOT（su）/ADB（无线配对）执行 `start.sh` →
`shizuku_starter`（native）→ `app_process` 运行 `moe.shizuku.starter.ServiceStarter`
→ fork 出 `shizuku_server`（`rikka.shizuku.server.ShizukuService`）→ 通过
`LinShizukuProvider` 向所有已授权应用分发 Binder。

**权限管理（可管理其他 Shizuku 兼容应用）**：

- 首页「已授权应用」：真实统计持有 API_V23 权限且被允许的应用数（`getAuthorizedCount`）
- 首页「管理应用」（AuthAppsScreen）：列出全部 Shizuku 兼容应用，双级筛选（已授权/未授权 × 运行/询问/拒绝），Switch 实时授予/撤销（`setAppPermission` → `IShizukuService.updateFlagsForUid`）
- 设置 →「应用授权管理」（AppsScreen）：服务运行状态提示 + 刷新 + 授权切换 + 操作反馈

## 参考资源

- Shizuku 官网: https://shizuku.rikka.app/zh-hans/
- Shizuku 源码: https://github.com/RikkaApps/Shizuku
- Sui 源码: https://github.com/RikkaApps/Sui
- RikkaApps: https://github.com/RikkaApps

## 许可证

本项目基于 Shizuku (MIT License) 衍生开发。

## Stellar 服务端合入（v3.0.0-deepmod 最新）

本版本已将 **Stellar 服务端（`roro.stellar.server.StellarService`，与官方 Stellar 同源码）完整合入 APK**，替换官方 `shizuku-server.jar` 作为实际运行的服务端，并配套替换 native 启动器：

### 启动链路（Stellar 直连）
- **启动命令**：`adb shell <nativeLibraryDir>/libstellar.so`（直接执行 APK 内的 libstellar.so，即 Stellar 官方指令形态）
- **libstellar.so**：用户提供的 Stellar starter（aarch64 可执行 ELF），已放入 `app/src/main/jniLibs/arm64-v8a/libstellar.so`；启动时自行从 APK 定位 base.apk 并以 `app_process` 加载 Stellar server（进程名 `stellar_server`）
- **Root 启动**：`su -c <nativeLibraryDir>/libstellar.so`
- **回退链路**：APK 内 so 不可达时回退 `sh /sdcard/start.sh`（仍提取 libstellar.so 到外部目录执行）
- **ADB 会话超时**：Stellar server 为常驻进程（exec 后不返回），`AdbClient` 的启动命令会话加 15 秒读超时（`SocketTimeoutException` 视为命令已发出），Binder 就绪由监听器判定

### 服务端实现（照抄 Stellar 源码）
- `app/src/main/java/roro/stellar/server/**`：StellarService、BinderDistributor、PermissionManager（细分权限系统）、UserServiceStarter、RemotePtyProcessHolder 等 55 个源文件
- `app/src/main/aidl/com/stellar/server/*.aidl`：Stellar 服务 AIDL 接口（6 个）
- 包名/进程名已从 `roro.stellar.manager` 全局替换为 `moe.shizuku.privileged.api`（ServerConstants / BinderDistributor / UserServiceStarter / Logger），授权弹窗 action 与 Manifest 注册的 `moe.shizuku.privileged.api.intent.action.REQUEST_PERMISSION` 一致
- 官方 `shizuku-server.jar` 已整体移除（其内置 hidden compat / parcelablelist 为旧版，会让 Stellar server 运行时 NoSuchMethodError 崩溃 → DeadObjectException）；依赖与 Stellar 官方构建一致：`dev.rikka.hidden:compat:4.4.0`（运行时）+ `stub:4.4.0`（仅编译期）+ `dev.rikka.tools.refine:runtime:4.4.0` + `dev.rikka.rikkax.parcelablelist:2.0.1` + gson；Rish 公开源码版保留在 `app/src/main/java/rikka/rish/`

### Stellar 生态 Provider（binder 通道修复）
- 新增 `moe.shizuku.privileged.api.stellar` provider（`roro.stellar.manager.StellarManagerProvider`，照抄官方 StellarManagerProvider 协议、去掉 Room 依赖）：Stellar server（app_process）启动后通过 `content://...stellar` 发送自身 Binder（sendBinder/getBinder/sendUserService）、读写配置（loadConfig/saveConfig 落 SharedPreferences）、上传日志
- 基类 `roro.stellar.StellarProvider` + `roro.stellar.Stellar` 单例（照抄 stellar-api）：收到 Binder 后**同时桥接给官方 `rikka.shizuku.Shizuku` 单例**，本 App 既有 UI（Shizuku.getBinder/pingBinder）立即生效
- 修复背景：此前 server 的 Binder 发不到 manager（无 `.stellar` provider），App 侧拿不到 Binder → `android.os.DeadObjectException`

### 启动成功判定（无线调试 / ADB 直连）
- starter 输出校验：包含「错误：/权限不足/SELinux」→ 判定失败并显示真实错误；包含「正常退出/进程号」→ 成功；有输出但无标志 → 提示等待 Binder
- 本地 shell 卡片已注明：直接执行 libstellar.so 必须 root 或 adb（uid 2000）身份，普通终端模拟器会权限不足

### 授权管理（与 Stellar 对齐）
- 服务端权限授予：询问/允许/拒绝（`setAppPermission` / `setAppPermissionAsk`），本地 `auth_state` 持久化，服务未运行时回退本地状态
- 授权请求弹窗：`RequestPermissionActivity`（始终允许/仅此一次/拒绝），经 `dispatchPermissionResult` 回复服务端
- 授权应用列表：展开式三选项（Shizuku 权限 · 询问/允许/拒绝），未激活时按清单过滤列出全部 Shizuku 兼容应用
