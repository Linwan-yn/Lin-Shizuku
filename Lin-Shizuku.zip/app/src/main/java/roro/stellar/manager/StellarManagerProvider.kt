package roro.stellar.manager

import android.content.Context
import android.os.Bundle
import com.google.gson.Gson
import roro.stellar.StellarProvider
import roro.stellar.server.StellarConfig

/**
 * Stellar 生态 provider（authority = ${applicationId}.stellar）。
 *
 * Stellar server（app_process 中运行）通过它：
 *  - 发送自身 Binder 给 manager（基类 StellarProvider 处理 sendBinder/getBinder/sendUserService，
 *    收到的 Binder 同时桥接给官方 rikka.shizuku.Shizuku 单例，本 App 既有 UI 立即生效）；
 *  - 读取/保存服务配置（loadConfig/saveConfig，持久化到 SharedPreferences）；
 *  - 上传/读取日志（saveLog/getLogs，内存保留最近 500 条）。
 *
 * 照抄官方 StellarManagerProvider 的协议，去掉 Room 依赖（配置/日志落 SharedPreferences）。
 */
class StellarManagerProvider : StellarProvider() {

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        when (method) {
            METHOD_GET_SHIZUKU_COMPAT -> {
                val value = prefs().getString(KEY_SHIZUKU_COMPAT, "true") ?: "true"
                return Bundle().apply { putBoolean(KEY_SHIZUKU_COMPAT, value.toBoolean()) }
            }
            METHOD_LOAD_CONFIG -> {
                val config = StellarConfig()
                prefs().all.forEach { (k, v) ->
                    val s = v.toString()
                    when (k) {
                        KEY_SHIZUKU_COMPAT -> config.shizukuCompatEnabled = s.toBoolean()
                        KEY_ACCESSIBILITY_AUTO_START -> config.accessibilityAutoStart = s.toBoolean()
                        KEY_DAEMON_ENABLED -> config.daemonEnabled = s.toBoolean()
                        KEY_PACKAGES_JSON -> runCatching {
                            config.packages = GSON.fromJson(
                                s, object : com.google.gson.reflect.TypeToken<MutableMap<Int, StellarConfig.PackageEntry>>() {}.type
                            ) ?: mutableMapOf()
                        }
                    }
                }
                return Bundle().apply { putString(KEY_CONFIG_JSON, GSON.toJson(config)) }
            }
            METHOD_SAVE_CONFIG -> {
                val json = extras?.getString(KEY_CONFIG_JSON) ?: return null
                val config = GSON.fromJson(json, StellarConfig::class.java) ?: return null
                prefs().edit()
                    .putString(KEY_SHIZUKU_COMPAT, config.shizukuCompatEnabled.toString())
                    .putString(KEY_ACCESSIBILITY_AUTO_START, config.accessibilityAutoStart.toString())
                    .putString(KEY_DAEMON_ENABLED, config.daemonEnabled.toString())
                    .putString(KEY_PACKAGES_JSON, GSON.toJson(config.packages))
                    .apply()
                return Bundle()
            }
            METHOD_SAVE_LOG -> {
                val line = arg ?: return null
                synchronized(logs) {
                    logs.addLast(line)
                    while (logs.size > 500) logs.removeFirst()
                }
                return Bundle()
            }
            METHOD_GET_LOGS -> {
                val lines: List<String> = synchronized(logs) { logs.toList() }
                return Bundle().apply { putStringArray(KEY_LOGS, lines.toTypedArray()) }
            }
            METHOD_CLEAR_LOGS -> {
                synchronized(logs) { logs.clear() }
                return Bundle()
            }
        }
        if (extras == null) return null
        return super.call(method, arg, extras)
    }

    private fun prefs(): android.content.SharedPreferences =
        context!!.getSharedPreferences("stellar_server", Context.MODE_PRIVATE)

    companion object {
        private val GSON = Gson()
        private val logs = java.util.ArrayDeque<String>()

        const val METHOD_GET_SHIZUKU_COMPAT = "getShizukuCompat"
        const val KEY_SHIZUKU_COMPAT = "shizukuCompat"
        const val KEY_ACCESSIBILITY_AUTO_START = "accessibilityAutoStart"
        const val KEY_DAEMON_ENABLED = "daemonEnabled"
        const val METHOD_LOAD_CONFIG = "loadConfig"
        const val METHOD_SAVE_CONFIG = "saveConfig"
        const val KEY_CONFIG_JSON = "configJson"
        const val KEY_PACKAGES_JSON = "packagesJson"
        const val METHOD_SAVE_LOG = "saveLog"
        const val METHOD_GET_LOGS = "getLogs"
        const val METHOD_CLEAR_LOGS = "clearLogs"
        const val KEY_LOGS = "logs"
    }
}
