package moe.shizuku.manager.adb

import android.annotation.TargetApi
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.RemoteInput
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.net.ConnectException

@TargetApi(Build.VERSION_CODES.R)
class AdbPairingService : Service() {

    companion object {
        const val notificationChannel = "adb_pairing"
        private const val tag = "AdbPairingService"
        private const val notificationId = 1
        private const val replyRequestId = 1
        private const val stopRequestId = 2
        private const val startAction = "start"
        private const val stopAction = "stop"
        private const val replyAction = "reply"
        private const val remoteInputResultKey = "paring_code"
        private const val portKey = "paring_code"

        fun startIntent(context: Context): Intent =
            Intent(context, AdbPairingService::class.java).setAction(startAction)

        private fun stopIntent(context: Context): Intent =
            Intent(context, AdbPairingService::class.java).setAction(stopAction)

        private fun replyIntent(context: Context, port: Int): Intent =
            Intent(context, AdbPairingService::class.java).setAction(replyAction).putExtra(portKey, port)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val port = MutableLiveData<Int>()
    private var adbMdns: AdbMdns? = null

    private val observer = Observer<Int> { port ->
        Log.i(tag, "Pairing service port: $port")
        val notification = createInputNotification(port)
        getSystemService(NotificationManager::class.java).notify(notificationId, notification)
    }

    private var started = false

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(
                notificationChannel, "ADB配对", NotificationManager.IMPORTANCE_HIGH
            ).apply {
                setSound(null, null)
                setShowBadge(false)
            }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = when (intent?.action) {
            startAction -> onStart()
            replyAction -> {
                val code = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(remoteInputResultKey) ?: ""
                val port = intent.getIntExtra(portKey, -1)
                if (port != -1) onInput(code.toString(), port) else onStart()
            }
            stopAction -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                null
            }
            else -> return START_NOT_STICKY
        }
        if (notification != null) {
            try {
                startForeground(notificationId, notification)
            } catch (e: Throwable) {
                Log.e(tag, "startForeground failed", e)
                getSystemService(NotificationManager::class.java).notify(notificationId, notification)
            }
        }
        return START_REDELIVER_INTENT
    }

    private fun startSearch() {
        if (started) return
        started = true
        adbMdns = AdbMdns(this, AdbMdns.TLS_PAIRING, port).apply { start() }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            port.observeForever(observer)
        } else {
            handler.post { port.observeForever(observer) }
        }
    }

    private fun stopSearch() {
        if (!started) return
        started = false
        adbMdns?.stop()
        if (Looper.myLooper() == Looper.getMainLooper()) {
            port.removeObserver(observer)
        } else {
            handler.post { port.removeObserver(observer) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSearch()
    }

    private fun onStart(): Notification {
        startSearch()
        return searchingNotification
    }

    private fun onInput(code: String, port: Int): Notification {
        GlobalScope.launch(Dispatchers.IO) {
            val host = "127.0.0.1"
            val key = try {
                val prefs = getSharedPreferences("adb_key", MODE_PRIVATE)
                AdbKey(PreferenceAdbKeyStore(prefs), "shizuku")
            } catch (e: Throwable) {
                e.printStackTrace()
                return@launch
            }
            AdbPairingClient(host, port, code, key).runCatching {
                start()
            }.onFailure { handleResult(false, it) }
                .onSuccess { handleResult(it, null) }
        }
        return workingNotification
    }

    private fun handleResult(success: Boolean, exception: Throwable?) {
        stopForeground(STOP_FOREGROUND_REMOVE)
        val title: String
        val text: String?
        if (success) {
            Log.i(tag, "Pair succeed")
            title = "配对成功"
            text = "返回应用点击启动"
            stopSearch()
        } else {
            title = "配对失败"
            text = when (exception) {
                is ConnectException -> "无法连接端口"
                is AdbInvalidPairingCodeException -> "配对码错误"
                is AdbKeyException -> "密钥存储错误"
                else -> exception?.let { Log.getStackTraceString(it) }
            }
            if (exception != null) Log.w(tag, "Pair failed", exception)
        }
        getSystemService(NotificationManager::class.java).notify(
            notificationId,
            Notification.Builder(this, notificationChannel)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(text)
                .build()
        )
    }

    private val stopNotificationAction: Notification.Action by lazy {
        val pendingIntent = PendingIntent.getService(
            this, stopRequestId, stopIntent(this),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_IMMUTABLE else 0
        )
        Notification.Action.Builder(null, "停止搜索", pendingIntent).build()
    }

    private val replyNotificationAction: Notification.Action by lazy {
        val remoteInput = RemoteInput.Builder(remoteInputResultKey)
            .setLabel("输入6位配对码")
            .build()
        val pendingIntent = PendingIntent.getForegroundService(
            this, replyRequestId, replyIntent(this, -1),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else PendingIntent.FLAG_UPDATE_CURRENT
        )
        Notification.Action.Builder(null, "输入配对码", pendingIntent)
            .addRemoteInput(remoteInput)
            .build()
    }

    private fun replyNotificationAction(port: Int): Notification.Action {
        val action = replyNotificationAction
        PendingIntent.getForegroundService(
            this, replyRequestId, replyIntent(this, port),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            else PendingIntent.FLAG_UPDATE_CURRENT
        )
        return action
    }

    private val searchingNotification: Notification by lazy {
        Notification.Builder(this, notificationChannel)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("正在搜索配对服务")
            .addAction(stopNotificationAction)
            .build()
    }

    private fun createInputNotification(port: Int): Notification {
        return Notification.Builder(this, notificationChannel)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("已找到配对服务")
            .setContentText("端口: $port")
            .addAction(replyNotificationAction(port))
            .build()
    }

    private val workingNotification: Notification by lazy {
        Notification.Builder(this, notificationChannel)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("正在配对...")
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
