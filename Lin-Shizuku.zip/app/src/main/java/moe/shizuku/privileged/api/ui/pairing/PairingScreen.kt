package moe.shizuku.privileged.api.ui.pairing

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PairingScreen(onBack: () -> Unit = {}) {
    val ctx = LocalContext.current
    val vm: PairingViewModel = viewModel(factory = viewModelFactory {
        initializer { PairingViewModel(ctx.applicationContext) }
    })
    val steps by vm.steps.collectAsState()
    val currentStepIndex by vm.currentStepIndex.collectAsState()
    val isCompleted by vm.isCompleted.collectAsState()
    val errorMessage by vm.errorMessage.collectAsState()
    val outputLines by vm.outputLines.collectAsState()
    val pairCode by vm.pairCode.collectAsState()
    val pairingNow by vm.pairingNow.collectAsState()
    val pairError by vm.pairError.collectAsState()
    var showLog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    // Auto-scroll to the current step.
    LaunchedEffect(currentStepIndex) {
        if (currentStepIndex > 0) {
            val target = (currentStepIndex * 140).coerceAtMost(scrollState.maxValue)
            scrollState.animateScrollTo(target)
        }
    }

    // Auto-close 3s after success (same as Stellar).
    LaunchedEffect(isCompleted) {
        if (isCompleted && errorMessage == null) {
            delay(3000)
            onBack()
        }
    }

    // Notification permission (needed for the pairing-code notification input).
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> vm.setNotificationPermission(granted) }

    val currentStep = steps.getOrNull(currentStepIndex)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("无线调试启动", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Status summary card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isCompleted) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
                            }
                        } else if (errorMessage != null) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE53935)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        } else {
                            CircularProgressIndicator(
                                modifier = Modifier.size(36.dp),
                                strokeWidth = 3.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                when {
                                    isCompleted -> "启动完成"
                                    errorMessage != null -> "启动失败"
                                    else -> "正在启动..."
                                },
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "步骤 ${(currentStepIndex + 1).coerceAtMost(steps.size)} / ${steps.size}",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    // Progress bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(
                                    if (steps.isEmpty()) 0f
                                    else (currentStepIndex + 1).coerceAtMost(steps.size).toFloat() / steps.size
                                )
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f))
                                    )
                                )
                        )
                    }
                    val errText = errorMessage
                    if (errText != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            errText,
                            fontSize = 13.sp,
                            color = Color(0xFFE53935),
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Timeline steps
            Column {
                steps.forEachIndexed { index, step ->
                    TimelineStepRow(
                        step = step,
                        isLast = index == steps.size - 1,
                        onGrantNotification = if (step.title == "授权通知权限" && step.status != StepStatus.COMPLETED) {
                            {
                                val granted = if (Build.VERSION.SDK_INT >= 33) {
                                    ctx.getSystemService(android.app.NotificationManager::class.java)
                                        .areNotificationsEnabled()
                                } else {
                                    true
                                }
                                if (granted) {
                                    vm.setNotificationPermission(true)
                                } else {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                        } else {
                            null
                        },
                        onOpenNotificationSettings = if (step.title == "授权通知权限") {
                            { openNotificationSettings(ctx) }
                        } else {
                            null
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // In-app pairing code input (shown when the pairing step needs action)
            val pairingStepActive = currentStep?.title == "无线调试配对" && currentStep.needsUserAction
            if (pairingStepActive) {
                PairingCodeCard(
                    pairCode = pairCode,
                    onCodeChange = { vm.setPairCode(it) },
                    pairingNow = pairingNow,
                    pairError = pairError,
                    onStartPairing = { vm.startPairingWithCode() }
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when {
                    errorMessage != null -> {
                        Button(
                            onClick = { vm.retry() },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) { Text("重试", fontSize = 14.sp) }
                    }
                    isCompleted -> {
                        Button(
                            onClick = onBack,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) { Text("完成", fontSize = 14.sp) }
                    }
                    currentStep?.needsUserAction == true -> {
                        when (currentStep.title) {
                            "开启无线调试" -> {
                                Button(
                                    onClick = { vm.continueAfterSetup() },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) { Text("已开启，继续", fontSize = 14.sp) }
                                OutlinedButton(
                                    onClick = { openDeveloperSettings(ctx) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("打开开发者选项", fontSize = 14.sp) }
                            }
                            "授权通知权限" -> {
                                Button(
                                    onClick = {
                                        // Re-check the real state first: the user may have enabled
                                        // notifications in system settings while the flow was paused.
                                        val granted = if (Build.VERSION.SDK_INT >= 33) {
                                            ctx.getSystemService(android.app.NotificationManager::class.java)
                                                .areNotificationsEnabled()
                                        } else {
                                            true
                                        }
                                        if (granted) {
                                            vm.setNotificationPermission(true)
                                        } else {
                                            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) { Text("授予权限", fontSize = 14.sp) }
                                OutlinedButton(
                                    onClick = { openNotificationSettings(ctx) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("打开通知设置", fontSize = 14.sp) }
                            }
                            "无线调试配对" -> {
                                Button(
                                    onClick = { vm.continueAfterSetup() },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) { Text("配对完成，继续", fontSize = 14.sp) }
                            }
                            else -> {}
                        }
                    }
                }
                if (!isCompleted) {
                    OutlinedButton(
                        onClick = { showLog = !showLog },
                        modifier = Modifier.weight(0.8f)
                    ) { Text(if (showLog) "隐藏日志" else "日志", fontSize = 14.sp) }
                }
            }

            // Startup log (real output from the flow)
            AnimatedVisibility(visible = showLog) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A24))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            "启动日志",
                            color = Color(0xFF8888AA),
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            outputLines.joinToString("\n").ifEmpty { "等待日志输出..." },
                            color = Color(0xFFB8C0D0),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TimelineStepRow(
    step: PairingStep,
    isLast: Boolean,
    onGrantNotification: (() -> Unit)? = null,
    onOpenNotificationSettings: (() -> Unit)? = null
) {
    val (bgColor, contentColor, borderColor) = when (step.status) {
        StepStatus.COMPLETED -> Triple(
            MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
        )
        StepStatus.RUNNING -> Triple(
            MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.primary
        )
        StepStatus.ERROR -> Triple(
            Color(0xFFE53935).copy(alpha = 0.15f),
            Color(0xFFE53935),
            Color(0xFFE53935).copy(alpha = 0.4f)
        )
        StepStatus.WARNING -> Triple(
            Color(0xFFFB8C00).copy(alpha = 0.15f),
            Color(0xFFFB8C00),
            Color(0xFFFB8C00).copy(alpha = 0.4f)
        )
        StepStatus.PENDING -> Triple(
            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            Color.Transparent
        )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        // Icon + connector
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(44.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(bgColor)
                    .border(
                        width = if (step.status == StepStatus.RUNNING) 1.5.dp else 0.dp,
                        color = borderColor,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                when (step.status) {
                    StepStatus.COMPLETED -> Icon(Icons.Default.Check, null, tint = contentColor, modifier = Modifier.size(18.dp))
                    StepStatus.RUNNING -> CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = contentColor
                    )
                    else -> Icon(step.icon, null, tint = contentColor, modifier = Modifier.size(18.dp))
                }
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(40.dp)
                        .background(
                            if (step.status == StepStatus.COMPLETED)
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                            else
                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f)
                        )
                )
            }
        }

        // Content card
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp, bottom = if (isLast) 0.dp else 8.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(bgColor)
                .then(
                    if (step.needsUserAction)
                        Modifier.border(1.dp, contentColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    else Modifier
                )
                .padding(12.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        step.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (step.status == StepStatus.PENDING)
                            MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        else
                            MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        when (step.status) {
                            StepStatus.COMPLETED -> "完成"
                            StepStatus.RUNNING -> "进行中"
                            StepStatus.ERROR -> "错误"
                            StepStatus.WARNING -> "注意"
                            StepStatus.PENDING -> "等待"
                        },
                        fontSize = 11.sp,
                        color = contentColor,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    step.description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    lineHeight = 16.sp
                )
                if (step.needsUserAction) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "需要您操作",
                        fontSize = 11.sp,
                        color = contentColor,
                        fontWeight = FontWeight.Medium
                    )
                }
                // Inline action buttons inside the step card, so the grant action is
                // always visible even when the bottom action area is showing another step.
                if (onGrantNotification != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onGrantNotification?.invoke() },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 6.dp, horizontal = 12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) { Text("授予权限", fontSize = 13.sp) }
                        OutlinedButton(
                            onClick = { onOpenNotificationSettings?.invoke() },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 6.dp, horizontal = 12.dp)
                        ) { Text("打开通知设置", fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun PairingCodeCard(
    pairCode: String,
    onCodeChange: (String) -> Unit,
    pairingNow: Boolean,
    pairError: String?,
    onStartPairing: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.QrCodeScanner,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("在此输入配对码", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                "在「无线调试」页面点击「使用配对码配对设备」后，将显示的 6 位配对码输入下方，即可直接完成配对（无需通知中心输入）。",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 17.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = pairCode,
                onValueChange = { input ->
                    if (input.length <= 6 && input.all { it.isDigit() }) {
                        onCodeChange(input)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("六位数字配对码") },
                singleLine = true,
                enabled = !pairingNow,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                shape = RoundedCornerShape(12.dp)
            )
            if (pairError != null) {
                val errText = pairError
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    errText,
                    fontSize = 12.sp,
                    color = Color(0xFFE53935),
                    lineHeight = 16.sp
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onStartPairing,
                modifier = Modifier.fillMaxWidth(),
                enabled = pairCode.length == 6 && !pairingNow,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                if (pairingNow) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("正在配对...", fontSize = 14.sp)
                } else {
                    Text("开始配对", fontSize = 14.sp)
                }
            }
        }
    }
}

/** Open the system notification settings for this app (fallback on MIUI/HyperOS where
 *  the runtime POST_NOTIFICATIONS dialog may not appear). */
private fun openNotificationSettings(context: android.content.Context) {
    try {
        val intent = android.content.Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
        context.startActivity(intent)
    } catch (_: Throwable) {
        try {
            val intent = android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(android.net.Uri.parse("package:${context.packageName}"))
            context.startActivity(intent)
        } catch (_: Throwable) {
        }
    }
}

/** Open the system developer options page. */
private fun openDeveloperSettings(context: android.content.Context) {
    try {
        context.startActivity(
            android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
        )
    } catch (_: Throwable) {
    }
}
