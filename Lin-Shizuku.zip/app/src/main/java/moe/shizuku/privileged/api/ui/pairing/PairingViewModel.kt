package moe.shizuku.privileged.api.ui.pairing

import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import moe.shizuku.manager.adb.AdbInvalidPairingCodeException
import moe.shizuku.manager.adb.AdbKey
import moe.shizuku.manager.adb.AdbMdns
import moe.shizuku.manager.adb.AdbPairingClient
import moe.shizuku.manager.adb.AdbPairingService
import moe.shizuku.manager.adb.PreferenceAdbKeyStore
import moe.shizuku.privileged.api.core.Prefs
import moe.shizuku.privileged.api.util.AdbWirelessHelper
import moe.shizuku.privileged.api.util.EnvironmentUtils
import rikka.shizuku.Shizuku
import java.io.EOFException
import java.net.ConnectException
import java.net.SocketTimeoutException
import javax.net.ssl.SSLException
import kotlin.time.Duration.Companion.milliseconds

enum class StepStatus { PENDING, RUNNING, COMPLETED, ERROR, WARNING }

data class PairingStep(
    val title: String,
    val icon: ImageVector,
    val status: StepStatus = StepStatus.PENDING,
    val description: String = "",
    val needsUserAction: Boolean = false
)

/**
 * Wireless-debugging pairing & startup flow, migrated from Stellar `StarterViewModel`
 * (wireless branch). Steps advance automatically from real ADB / mDNS / shell output;
 * user actions (enable wireless debugging, grant notification permission, finish
 * pairing) are surfaced as [PairingStep.needsUserAction] and resumed via
 * [continueAfterSetup].
 */
class PairingViewModel(private val context: Context) : ViewModel() {

    private val _steps = MutableStateFlow<List<PairingStep>>(emptyList())
    val steps: StateFlow<List<PairingStep>> = _steps.asStateFlow()

    private val _currentStepIndex = MutableStateFlow(0)
    val currentStepIndex: StateFlow<Int> = _currentStepIndex.asStateFlow()

    private val _isCompleted = MutableStateFlow(false)
    val isCompleted: StateFlow<Boolean> = _isCompleted.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _outputLines = MutableStateFlow<List<String>>(emptyList())
    val outputLines: StateFlow<List<String>> = _outputLines.asStateFlow()

    private val _pairCode = MutableStateFlow("")
    val pairCode: StateFlow<String> = _pairCode.asStateFlow()

    private val _pairingNow = MutableStateFlow(false)
    val pairingNow: StateFlow<Boolean> = _pairingNow.asStateFlow()

    private val _pairError = MutableStateFlow<String?>(null)
    val pairError: StateFlow<String?> = _pairError.asStateFlow()

    private val helper = AdbWirelessHelper()
    private var adbMdns: AdbMdns? = null
    private var detectedPort = 0

    private var hasNotificationPermission = context.getSystemService(
        android.app.NotificationManager::class.java
    ).areNotificationsEnabled()

    private enum class PairingPhase { NONE, ENABLE_WIRELESS, PAIRING }
    private var pairingPhase = PairingPhase.NONE

    init {
        initializeSteps()
        startProcess()
    }

    // ---------- steps ----------

    private fun step(title: String, icon: ImageVector, desc: String) =
        PairingStep(title, icon, StepStatus.PENDING, desc)

    private fun initializeSteps() {
        // 「授权通知权限」「无线调试配对」不预置：仅当未配对时由 showPairingSteps()
        // 动态插入，避免已配对自动启动时残留"等待"步骤且按钮区空白。
        _steps.value = listOf(
            step("检测 ADB 端口", Icons.Filled.Wifi, "正在检测可用的 ADB 端口..."),
            step("检测配对状态", Icons.Filled.Key, "等待检测"),
            step("连接 ADB 服务", Icons.Filled.SettingsEthernet, "等待连接"),
            step("验证连接状态", Icons.Filled.Verified, "等待验证"),
            step("检查现有服务", Icons.Filled.Search, "等待执行"),
            step("启动服务进程", Icons.Filled.RocketLaunch, "等待执行"),
            step("等待 Binder 响应", Icons.Filled.Refresh, "等待执行"),
            step("启动完成", Icons.Filled.Check, "等待完成")
        )
        _currentStepIndex.value = 0
    }

    private fun updateStep(index: Int, status: StepStatus, description: String, needsUserAction: Boolean = false) {
        viewModelScope.launch {
            if (status == StepStatus.RUNNING || status == StepStatus.COMPLETED) {
                delay(300.milliseconds)
            }
            val currentSteps = _steps.value.toMutableList()
            if (index in currentSteps.indices) {
                currentSteps[index] = currentSteps[index].copy(
                    status = status,
                    description = description,
                    needsUserAction = needsUserAction
                )
                _steps.value = currentSteps
                if (status == StepStatus.RUNNING) {
                    _currentStepIndex.value = index
                }
            }
        }
    }

    private fun insertStep(afterIndex: Int, newStep: PairingStep) {
        val currentSteps = _steps.value.toMutableList()
        if (afterIndex in -1 until currentSteps.size) {
            currentSteps.add(afterIndex + 1, newStep)
            _steps.value = currentSteps
        }
    }

    private fun addOutputLine(line: String) {
        viewModelScope.launch { _outputLines.value += line }
    }

    // ---------- entry ----------

    private fun startProcess() = startDetection()

    private fun setSuccess() {
        viewModelScope.launch {
            val steps = _steps.value
            val lastIndex = steps.lastIndex
            steps.forEachIndexed { index, s ->
                if (s.status != StepStatus.COMPLETED && s.status != StepStatus.WARNING) {
                    updateStep(
                        index,
                        StepStatus.COMPLETED,
                        if (index == lastIndex) "Shizuku 服务已成功启动" else "完成"
                    )
                }
            }
            _isCompleted.value = true
        }
    }

    private fun setError(error: Throwable, stepIndex: Int) {
        viewModelScope.launch {
            updateStep(stepIndex, StepStatus.ERROR, error.message ?: "执行失败")
            _errorMessage.value = error.message ?: "未知错误"
        }
    }

    // ---------- step 1-2: detect port & pairing status ----------

    private fun startDetection() {
        viewModelScope.launch(Dispatchers.IO) {
            launch(Dispatchers.Main) {
                updateStep(0, StepStatus.RUNNING, "正在检测可用的 ADB 端口...")
            }

            val systemPort = EnvironmentUtils.getAdbTcpPort()
            if (systemPort in 1..65535) {
                val canConnect = helper.hasAdbPermission(context, "127.0.0.1", systemPort)
                if (canConnect) {
                    detectedPort = systemPort
                    launch(Dispatchers.Main) {
                        updateStep(0, StepStatus.COMPLETED, "端口可用: $systemPort")
                        updateStep(1, StepStatus.COMPLETED, "已配对")
                        insertNotificationStep()
                        delay(300.milliseconds)
                        startAdbSteps()
                    }
                    return@launch
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                launch(Dispatchers.Main) { startMdnsDetection() }
            } else {
                launch(Dispatchers.Main) {
                    updateStep(0, StepStatus.WARNING, "未检测到端口")
                    showEnableWirelessAdbStep()
                }
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun startMdnsDetection() {
        var handled = false
        val portData = MutableLiveData<Int>()
        var observer: Observer<Int>? = null
        observer = Observer<Int> { discovered ->
            if (discovered in 1..65535 && !handled) {
                handled = true
                adbMdns?.stop()
                adbMdns = null
                observer?.let { portData.removeObserver(it) }

                viewModelScope.launch(Dispatchers.IO) {
                    val canConnect = helper.hasAdbPermission(context, "127.0.0.1", discovered)
                    launch(Dispatchers.Main) {
                        updateStep(0, StepStatus.COMPLETED, "端口可用: $discovered")
                        detectedPort = discovered
                        if (canConnect) {
                            updateStep(1, StepStatus.COMPLETED, "已配对")
                            insertNotificationStep()
                            delay(300.milliseconds)
                            startAdbSteps()
                        } else {
                            updateStep(1, StepStatus.WARNING, "需要配对")
                            delay(300.milliseconds)
                            showPairingSteps()
                        }
                    }
                }
            }
        }
        portData.observeForever(observer)

        adbMdns = AdbMdns(context, AdbMdns.TLS_CONNECT, portData).apply { start() }

        // Timeout: no service discovered → guide the user to enable wireless debugging.
        viewModelScope.launch {
            delay(15_000L)
            if (!handled) {
                handled = true
                adbMdns?.stop()
                adbMdns = null
                observer?.let { portData.removeObserver(it) }
                updateStep(0, StepStatus.WARNING, "未检测到端口")
                showEnableWirelessAdbStep()
            }
        }
    }

    // ---------- user action: enable wireless debugging ----------

    private fun showEnableWirelessAdbStep() {
        pairingPhase = PairingPhase.ENABLE_WIRELESS
        insertStep(
            0,
            PairingStep(
                title = "开启无线调试",
                icon = Icons.Filled.WifiOff,
                status = StepStatus.RUNNING,
                description = "请打开 设置 → 开发者选项 → 无线调试，开启后返回本页点击「继续」",
                needsUserAction = true
            )
        )
        _currentStepIndex.value = 1
    }

    // ---------- pairing ----------

    /**
     * 已配对自动启动时也显示「授权通知权限」步骤（非阻塞）：
     * 权限已授予 → 完成；未授予 → 黄色提示，不阻断启动。
     */
    private fun insertNotificationStep() {
        if (_steps.value.any { it.title == "授权通知权限" }) return
        val hasPermission = hasNotificationPermission
        insertStep(
            1,
            PairingStep(
                title = "授权通知权限",
                icon = Icons.Filled.Notifications,
                status = if (hasPermission) StepStatus.COMPLETED else StepStatus.WARNING,
                description = if (hasPermission) "通知权限已授予" else "通知权限未授予，可稍后在系统设置中开启",
                needsUserAction = false
            )
        )
    }

    private fun showPairingSteps() {
        pairingPhase = PairingPhase.PAIRING
        val hasPermission = hasNotificationPermission

        insertStep(
            1,
            PairingStep(
                title = "授权通知权限",
                icon = Icons.Filled.Notifications,
                status = if (hasPermission) StepStatus.COMPLETED else StepStatus.RUNNING,
                description = if (hasPermission) "通知权限已授予" else "需要通知权限，用于在通知栏输入配对码",
                needsUserAction = !hasPermission
            )
        )
        insertStep(
            2,
            PairingStep(
                title = "无线调试配对",
                icon = Icons.Filled.QrCodeScanner,
                status = if (hasPermission) StepStatus.RUNNING else StepStatus.PENDING,
                description = "在无线调试页面点击「使用配对码配对设备」，然后在通知中心输入配对码",
                needsUserAction = hasPermission
            )
        )
        // 插入后: 授权通知权限=index 2, 无线调试配对=index 3
        _currentStepIndex.value = if (hasPermission) 3 else 2

        if (hasPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startPairingService()
        }
    }

    fun setNotificationPermission(granted: Boolean) {
        hasNotificationPermission = granted
        if (granted) {
            val currentSteps = _steps.value
            val notificationIndex = currentSteps.indexOfFirst { it.title == "授权通知权限" }
            if (notificationIndex >= 0) {
                updateStep(notificationIndex, StepStatus.COMPLETED, "通知权限已授予")
                val pairingIndex = currentSteps.indexOfFirst { it.title == "无线调试配对" }
                if (pairingIndex >= 0) {
                    updateStep(
                        pairingIndex,
                        StepStatus.RUNNING,
                        "在无线调试页面点击「使用配对码配对设备」，然后在通知中心输入配对码",
                        needsUserAction = true
                    )
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startPairingService()
            }
        } else {
            // Permission dialog denied (or never shown, e.g. on MIUI). Keep the step
            // active and tell the user to enable notifications manually.
            val currentSteps = _steps.value
            val notificationIndex = currentSteps.indexOfFirst { it.title == "授权通知权限" }
            if (notificationIndex >= 0) {
                updateStep(
                    notificationIndex,
                    StepStatus.WARNING,
                    "未获得通知权限，请在系统「通知」设置中允许本应用通知（或点击「打开通知设置」手动开启）",
                    needsUserAction = true
                )
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun startPairingService() {
        val intent = AdbPairingService.startIntent(context)
        try {
            context.startForegroundService(intent)
        } catch (_: Throwable) {
            // foreground service may be blocked by the system; pairing UI still works
        }
    }

    /** Resume after the user finished the current action (enable / pair). */
    fun continueAfterSetup() {
        viewModelScope.launch {
            when (pairingPhase) {
                PairingPhase.ENABLE_WIRELESS -> {
                    _outputLines.value = emptyList()
                    _errorMessage.value = null
                    pairingPhase = PairingPhase.NONE
                    initializeSteps()
                    delay(300.milliseconds)
                    startProcess()
                }
                PairingPhase.PAIRING -> {
                    if (detectedPort > 0) {
                        _outputLines.value = emptyList()
                        _errorMessage.value = null
                        val currentSteps = _steps.value
                        val pairingIndex = currentSteps.indexOfFirst { it.title == "无线调试配对" }
                        if (pairingIndex >= 0) {
                            updateStep(pairingIndex, StepStatus.COMPLETED, "配对完成")
                        }
                        pairingPhase = PairingPhase.NONE
                        delay(300.milliseconds)
                        startAdbSteps()
                    } else {
                        _outputLines.value = emptyList()
                        _errorMessage.value = null
                        pairingPhase = PairingPhase.NONE
                        initializeSteps()
                        delay(300.milliseconds)
                        startProcess()
                    }
                }
                PairingPhase.NONE -> {
                    _outputLines.value = emptyList()
                    _errorMessage.value = null
                    initializeSteps()
                    delay(300.milliseconds)
                    startProcess()
                }
            }
        }
    }

    // ---------- in-app pairing code input ----------

    fun setPairCode(code: String) {
        _pairCode.value = code
        if (code.length == 6) {
            _pairError.value = null
        }
    }

    /**
     * Pair directly from the in-app pairing code input (no notification input
     * needed — important on MIUI / HyperOS where the notification input may be
     * blocked). Discovers the pairing port via mDNS, then runs [AdbPairingClient].
     * On success the flow advances automatically to the ADB start steps.
     */
    fun startPairingWithCode() {
        val code = _pairCode.value.trim()
        if (code.length != 6 || !code.all { it.isDigit() }) {
            _pairError.value = "请输入 6 位数字配对码"
            return
        }
        if (_pairingNow.value) return
        viewModelScope.launch {
            _pairingNow.value = true
            _pairError.value = null
            addOutputLine("正在搜索配对服务...")

            val pairingPort = discoverPairingPort()
            if (pairingPort <= 0) {
                _pairingNow.value = false
                _pairError.value = "未找到配对服务，请先在「无线调试」页面点击「使用配对码配对设备」"
                return@launch
            }
            addOutputLine("配对服务端口: $pairingPort")

            val key = AdbKey(
                PreferenceAdbKeyStore(context.getSharedPreferences("adb_key", Context.MODE_PRIVATE)),
                "shizuku"
            )
            val result = withContext(Dispatchers.IO) {
                try {
                    AdbPairingClient("127.0.0.1", pairingPort, code, key).use { it.start() }
                    null
                } catch (e: AdbInvalidPairingCodeException) {
                    "配对码错误，请重新输入"
                } catch (e: Throwable) {
                    "配对失败：${e.message ?: e.javaClass.simpleName}"
                }
            }
            _pairingNow.value = false

            if (result == null) {
                addOutputLine("配对成功")
                _pairError.value = null
                _pairCode.value = ""
                continueAfterSetup()
            } else {
                addOutputLine("错误：$result")
                _pairError.value = result
            }
        }
    }

    /** Discover the ADB pairing port (mDNS `_adb-tls-pairing`), 10s timeout. */
    private suspend fun discoverPairingPort(): Int = withContext(Dispatchers.Main) {
        val deferred = CompletableDeferred<Int>()
        val portData = MutableLiveData<Int>()
        var observer: Observer<Int>? = null
        observer = Observer<Int> { discovered ->
            if (discovered in 1..65535 && !deferred.isCompleted) {
                deferred.complete(discovered)
            }
        }
        portData.observeForever(observer)
        val mdns = AdbMdns(context, AdbMdns.TLS_PAIRING, portData)
        mdns.start()

        // Timeout
        val timeoutJob = launch {
            delay(10_000L)
            if (!deferred.isCompleted) {
                deferred.complete(-1)
            }
        }

        val port = deferred.await()
        timeoutJob.cancel()
        mdns.stop()
        portData.removeObserver(observer)
        port
    }

    // ---------- connect & start ----------

    private fun startAdbSteps() {
        val connectIndex = _steps.value.indexOfFirst { it.title == "连接 ADB 服务" }
        if (connectIndex >= 0) {
            updateStep(connectIndex, StepStatus.RUNNING, "正在连接...")
        }
        startAdbConnection("127.0.0.1", detectedPort)
    }

    private fun startAdbConnection(host: String, port: Int) {
        addOutputLine("Connecting to $host:$port...")
        val tcpMode = Prefs.tcpMode
        val tcpPort = Prefs.tcpPort
        helper.startShizukuViaAdb(
            ctx = context,
            host = host,
            port = port,
            coroutineScope = viewModelScope,
            onOutput = { output ->
                addOutputLine(output)
                handleOutput(output)
            },
            onError = { error -> handleConnectError(error) },
            onSuccess = { handleConnectSuccess() },
            tcpMode = tcpMode,
            tcpPort = tcpPort
        )
    }

    private fun handleOutput(output: String) {
        viewModelScope.launch(Dispatchers.Main) {
            val steps = _steps.value
            val connectIndex = steps.indexOfFirst { it.title == "连接 ADB 服务" }
            val verifyIndex = steps.indexOfFirst { it.title == "验证连接状态" }
            val checkIndex = steps.indexOfFirst { it.title == "检查现有服务" }
            val startIndex = steps.indexOfFirst { it.title == "启动服务进程" }
            val binderIndex = steps.indexOfFirst { it.title == "等待 Binder 响应" }

            when {
                output.contains("检查权限: ADB") || output.contains("检查权限: Root")
                    || output.contains("info: start.sh begin") || output.contains("connected") -> {
                    if (connectIndex >= 0 && steps[connectIndex].status != StepStatus.COMPLETED) {
                        updateStep(connectIndex, StepStatus.COMPLETED, "连接成功")
                    }
                    if (verifyIndex >= 0 && steps[verifyIndex].status != StepStatus.COMPLETED) {
                        updateStep(verifyIndex, StepStatus.COMPLETED, "验证通过")
                    }
                }
                output.contains("info: attempt to copy") || output.contains("info: exec")
                    || output.contains("检查现有服务") || output.contains("未发现现有服务")
                    || output.contains("终止现有服务") -> {
                    if (connectIndex >= 0 && steps[connectIndex].status != StepStatus.COMPLETED) {
                        updateStep(connectIndex, StepStatus.COMPLETED, "连接成功")
                    }
                    if (verifyIndex >= 0 && steps[verifyIndex].status != StepStatus.COMPLETED) {
                        updateStep(verifyIndex, StepStatus.COMPLETED, "验证通过")
                    }
                    if (checkIndex >= 0 && steps[checkIndex].status != StepStatus.COMPLETED) {
                        updateStep(checkIndex, StepStatus.COMPLETED, "完成")
                    }
                    if (startIndex >= 0 && steps[startIndex].status != StepStatus.RUNNING) {
                        updateStep(startIndex, StepStatus.RUNNING, "正在启动...")
                    }
                }
                output.contains("启动服务进程") -> {
                    if (startIndex >= 0 && steps[startIndex].status != StepStatus.RUNNING) {
                        updateStep(startIndex, StepStatus.RUNNING, "正在启动...")
                    }
                }
                output.contains("shizuku_starter exit with 0") || output.contains("stellar_starter 正常退出")
                    || output.contains("正常退出（退出码 0）") -> {
                    if (startIndex >= 0 && steps[startIndex].status != StepStatus.COMPLETED) {
                        updateStep(startIndex, StepStatus.COMPLETED, "完成")
                    }
                    if (binderIndex >= 0 &&
                        steps[binderIndex].status != StepStatus.RUNNING &&
                        steps[binderIndex].status != StepStatus.COMPLETED
                    ) {
                        updateStep(binderIndex, StepStatus.RUNNING, "等待响应")
                        waitForService()
                    }
                }
            }

            output.lines().forEach { line ->
                val trimmed = line.trim()
                if (trimmed.startsWith("错误：")) {
                    setError(Exception(trimmed.substringAfter("错误：").trim()), _currentStepIndex.value)
                }
            }
        }
    }

    private fun handleConnectSuccess() {
        viewModelScope.launch(Dispatchers.Main) {
            val steps = _steps.value
            val connectIndex = steps.indexOfFirst { it.title == "连接 ADB 服务" }
            val verifyIndex = steps.indexOfFirst { it.title == "验证连接状态" }
            val checkIndex = steps.indexOfFirst { it.title == "检查现有服务" }
            val startIndex = steps.indexOfFirst { it.title == "启动服务进程" }
            val binderIndex = steps.indexOfFirst { it.title == "等待 Binder 响应" }

            if (connectIndex >= 0 && steps[connectIndex].status != StepStatus.COMPLETED) {
                updateStep(connectIndex, StepStatus.COMPLETED, "连接成功")
            }
            if (verifyIndex >= 0 && steps[verifyIndex].status != StepStatus.COMPLETED) {
                updateStep(verifyIndex, StepStatus.COMPLETED, "验证通过")
            }
            if (checkIndex >= 0 && steps[checkIndex].status != StepStatus.COMPLETED) {
                updateStep(checkIndex, StepStatus.COMPLETED, "完成")
            }
            if (startIndex >= 0 && steps[startIndex].status != StepStatus.COMPLETED) {
                updateStep(startIndex, StepStatus.COMPLETED, "完成")
            }
            if (binderIndex >= 0 &&
                steps[binderIndex].status != StepStatus.RUNNING &&
                steps[binderIndex].status != StepStatus.COMPLETED
            ) {
                updateStep(binderIndex, StepStatus.RUNNING, "等待响应")
                waitForService()
            }
        }
    }

    private fun handleConnectError(error: Throwable) {
        if (_isCompleted.value) return
        addOutputLine("错误：${error.message}")
        viewModelScope.launch(Dispatchers.Main) {
            val needsPairing = error is SSLException ||
                error is ConnectException ||
                error is SocketTimeoutException ||
                error is EOFException
            if (needsPairing) {
                val pairingIndex = _steps.value.indexOfFirst { it.title == "无线调试配对" }
                if (pairingIndex >= 0) {
                    pairingPhase = PairingPhase.PAIRING
                    updateStep(pairingIndex, StepStatus.ERROR, "配对失败或已失效，请重新配对", needsUserAction = true)
                    _errorMessage.value = null
                } else {
                    val connectIndex = _steps.value.indexOfFirst { it.title == "连接 ADB 服务" }
                    setError(
                        Exception("需要先配对才能连接"),
                        if (connectIndex >= 0) connectIndex else _currentStepIndex.value
                    )
                }
            } else {
                val connectIndex = _steps.value.indexOfFirst { it.title == "连接 ADB 服务" }
                setError(error, if (connectIndex >= 0) connectIndex else _currentStepIndex.value)
            }
        }
    }

    // ---------- wait for binder ----------

    private fun waitForService() {
        viewModelScope.launch {
            var binderReceived = false
            val listener = object : Shizuku.OnBinderReceivedListener {
                override fun onBinderReceived() {
                    if (!binderReceived) {
                        binderReceived = true
                        Shizuku.removeBinderReceivedListener(this)
                        setSuccess()
                    }
                }
            }
            Shizuku.addBinderReceivedListener(listener)

            if (moe.shizuku.privileged.api.core.ShizukuManager.isRunningCompat()) {
                binderReceived = true
                Shizuku.removeBinderReceivedListener(listener)
                setSuccess()
                return@launch
            }

            val maxWaitTime = 15_000L
            val checkInterval = 300L
            var elapsed = 0L
            while (elapsed < maxWaitTime && !binderReceived) {
                delay(checkInterval.milliseconds)
                elapsed += checkInterval

                if (!binderReceived && moe.shizuku.privileged.api.core.ShizukuManager.isRunningCompat()) {
                    binderReceived = true
                    Shizuku.removeBinderReceivedListener(listener)
                    setSuccess()
                    return@launch
                }

                if (hasErrorInOutput()) {
                    Shizuku.removeBinderReceivedListener(listener)
                    setError(Exception(getLastErrorMessage()), 8)
                    return@launch
                }
            }

            if (!binderReceived) {
                Shizuku.removeBinderReceivedListener(listener)
                setError(Exception("等待服务启动超时"), 8)
            }
        }
    }

    private fun hasErrorInOutput(): Boolean = _outputLines.value.any {
        it.contains("错误：") || it.contains("Error:") ||
            it.contains("Exception") || it.contains("FATAL") || it.contains("fatal:")
    }

    private fun getLastErrorMessage(): String {
        val errorLines = _outputLines.value.filter {
            it.contains("错误：") || it.contains("Error:")
        }
        return if (errorLines.isNotEmpty()) {
            errorLines.last()
                .substringAfter("错误：")
                .substringAfter("Error:")
                .trim()
        } else {
            "启动失败，请查看日志"
        }
    }

    fun retry() {
        viewModelScope.launch {
            _outputLines.value = emptyList()
            _errorMessage.value = null
            _isCompleted.value = false
            initializeSteps()
            delay(500.milliseconds)
            startProcess()
        }
    }

    override fun onCleared() {
        super.onCleared()
        adbMdns?.stop()
        adbMdns = null
    }
}
