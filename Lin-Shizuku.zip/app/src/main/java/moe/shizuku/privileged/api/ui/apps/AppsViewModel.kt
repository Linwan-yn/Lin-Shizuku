package moe.shizuku.privileged.api.ui.apps

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import moe.shizuku.privileged.api.core.ShizukuManager
import moe.shizuku.privileged.api.data.AppInfo

/**
 * 电池优化白名单管理。
 *
 * 列出全部已安装应用，通过 shell 命令（Shizuku / Stellar 服务端，uid 2000 权限）
 * 读取与修改系统 deviceidle 白名单：
 *   - 查询全量：dumpsys deviceidle whitelist  （解析 Whitelist user/system apps 的包名集合）
 *   - 加入：     dumpsys deviceidle whitelist +<package>
 *   - 移出：     dumpsys deviceidle whitelist -<package>
 * 白名单中的应用将豁免系统 Doze / 省电模式的深度后台限制。
 */
class AppsViewModel(private val context: Context) : ViewModel() {

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps.asStateFlow()

    /** 当前在电池优化白名单中的包名集合。 */
    private val _whitelist = MutableStateFlow<Set<String>>(emptySet())
    val whitelist: StateFlow<Set<String>> = _whitelist.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _serviceRunning = MutableStateFlow(false)
    val serviceRunning: StateFlow<Boolean> = _serviceRunning.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _loading.value = true
            _message.value = null
            val running = ShizukuManager.getStatus() == ShizukuManager.Status.RUNNING
            _serviceRunning.value = running
            _apps.value = ShizukuManager.getAllApps(context)
            if (running) {
                _whitelist.value = queryWhitelist()
            } else {
                _whitelist.value = emptySet()
            }
            _loading.value = false
        }
    }

    /**
     * 读取系统电池优化白名单全量集合。
     * 先解析 dumpsys deviceidle whitelist 全量输出；若解析为空（厂商输出格式不兼容
     * 或命令无权限），降级为逐应用查询 dumpsys deviceidle whitelist "=<pkg>"（true/false）。
     */
    private suspend fun queryWhitelist(): Set<String> = withContext(Dispatchers.IO) {
        var set = try {
            parseWhitelist(ShizukuManager.runCommand("dumpsys deviceidle whitelist"))
        } catch (_: Throwable) { emptySet() }
        if (set.isEmpty()) {
            set = queryOneByOne()
        }
        set
    }

    /** 兼容多厂商输出格式的解析：包名 (uid) / 包名 (uid=xxx) / 行尾带注释。 */
    private fun parseWhitelist(out: String): Set<String> {
        if (out.isBlank()) return emptySet()
        val set = mutableSetOf<String>()
        for (re in listOf(
            Regex("""([A-Za-z0-9_.]+)\s*\(\d+\)"""),
            Regex("""([A-Za-z0-9_.]+)\s*\(uid=\d+\)""")
        )) {
            for (m in re.findAll(out)) set.add(m.groupValues[1])
            if (set.isNotEmpty()) return set
        }
        return set
    }

    /** 降级通道：逐个应用查询白名单状态，输出 true 的包名。 */
    private suspend fun queryOneByOne(): Set<String> = withContext(Dispatchers.IO) {
        val set = mutableSetOf<String>()
        try {
            val out = ShizukuManager.runCommand(
                "pm list packages | sed 's/package://' | while read -r p; do r=\$(dumpsys deviceidle whitelist \"=\$p\" 2>/dev/null); [ \"\$r\" = \"true\" ] && echo \"\$p\"; done"
            )
            for (line in out.lineSequence()) {
                val p = line.trim()
                if (p.isNotEmpty() && p.all { it.isLetterOrDigit() || it == '.' || it == '_' }) {
                    set.add(p)
                }
            }
        } catch (_: Throwable) {}
        set
    }

    /** 加入 / 移出电池优化白名单，随后全量刷新确认结果。 */
    fun toggle(app: AppInfo) {
        if (!_serviceRunning.value) {
            _message.value = "Shizuku 服务未运行，无法修改白名单"
            return
        }
        val inList = _whitelist.value.contains(app.packageName)
        val action = if (inList) "移出" else "加入"
        viewModelScope.launch(Dispatchers.IO) {
            val cmd = if (inList) {
                "dumpsys deviceidle whitelist -${app.packageName}"
            } else {
                "dumpsys deviceidle whitelist +${app.packageName}"
            }
            val out = try { ShizukuManager.runCommand(cmd) } catch (_: Throwable) { "" }
            val newSet = queryWhitelist()
            withContext(Dispatchers.Main) {
                val changed = if (inList) {
                    !newSet.contains(app.packageName)
                } else {
                    newSet.contains(app.packageName)
                }
                _whitelist.value = newSet
                if (!changed) {
                    _message.value = "$action 白名单失败（部分厂商系统会限制 deviceidle 命令）：$out"
                }
            }
        }
    }

    fun clearMessage() {
        _message.value = null
    }
}
