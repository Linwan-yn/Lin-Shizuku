package moe.shizuku.privileged.api.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

/**
 * Boot receiver — starts Shizuku automatically on boot if enabled in settings.
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        try {
            Prefs.init(context)
        } catch (_: Throwable) {}

        if (!Prefs.startOnBoot) {
            Log.d(TAG, "Auto-start on boot is disabled")
            return
        }

        Log.d(TAG, "Auto-start on boot is enabled, starting Shizuku...")

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Wait for the system to settle after boot, then retry a few times:
                // su / surfaceflinger / zygote may not be fully ready immediately.
                kotlinx.coroutines.delay(5_000L)
                var lastResult = ""
                repeat(3) { attempt ->
                    if (moe.shizuku.privileged.api.core.ShizukuManager.isRunningCompat()) {
                        Log.d(TAG, "Shizuku already running on boot")
                        return@launch
                    }
                    lastResult = ShizukuManager.startService(context)
                    Log.d(TAG, "Boot start attempt ${attempt + 1}: $lastResult")
                    if (moe.shizuku.privileged.api.core.ShizukuManager.isRunningCompat()) return@launch
                    kotlinx.coroutines.delay(4_000L)
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Boot start failed", e)
            } finally {
                pendingResult.finish()
            }
        }
    }
}
