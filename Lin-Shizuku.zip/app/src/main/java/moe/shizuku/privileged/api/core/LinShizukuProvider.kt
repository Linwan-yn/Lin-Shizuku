package moe.shizuku.privileged.api.core

import android.os.Bundle
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuProvider

/**
 * Shizuku provider with logging and Sui disabled.
 */
class LinShizukuProvider : ShizukuProvider() {

    override fun onCreate(): Boolean {
        disableAutomaticSuiInitialization()
        Log.i(TAG, "LinShizukuProvider onCreate")
        return super.onCreate()
    }

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        Log.i(TAG, "call method=$method, extras=${extras != null}")
        return try {
            val result = super.call(method, arg, extras)
            Log.i(TAG, "call result=$result, binder alive=${Shizuku.getBinder()?.pingBinder() == true}")
            result
        } catch (e: Throwable) {
            Log.e(TAG, "call failed: ${e.message}", e)
            null
        }
    }

    companion object {
        private const val TAG = "LinShizukuProvider"
    }
}
