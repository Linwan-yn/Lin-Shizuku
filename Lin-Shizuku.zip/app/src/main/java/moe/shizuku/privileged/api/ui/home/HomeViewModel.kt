package moe.shizuku.privileged.api.ui.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import moe.shizuku.privileged.api.core.Prefs
import moe.shizuku.privileged.api.core.ShizukuManager
import moe.shizuku.privileged.api.util.AdbStarter
import moe.shizuku.privileged.api.util.Starter
import rikka.shizuku.Shizuku

/** Which startup flow is currently running / was last run. */
enum class StartMode { NONE, ROOT, WADB }

/**
 * Home screen state. Mirrors the official `ServiceStatus` model
 * (uid / apiVersion / seContext / permission) adapted to the Compose UI.
 */
data class HomeUiState(
    val running: Boolean = false,
    val serverVersion: Int = -1,
    val serverUid: Int = -1,
    val seContext: String? = null,
    val rootAvailable: Boolean = false,
    val authorizedCount: Int = 0,
    val starting: Boolean = false,
    val dialogVisible: Boolean = false,
    val startMode: StartMode = StartMode.NONE,
    val output: String = ""
) {
    /** Same semantic as official ServiceStatus.isRunning: binder alive + uid known. */
    val isRunning: Boolean get() = running && serverUid != -1

    /** Identity of the running server, same logic as official launch-mode detection. */
    val identityText: String
        get() = when {
            !isRunning -> "未连接"
            serverUid == 0 -> "root"
            serverUid == 2000 -> "shell (adb)"
            else -> "uid $serverUid"
        }
}

/**
 * ViewModel for the home screen: loads real service status from the Shizuku
 * binder (migrated from official HomeViewModel), and runs the root / wireless-adb
 * startup flows with streaming output (migrated from official StarterActivity).
 */
class HomeViewModel : ViewModel() {

    private val _state = MutableStateFlow(HomeUiState())
    val state: StateFlow<HomeUiState> = _state.asStateFlow()

    /** Watchdog: true once the service has been seen running; a later silent
     *  disappearance (without a user-initiated stop) is treated as a crash and
     *  triggers automatic recovery when enabled. */
    private var watchdogArmed = false

    /** Timestamp until which automatic recovery is suppressed (user pressed stop). */
    private var suppressWatchdogUntil = 0L

    /**
     * Reload service status from the Shizuku API.
     * Official logic: only read binder info when pingBinder() succeeds.
     *
     * @param includeCount whether to (re)scan the authorized-app count (heavier).
     */
    fun refresh(ctx: Context, includeCount: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            val running = moe.shizuku.privileged.api.core.ShizukuManager.isRunningCompat()
            val version = if (running) moe.shizuku.privileged.api.core.ShizukuManager.getServerVersionCompat() else -1
            val uid = if (running) moe.shizuku.privileged.api.core.ShizukuManager.getServerUidCompat() else -1
            val seContext = if (running && version >= 6) {
                try { Shizuku.getSELinuxContext() } catch (_: Throwable) { null }
            } else null
            val root = ShizukuManager.isRooted()
            val prev = _state.value
            // 计数始终扫描：服务未激活时返回 Shizuku 兼容应用总数，激活后返回已授权数
            val count = if (includeCount) {
                try { ShizukuManager.getAuthorizedCount(ctx) } catch (_: Throwable) { prev.authorizedCount }
            } else {
                prev.authorizedCount
            }
            _state.update {
                it.copy(
                    running = running,
                    serverVersion = version,
                    serverUid = uid,
                    seContext = seContext,
                    rootAvailable = root,
                    authorizedCount = count
                )
            }
            if (running) watchdogArmed = true
            maybeAutoRecover(ctx)
        }
    }

    /** Watchdog: silently restart the service if it crashed and recovery is enabled. */
    private suspend fun maybeAutoRecover(ctx: Context) {
        val s = _state.value
        if (!watchdogArmed) return          // never seen running → nothing to recover
        if (s.isRunning || s.starting) return
        if (System.currentTimeMillis() < suppressWatchdogUntil) return
        if (!Prefs.watchdog) return
        if (!s.rootAvailable) return        // non-root cannot auto-restart; user starts via wireless adb

        watchdogArmed = false
        _state.update {
            it.copy(starting = true, startMode = StartMode.ROOT, output = "检测到服务异常退出，正在自动恢复...\n")
        }
        val sb = StringBuilder("检测到服务异常退出，正在自动恢复...\n\n")
        val exec = ShizukuManager.startService(ctx)
        sb.append(exec).append('\n')
        sb.append("\nWaiting for service...\n")
        _state.update { it.copy(output = sb.toString()) }
        val bound = ShizukuManager.waitForBinder()
        sb.append(if (bound) "服务已自动恢复 ✓\n" else "自动恢复失败，请手动启动。\n")
        _state.update { it.copy(output = sb.toString()) }

        refresh(ctx, includeCount = true)
        _state.update { it.copy(starting = false) }
    }

    /** Start Shizuku via root (su). Adapted from official StarterActivity.startRoot(). */
    fun startRoot(ctx: Context) {
        if (_state.value.starting) return
        viewModelScope.launch {
            _state.update {
                it.copy(starting = true, dialogVisible = true, startMode = StartMode.ROOT, output = "")
            }
            val sb = StringBuilder()
            sb.append("Starting with root...\n\n")
            _state.update { it.copy(output = sb.toString()) }

            val execOutput = withContext(Dispatchers.IO) {
                if (!ShizukuManager.isRooted()) {
                    "错误：未检测到 su，无法以 root 启动。\n请确认设备已获取 root，且 su 可用（如 Magisk）。"
                } else {
                    try {
                        Starter.writeSdcardFiles(ctx)
                        val cmd = Starter.getSdcardCommand(ctx)
                        sb.append("执行: $cmd\n\n")
                        _state.update { it.copy(output = sb.toString()) }

                        val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                        val out = proc.inputStream.bufferedReader().readText()
                        val err = proc.errorStream.bufferedReader().readText()
                        proc.waitFor()
                        (out + err).ifEmpty { "（无输出）" }
                    } catch (e: Throwable) {
                        "启动失败: ${e.message ?: e.javaClass.simpleName}"
                    }
                }
            }
            sb.append(execOutput).append('\n')
            _state.update { it.copy(output = sb.toString()) }

            // Wait for the server binder, same as official StarterActivity.
            sb.append("\nWaiting for service...\n")
            _state.update { it.copy(output = sb.toString()) }
            val bound = ShizukuManager.waitForBinder()
            sb.append(if (bound) "Service started ✓\n" else "服务未就绪，请检查上方输出。\n")
            _state.update { it.copy(output = sb.toString()) }

            refresh(ctx, includeCount = true)
            _state.update { it.copy(starting = false) }
        }
    }

    /** Start Shizuku via wireless adb, streaming output from [AdbStarter]. */
    fun startWadb(ctx: Context) {
        if (_state.value.starting) return
        viewModelScope.launch {
            _state.update {
                it.copy(starting = true, dialogVisible = true, startMode = StartMode.WADB, output = "")
            }
            val sb = StringBuilder()
            val ok = AdbStarter.startViaAdb(ctx) { chunk ->
                sb.append(chunk)
                _state.update { it.copy(output = sb.toString()) }
            }
            if (ok) {
                sb.append("\nWaiting for service...\n")
                _state.update { it.copy(output = sb.toString()) }
                val bound = ShizukuManager.waitForBinder()
                sb.append(if (bound) "Service started ✓\n" else "服务未就绪，请检查上方输出。\n")
            }
            _state.update { it.copy(output = sb.toString()) }

            refresh(ctx, includeCount = true)
            _state.update { it.copy(starting = false) }
        }
    }

    /** Stop the Shizuku service. Same as official menu "Stop" action (Shizuku.exit()). */
    fun stop(ctx: Context) {
        // User-initiated stop must not trigger the watchdog.
        suppressWatchdogUntil = System.currentTimeMillis() + 30_000L
        viewModelScope.launch(Dispatchers.IO) {
            ShizukuManager.stopService()
            delay(600)
            refresh(ctx, includeCount = false)
        }
    }

    fun dismissDialog() {
        _state.update { it.copy(dialogVisible = false, output = "") }
    }
}
