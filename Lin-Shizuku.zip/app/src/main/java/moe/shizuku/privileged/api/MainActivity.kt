package moe.shizuku.privileged.api

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.toMutableStateList
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import moe.shizuku.privileged.api.core.AppThemeState
import moe.shizuku.privileged.api.core.Prefs
import moe.shizuku.privileged.api.ui.apps.AppsScreen
import moe.shizuku.privileged.api.ui.auth.AuthAppsScreen
import moe.shizuku.privileged.api.ui.battery.BatteryScreen
import moe.shizuku.privileged.api.ui.browser.BrowserActivity
import moe.shizuku.privileged.api.ui.home.HomeScreen
import moe.shizuku.privileged.api.ui.modules.ModulesScreen
import moe.shizuku.privileged.api.ui.modules.ScriptEditActivity
import moe.shizuku.privileged.api.ui.nav.NavAnimations
import moe.shizuku.privileged.api.ui.pairing.PairingScreen
import moe.shizuku.privileged.api.ui.settings.SettingsScreen
import moe.shizuku.privileged.api.ui.terminal.TerminalScreen
import moe.shizuku.privileged.api.ui.theme.LinShizukuTheme
import moe.shizuku.privileged.api.ui.widget.GlassNavItem
import moe.shizuku.privileged.api.ui.widget.LiquidGlassBottomBar
import moe.shizuku.privileged.api.util.ActivityTransitions
import moe.shizuku.privileged.api.util.SystemSettings

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        SystemSettings.applySystem(this)
        // 统一诊断日志：fallback 目录（无「所有文件访问」权限时降级写入）
        moe.shizuku.privileged.api.core.DiagnosticLog.setFallbackDir(getExternalFilesDir(null) ?: filesDir)
        // Stellar 生态：App 前台进程启动时主动从 .stellar provider 拉取 Binder（服务可能已先于 App 运行），
        // 拉取后桥接官方 Shizuku 单例，首页立即显示运行状态
        runCatching {
            roro.stellar.StellarProvider.requestBinderForNonProviderProcess(applicationContext)
        }
        // 可信 WLAN 自动启动监听（进程存活期间有效）
        moe.shizuku.privileged.api.core.WlanAutoStartManager.register(applicationContext)
        // 系统暗色模式监听：跟随系统分支即时响应系统切换
        AppThemeState.systemNight.value = isSystemNight(resources.configuration)
        registerComponentCallbacks(object : android.content.ComponentCallbacks {
            override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
                AppThemeState.systemNight.value = isSystemNight(newConfig)
            }
            override fun onLowMemory() {}
        })
        setContent {
            // 外观设置变更（夜间模式/动态颜色/AMOLED/液态玻璃）通过全局 Compose State 驱动，
            // 设置页切换后必然重组，即时生效（无需重启/recreate）
            val darkOption by AppThemeState.darkModeOption
            val amoled by AppThemeState.amoled
            val dynamicColor by AppThemeState.dynamicColor
            val glassEnabled by AppThemeState.glassEnabled
            val systemNight by AppThemeState.systemNight
            val dark = when (darkOption) {
                "总是开启" -> true
                "总是关闭" -> false
                else -> systemNight
            }
            LinShizukuTheme(
                darkTheme = dark,
                dynamicColor = dynamicColor,
                amoled = amoled
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        glassEnabled = glassEnabled,
                        onEditScript = { id ->
                            val intent = Intent(this, ScriptEditActivity::class.java)
                            if (id != null) intent.putExtra("script_id", id)
                            startActivity(intent)
                            ActivityTransitions.overrideForward(this)
                        }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.hideRecents) {
            try {
                val am = getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                am.appTasks.forEach { it.setExcludeFromRecents(true) }
            } catch (_: Throwable) {}
        }
    }

    override fun finish() {
        super.finish()
        ActivityTransitions.overrideBackward(this)
    }
}

/**
 * Navigation target identifiers.
 * Tab screens use 10+tab index so they never collide with home sub-screens (0..9).
 */
private object NavTarget {
    const val HOME = 0
    const val AUTH_APPS = 1
    const val PAIRING = 2
    const val BATTERY = 3
    const val MODULES = 11
    const val TERMINAL = 12
    const val APPS = 13
    const val SETTINGS = 14
}

    private fun isSystemNight(config: android.content.res.Configuration): Boolean {
        return (config.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
    }

@Composable
private fun MainScreen(
    onEditScript: (String?) -> Unit,
    glassEnabled: Boolean = Prefs.glassEnabled
) {
    val ctx = LocalContext.current
    val view = LocalView.current

    var tab by rememberSaveable { mutableIntStateOf(0) }
    // Back stack of sub-screen targets within the home tab. Empty = home.
    // Saved across Activity recreation (settings applied via recreate()).
    val subStack = rememberSaveable(
        saver = listSaver(
            save = { it.toList() },
            restore = { it.toMutableStateList() }
        )
    ) { mutableStateListOf<Int>() }
    // Track previous target for direction-aware animation.
    var prevTarget by remember { mutableIntStateOf(NavTarget.HOME) }

    val currentSub = subStack.lastOrNull() ?: 0
    // 子页（首页或其它 tab 推入）优先显示；无子页时：首页 tab→HOME，其它 tab→tab+10
    val currentTarget = if (subStack.isNotEmpty()) currentSub else if (tab == 0) 0 else tab + 10

    val items = listOf(
        GlassNavItem(Icons.Filled.Home, "首页"),
        GlassNavItem(Icons.Filled.ViewModule, "模块"),
        GlassNavItem(Icons.Filled.Terminal, "终端"),
        GlassNavItem(Icons.Filled.BatteryFull, "电池"),
        GlassNavItem(Icons.Filled.Settings, "设置")
    )

    /** Push a sub-screen onto the home back stack. */
    fun pushSub(target: Int) {
        prevTarget = currentTarget
        subStack.add(target)
    }

    /** Pop the top sub-screen. Returns true if something was popped. */
    fun popSub(): Boolean {
        if (subStack.isEmpty()) return false
        prevTarget = currentTarget
        subStack.removeLast()
        return true
    }

    /** Switch to a bottom tab, clearing any sub-stack. */
    fun switchTab(newTab: Int) {
        if (newTab == tab && subStack.isEmpty()) return
        prevTarget = currentTarget
        subStack.clear()
        tab = newTab
        // Haptic feedback on tab switch
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
        }
    }

    // System back handler: pop sub-stack first, then return to home tab.
    BackHandler(enabled = subStack.isNotEmpty() || tab != 0) {
        when {
            subStack.isNotEmpty() -> { popSub() }
            tab != 0 -> { switchTab(0) }
        }
    }

    // Determine animation direction:
    // - Sub-screen push/pop: horizontal slide
    // - Tab switch: cross-fade + scale
    val isSubNavigation = (tab == 0 && prevTarget < 10) || (currentTarget < 10)
    val goingBack = when {
        // Popping a sub-screen (home or other tab)
        subStack.isNotEmpty().not() && prevTarget in 1..3 && currentTarget < 10 -> true
        // Tab switch back to home
        prevTarget >= 10 && currentTarget == 0 -> true
        // Sub-screen popped back to a non-home tab (e.g. settings)
        prevTarget < 10 && currentTarget >= 10 -> true
        else -> false
    }

    // ===== 关键修复点：页面内容只避让系统导航栏 WindowInsets，不叠加自定义胶囊高度 =====
    val density = LocalDensity.current
    // 仅消费系统导航栏底部 inset，不人为增加多余底部留白
    val systemNavInset = with(density) { WindowInsets.navigationBars.getBottom(density).toDp() }

    Box(modifier = Modifier.fillMaxSize()) {
        // Subtle vertical gradient background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.background.copy(alpha = 0.97f)
                        )
                    )
                )
        )

        AnimatedContent(
            targetState = currentTarget,
            transitionSpec = NavAnimations.transitionSpec(
                isSubPush = isSubNavigation,
                goingBack = goingBack
            ),
            label = "mainNav",
            modifier = Modifier
                .fillMaxSize()
                // 关键修复点：仅避让系统导航栏高度，不叠加胶囊高度，无多余底部留白
                .padding(bottom = systemNavInset)
        ) { target ->
            when (target) {
                NavTarget.HOME -> HomeScreen(
                    onManageApps = { pushSub(NavTarget.AUTH_APPS) },
                    onPair = { pushSub(NavTarget.PAIRING) },
                    onStartWireless = { pushSub(NavTarget.PAIRING) },
                    onGuide = {
                        val intent = Intent(ctx, BrowserActivity::class.java)
                        intent.putExtra("url", "https://shizuku.rikka.app/zh-hans/guide/")
                        intent.putExtra("title", "分步骤指南")
                        ctx.startActivity(intent)
                        (ctx as? android.app.Activity)?.let { ActivityTransitions.overrideForward(it) }
                    }
                )
                NavTarget.AUTH_APPS -> AuthAppsScreen()
                NavTarget.PAIRING -> PairingScreen(onBack = { popSub() })
                NavTarget.BATTERY -> BatteryScreen()
                NavTarget.MODULES -> ModulesScreen(onEditScript = onEditScript)
                NavTarget.TERMINAL -> TerminalScreen()
                NavTarget.APPS -> AppsScreen()
                NavTarget.SETTINGS -> SettingsScreen(
                    onOpenBattery = {
                        // 直接跳系统电池优化：HyperOS 上即「电量详情 / 省电策略」页
                        try {
                            val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                            intent.data = android.net.Uri.parse("package:${ctx.packageName}")
                            ctx.startActivity(intent)
                        } catch (_: Throwable) {
                            try {
                                ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            } catch (_: Throwable) {
                                try {
                                    val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                    i.data = android.net.Uri.parse("package:${ctx.packageName}")
                                    ctx.startActivity(i)
                                } catch (_: Throwable) {}
                            }
                        }
                    },
                    onOpenApps = { pushSub(NavTarget.APPS) }
                )
                else -> HomeScreen(
                    onManageApps = { pushSub(NavTarget.AUTH_APPS) },
                    onPair = { pushSub(NavTarget.PAIRING) },
                    onStartWireless = { pushSub(NavTarget.PAIRING) },
                    onGuide = {
                        val intent = Intent(ctx, BrowserActivity::class.java)
                        intent.putExtra("url", "https://shizuku.rikka.app/zh-hans/guide/")
                        intent.putExtra("title", "分步骤指南")
                        ctx.startActivity(intent)
                        (ctx as? android.app.Activity)?.let { ActivityTransitions.overrideForward(it) }
                    }
                )
            }
        }

        // 顶层：悬浮胶囊，叠加在系统导航栏之上，不占用内容空间
        LiquidGlassBottomBar(
            items = items,
            selectedIndex = tab,
            onSelect = { switchTab(it) },
            glassEnabled = glassEnabled,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}
