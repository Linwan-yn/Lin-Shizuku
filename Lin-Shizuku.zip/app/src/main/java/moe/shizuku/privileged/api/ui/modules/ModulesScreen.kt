package moe.shizuku.privileged.api.ui.modules

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.platform.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import moe.shizuku.privileged.api.core.LinModuleItem
import moe.shizuku.privileged.api.core.ModuleStore
import moe.shizuku.privileged.api.core.ScriptItem
import moe.shizuku.privileged.api.core.ShizukuManager
import moe.shizuku.privileged.api.ui.browser.BrowserActivity
import moe.shizuku.privileged.api.ui.widget.EmptyState
import moe.shizuku.privileged.api.ui.widget.GlassCard
import moe.shizuku.privileged.api.ui.widget.pressClickable
import moe.shizuku.privileged.api.ui.widget.pressClickableNoRipple
import moe.shizuku.privileged.api.util.ActivityTransitions

private val PlayButtonColor = Color(0xFF006064)

/**
 * 模块页：Shell 脚本 + Lin 模块，真实数据（filesDir/modules/）与真实执行（Shizuku shell）。
 */
@Composable
fun ModulesScreen(onEditScript: (String?) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }

    var scripts by remember { mutableStateOf(emptyList<ScriptItem>()) }
    var linModules by remember { mutableStateOf(emptyList<LinModuleItem>()) }
    var loading by remember { mutableStateOf(true) }

    // 执行弹窗状态
    var execVisible by remember { mutableStateOf(false) }
    var execTitle by remember { mutableStateOf("执行中...") }
    var execOutput by remember { mutableStateOf("") }
    var execDone by remember { mutableStateOf(false) }
    var showQuickCmd by remember { mutableStateOf(false) }

    // 删除确认
    var deleteTarget by remember { mutableStateOf<Pair<String, String>?>(null) } // (type, id)
    var installMsg by remember { mutableStateOf<String?>(null) }
    var showDoc by remember { mutableStateOf(false) }

    fun reload() {
        scope.launch(Dispatchers.IO) {
            val s = ModuleStore.listScripts(ctx)
            val m = ModuleStore.listModules(ctx)
            withContext(Dispatchers.Main) {
                scripts = s
                linModules = m
                loading = false
            }
        }
    }

    // 从编辑 / 输出页返回时自动刷新
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) reload()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(Unit) { reload() }

    // 导入 .sh 脚本
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val err = ModuleStore.importScript(ctx, uri)
                withContext(Dispatchers.Main) {
                    installMsg = when {
                        err == null -> "脚本导入成功"
                        err.startsWith("脚本已导入") -> err
                        else -> "导入失败: $err"
                    }
                    reload()
                }
            }
        }
    }

    /** 真实执行命令：流式输出到执行弹窗。 */
    fun runReal(title: String, cmd: String) {
        if (cmd.isBlank()) return
        execVisible = true
        execDone = false
        execTitle = title
        execOutput = ""
        scope.launch(Dispatchers.IO) {
            val finished = ShizukuManager.runCommandStreaming(
                cmd,
                onLine = { line, isErr ->
                    withContext(Dispatchers.Main) {
                        execOutput += (if (isErr) "[错误] " else "") + line + "\n"
                    }
                },
                timeoutMs = 60_000
            )
            withContext(Dispatchers.Main) {
                execDone = true
                execTitle = if (finished) "执行完毕" else "执行超时"
            }
        }
    }

    /** 开关型脚本 / 模块：执行 on/off 块并持久化状态。 */
    fun runToggle(id: String, name: String, on: Boolean) {
        ModuleStore.setEnabled(ctx, id, on)
        scope.launch(Dispatchers.IO) {
            val block = ModuleStore.toggleBlock(ctx, id, on)
            withContext(Dispatchers.Main) {
                runReal(
                    "${if (on) "开启" else "关闭"}: $name",
                    if (block.isBlank()) "echo 脚本缺少 ${if (on) "#on" else "#off"} 块" else block
                )
            }
        }
    }

    /** 安装模块（SAF 选择 zip / .lin）。 */
    val installLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val err = ModuleStore.installModule(ctx, uri)
                withContext(Dispatchers.Main) {
                    if (err != null) {
                        installMsg = err
                    } else {
                        installMsg = "模块安装成功"
                    }
                    reload()
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TabRow(
                    selectedTabIndex = tab,
                    modifier = Modifier.weight(1f)
                ) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Shell 脚本") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Lin 模块") })
                }
                IconButton(onClick = { showQuickCmd = true }) {
                    Icon(Icons.Filled.Terminal, "快速命令", tint = MaterialTheme.colorScheme.onSurface)
                }
                IconButton(onClick = { showDoc = true }) {
                    Icon(Icons.Filled.Info, "格式与制作文档", tint = MaterialTheme.colorScheme.onSurface)
                }
            }
            Box(modifier = Modifier.fillMaxSize()) {
                if (tab == 0) {
                    ScriptsTab(
                        scripts = scripts,
                        loading = loading,
                        onEdit = { onEditScript(it) },
                        onNew = { onEditScript(null) },
                        onImport = { importLauncher.launch(arrayOf("*/*")) },
                        onRun = { script ->
                            val intent = Intent(ctx, OutputActivity::class.java)
                            intent.putExtra("script_id", script.id)
                            ctx.startActivity(intent)
                            ActivityTransitions.overrideForward(ctx as android.app.Activity)
                        },
                        onToggle = { script, on ->
                            runToggle(script.id, script.name, on)
                            scripts = scripts.map {
                                if (it.id == script.id) it.copy(enabled = on) else it
                            }
                        },
                        onDelete = { script -> deleteTarget = Pair("script", script.id) }
                    )
                } else {
                    LinModulesTab(
                        modules = linModules,
                        loading = loading,
                        onToggle = { m, on ->
                            // Lin 模块开关 = 启用/禁用状态；关闭时真正停止模块（执行 stop.sh / 清理后台进程）
                            ModuleStore.setEnabled(ctx, m.id, on)
                            if (!on) {
                                scope.launch(Dispatchers.IO) {
                                    ModuleStore.stopModule(ctx, m.id)
                                }
                            }
                            linModules = linModules.map {
                                if (it.id == m.id) it.copy(enabled = on) else it
                            }
                        },
                        onAction = { m ->
                            val script = ModuleStore.moduleActionScript(ctx, m.id)
                            runReal("运行: ${m.name}", script)
                        },
                        onWebUI = { m ->
                            val url = ModuleStore.webuiUrl(ctx, m)
                            if (url.isNotBlank()) {
                                val intent = Intent(ctx, BrowserActivity::class.java)
                                intent.putExtra("url", url)
                                intent.putExtra("title", m.name)
                                intent.putExtra("module_id", m.id)
                                ctx.startActivity(intent)
                                ActivityTransitions.overrideForward(ctx as android.app.Activity)
                            }
                        },
                        onDelete = { m -> deleteTarget = Pair("module", m.id) },
                        onInstall = { installLauncher.launch(arrayOf("*/*")) }
                    )
                }
            }
        }

        if (execVisible) {
            ExecutionOverlay(
                title = execTitle,
                output = execOutput,
                done = execDone,
                onClose = { execVisible = false }
            )
        }

        if (showQuickCmd) {
            QuickCommandDialog(
                onDismiss = { showQuickCmd = false },
                onExecute = { cmd ->
                    showQuickCmd = false
                    runReal("命令: $cmd", cmd)
                }
            )
        }

        if (showDoc) {
            ModuleDocDialog(onDismiss = { showDoc = false })
        }

        deleteTarget?.let { (type, id) ->
            AlertDialog(
                onDismissRequest = { deleteTarget = null },
                title = { Text("删除确认", fontWeight = FontWeight.SemiBold) },
                text = { Text("确定删除该${if (type == "script") "脚本" else "模块"}吗？此操作不可恢复。") },
                confirmButton = {
                    TextButton(onClick = {
                        deleteTarget = null
                        if (type == "script") ModuleStore.deleteScript(ctx, id) else ModuleStore.deleteModule(ctx, id)
                        reload()
                    }) { Text("删除", color = Color(0xFFE57373)) }
                },
                dismissButton = {
                    TextButton(onClick = { deleteTarget = null }) { Text("取消") }
                }
            )
        }

        installMsg?.let { msg ->
            AlertDialog(
                onDismissRequest = { installMsg = null },
                title = { Text("安装结果", fontWeight = FontWeight.SemiBold) },
                text = { Text(msg) },
                confirmButton = {
                    TextButton(onClick = { installMsg = null }) { Text("好") }
                }
            )
        }
    }
}

@Composable
private fun ExecutionOverlay(
    title: String,
    output: String,
    done: Boolean,
    onClose: () -> Unit
) {
    val scrollState = rememberScrollState()
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.weight(1f))
                if (!done) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, "关闭", tint = MaterialTheme.colorScheme.onBackground)
                    }
                }
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp)
            ) {
                if (output.isEmpty() && !done) {
                    Text("等待输出...", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                } else {
                    Text(output, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp, fontFamily = FontFamily.Monospace, lineHeight = 20.sp)
                }
            }
            if (done) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 100.dp),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(PlayButtonColor)
                            .clickable { onClose() }
                            .padding(horizontal = 24.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("关闭", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickCommandDialog(
    onDismiss: () -> Unit,
    onExecute: (String) -> Unit
) {
    var cmd by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("命令执行", fontWeight = FontWeight.SemiBold) },
        text = {
            Column {
                OutlinedTextField(
                    value = cmd,
                    onValueChange = { cmd = it },
                    label = { Text("输入命令") },
                    placeholder = { Text("通过 Shizuku 以 shell 权限执行") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 6
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (cmd.isNotBlank()) onExecute(cmd) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("执行")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        }
    )
}

@Composable
private fun LinModulesTab(
    modules: List<LinModuleItem>,
    loading: Boolean,
    onToggle: (LinModuleItem, Boolean) -> Unit,
    onAction: (LinModuleItem) -> Unit,
    onWebUI: (LinModuleItem) -> Unit,
    onDelete: (LinModuleItem) -> Unit,
    onInstall: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (loading) {
            EmptyState(
                title = "加载中...",
                subtitle = "",
                modifier = Modifier.padding(bottom = 80.dp)
            )
        } else if (modules.isEmpty()) {
            EmptyState(
                title = "暂无 Lin 模块",
                subtitle = "点击右下角安装模块（.lin / .zip 包）",
                modifier = Modifier.padding(bottom = 80.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
                    .padding(top = 16.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(modules, key = { it.id }) { module ->
                    LinModuleCard(
                        module = module,
                        onToggle = { onToggle(module, it) },
                        onAction = { onAction(module) },
                        onWebUI = { onWebUI(module) },
                        onDelete = { onDelete(module) }
                    )
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }

        ExtendedFloatingActionButton(
            onClick = onInstall,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 88.dp),
            icon = { Icon(Icons.Filled.Add, null) },
            text = { Text("安装模块") }
        )
    }
}

@Composable
private fun LinModuleCard(
    module: LinModuleItem,
    onToggle: (Boolean) -> Unit,
    onAction: () -> Unit,
    onWebUI: () -> Unit,
    onDelete: () -> Unit
) {
    var enabled by remember { mutableStateOf(module.enabled) }
    LaunchedEffect(module.enabled) { enabled = module.enabled }

    GlassCard {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(module.sizeLabel, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (module.webui.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (enabled) PlayButtonColor
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                            .then(if (enabled) Modifier.pressClickableNoRipple { onWebUI() } else Modifier)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "WEBUI",
                            fontSize = 11.sp,
                            color = if (enabled) Color.White
                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                if (module.hasAction) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (enabled) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                            .then(if (enabled) Modifier.pressClickableNoRipple { onAction() } else Modifier)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "运行",
                            fontSize = 11.sp,
                            color = if (enabled) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Spacer(modifier = Modifier.weight(1f))
                Switch(
                    checked = enabled,
                    onCheckedChange = {
                        enabled = it
                        onToggle(it)
                    }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(module.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            if (module.version.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text("版本: ${module.version}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (module.author.isNotEmpty()) {
                Text("作者: ${module.author}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("ID: ${module.id}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (module.description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(module.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (module.hasAction) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .then(if (enabled) Modifier.pressClickable { onAction() } else Modifier)
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Terminal, "执行",
                            tint = if (enabled) MaterialTheme.colorScheme.onSurfaceVariant
                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                if (module.webui.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .then(if (enabled) Modifier.pressClickable { onWebUI() } else Modifier)
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Filled.Language, "WebUI",
                            tint = if (enabled) MaterialTheme.colorScheme.onSurfaceVariant
                            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .pressClickable { onDelete() }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Delete, "删除", tint = Color(0xFFE57373), modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun ScriptsTab(
    scripts: List<ScriptItem>,
    loading: Boolean,
    onEdit: (String) -> Unit,
    onNew: () -> Unit,
    onImport: () -> Unit,
    onRun: (ScriptItem) -> Unit,
    onToggle: (ScriptItem, Boolean) -> Unit,
    onDelete: (ScriptItem) -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (loading) {
            EmptyState(
                title = "加载中...",
                subtitle = "",
                modifier = Modifier.padding(bottom = 80.dp)
            )
        } else if (scripts.isEmpty()) {
            EmptyState(
                title = "暂无 Shell 脚本",
                subtitle = "点击右下角按钮创建新脚本",
                modifier = Modifier.padding(bottom = 80.dp)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
                    .padding(top = 16.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(scripts, key = { it.id }) { script ->
                    ScriptCard(
                        script = script,
                        onEdit = { onEdit(script.id) },
                        onDelete = { onDelete(script) },
                        onRun = { onRun(script) },
                        onToggle = { on -> onToggle(script, on) }
                    )
                }
                item { Spacer(modifier = Modifier.height(80.dp)) }
            }
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 88.dp),
            horizontalAlignment = Alignment.End
        ) {
            FloatingActionButton(
                onClick = onImport,
                modifier = Modifier.size(48.dp),
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
            ) {
                Icon(Icons.Filled.FileOpen, "导入 .sh", tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(modifier = Modifier.height(10.dp))
            ExtendedFloatingActionButton(
                onClick = onNew,
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text("新建Shell脚本") }
            )
        }
    }
}

@Composable
private fun ScriptCard(
    script: ScriptItem,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRun: (ScriptItem) -> Unit,
    onToggle: (Boolean) -> Unit
) {
    var enabled by remember { mutableStateOf(script.enabled) }

    GlassCard {
        Column(modifier = Modifier.padding(vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(script.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    if (script.author.isNotEmpty()) {
                        Text("作者: ${script.author}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (script.brand.isNotEmpty()) {
                        Text("适用品牌: ${script.brand}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (script.description.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(script.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                if (script.isToggle) {
                    Switch(
                        checked = enabled,
                        onCheckedChange = {
                            enabled = it
                            onToggle(it)
                        },
                        modifier = Modifier.padding(top = 4.dp)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(PlayButtonColor)
                            .pressClickableNoRipple { onRun(script) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.PlayArrow, "执行", tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (script.isToggle) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text("开关型", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text("脚本", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Edit, "编辑", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Delete, "删除", tint = Color(0xFFE57373), modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

private val ModuleDocText = """
Shell 脚本格式
────────────────
存储目录：应用内部 filesDir/modules/<id>/run.sh
自动识别：含 #on 与 #off 标记为开关型，否则为普通脚本。

【普通脚本（RUN）】
顶部可用 #--- 包围的元数据块描述脚本：
#---
#name: 脚本名称
#description: 功能描述
#author: 作者
#brand: 适用品牌
#---
其余内容为 shell 命令，点击运行整文件执行，
输出在“执行输出”页实时显示。

【开关型脚本（TOGGLE）】
含 #on 与 #off 两个标记，标记之间为对应命令块：
#on
开启时执行的命令
#off
关闭时执行的命令
列表中显示为开关，切换即执行对应块。

【新建 / 编辑 / 导出】
右下角「新建Shell脚本」→ 填写名称与内容 → 保存；
支持导出 .sh 文件分享。

Lin 模块制作
────────────────
模块 = zip 包（.lin / .zip），安装后解压到
filesDir/modules/<id>/。目录结构：

<id>/
├─ module.json    必填：模块元数据
├─ run.sh         可选：action 脚本（含 #on/#off 可为开关）
├─ stop.sh        可选：停止脚本（开关关闭时执行，用于清理模块后台进程）
└─ web/           可选：WebUI 静态资源（默认入口 web/index.html）

【module.json 字段】
{
  "id": "模块唯一ID，仅限字母数字._-",
  "name": "模块名称",
  "version": "版本号",
  "author": "作者",
  "description": "功能描述",
  "webui": "web/index.html 或 http(s)://远程地址",
  "action": true
}

【模块能力】
· 运行：action 为 true 时卡片显示「运行」，执行 run.sh
· 开关：切换启用/禁用状态；关闭时执行 stop.sh（无 stop.sh 则清理
  引用模块目录的后台进程），让模块真正停止运行
· WebUI：webui 字段指向本地 web/index.html 或远程地址，
  卡片显示「WEBUI」按钮，浏览器打开
· 删除：卡片删除按钮移除整个目录

【打包】
将以上文件压成 zip（module.json 在包根目录），
重命名为 xxx.lin，在模块页「安装模块」选择即可。
""".trimIndent()

@Composable
private fun ModuleDocDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("脚本与模块文档", fontWeight = FontWeight.SemiBold) },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .height(420.dp)
            ) {
                Text(
                    ModuleDocText,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("好") }
        }
    )
}
