package moe.shizuku.privileged.api.ui.browser

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.runBlocking
import moe.shizuku.privileged.api.core.ModuleStore
import moe.shizuku.privileged.api.core.ShizukuManager
import moe.shizuku.privileged.api.ui.theme.LinShizukuTheme
import moe.shizuku.privileged.api.util.ActivityTransitions
import org.json.JSONObject
import java.io.File

class BrowserActivity : ComponentActivity() {

    private var webView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val url = intent.getStringExtra("url") ?: "https://shizuku.rikka.app/"
        val title = intent.getStringExtra("title") ?: "浏览器"
        val moduleId = intent.getStringExtra("module_id")

        setContent {
            LinShizukuTheme {
                BrowserScreen(
                    title = title,
                    url = url,
                    onBack = { finishWithTransition() },
                    onWebViewCreated = { view ->
                        webView = view
                        // Lin 模块本地 WebUI：注入 ksu 兼容桥（AxManager/KernelSU WebUI 协议）
                        if (moduleId != null) {
                            val dir = File(ModuleStore.moduleDir(this), moduleId)
                            view.addJavascriptInterface(LinModuleJsBridge(view, dir), "ksu")
                        }
                    }
                )
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView?.canGoBack() == true) {
            webView?.goBack()
        } else {
            finishWithTransition()
        }
    }

    private fun finishWithTransition() {
        ActivityTransitions.finishWithAnimation(this)
    }
}

/**
 * Lin 模块 WebUI 的 ksu 兼容桥（AxManager / KernelSU WebUI 协议）：
 * - ksu.exec(cmd, '{}', cbName)：异步执行 shell 命令，回调 (errno, stdout, stderr)
 * - ksu.moduleInfo()：返回当前模块目录信息
 * - ksu.moduleEnabled()：返回模块当前是否启用（开关关闭后 WebUI 可据此禁用操作）
 */
private class LinModuleJsBridge(
    private val webView: WebView,
    private val moduleDir: File
) {
    private val moduleId: String = moduleDir.name

    @JavascriptInterface
    fun moduleInfo(): String {
        return try {
            JSONObject().put("moduleDir", moduleDir.absolutePath).toString()
        } catch (_: Throwable) {
            "{}"
        }
    }

    @JavascriptInterface
    fun moduleEnabled(): Boolean {
        return try {
            ModuleStore.isEnabled(webView.context, moduleId)
        } catch (_: Throwable) {
            false
        }
    }

    @JavascriptInterface
    fun exec(cmd: String, opts: String, callbackName: String) {
        Thread {
            val out = try {
                runBlocking { ShizukuManager.runCommand(cmd) }
            } catch (e: Throwable) {
                "错误: ${e.message}"
            }
            webView.post {
                try {
                    webView.evaluateJavascript(
                        "window['$callbackName'](0, ${JSONObject.quote(out)}, '');",
                        null
                    )
                } catch (_: Throwable) {}
            }
        }.start()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BrowserScreen(
    title: String,
    url: String,
    onBack: () -> Unit,
    onWebViewCreated: (WebView) -> Unit
) {
    var progress by remember { mutableIntStateOf(0) }
    var currentUrl by remember { mutableStateOf(url) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()

    // Intercept system back: navigate web history first, then close activity.
    BackHandler(enabled = canGoBack) {
        // WebView back is handled via the activity's onBackPressed; this BackHandler
        // prevents the default finish when web history exists.
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { /* webView?.goBack() */ },
                        enabled = canGoBack
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "后退")
                    }
                    IconButton(
                        onClick = { /* webView?.goForward() */ },
                        enabled = canGoForward
                    ) {
                        Icon(Icons.Filled.ArrowForward, "前进")
                    }
                    IconButton(onClick = { /* webView?.reload() */ }) {
                        Icon(Icons.Filled.Refresh, "刷新")
                    }
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                userAgentString = "$userAgentString ShizukuDeepMod/3.0"
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                // 本地模块 WebUI（file:// web/index.html 及同目录资源）
                                allowFileAccess = true
                                @Suppress("DEPRECATION")
                                setAllowFileAccessFromFileURLs(true)
                            }
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    request?.url?.let { view?.loadUrl(it.toString()) }
                                    return true
                                }

                                override fun doUpdateVisitedHistory(
                                    view: WebView?,
                                    url: String?,
                                    isReload: Boolean
                                ) {
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    progress = newProgress
                                }
                            }
                            loadUrl(url)
                            onWebViewCreated(this)
                            canGoBack = canGoBack()
                            canGoForward = canGoForward()
                        }
                    },
                    update = { view ->
                        if (currentUrl != url) {
                            view.loadUrl(url)
                            currentUrl = url
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
