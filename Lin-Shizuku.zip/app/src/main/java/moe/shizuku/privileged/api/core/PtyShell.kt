package moe.shizuku.privileged.api.core

import android.system.OsConstants
import java.io.File
import java.io.FileDescriptor
import java.lang.reflect.Method

/**
 * PTY (pseudo-terminal) backed shell using reflection to access hidden android.system.Os PTY APIs.
 * Provides a real TTY so interactive programs (vim, top, less, etc.) work correctly.
 */
class PtyShell(
    private val command: String = "/system/bin/sh",
    private val args: Array<String> = emptyArray(),
    private val env: Array<String> = arrayOf("TERM=xterm-256color", "HOME=/data/local/tmp", "PS1=$ ")
) {
    private var masterFd: FileDescriptor? = null
    private var process: Process? = null
    private var reading = false

    // Reflected methods
    private val osClass = Class.forName("android.system.Os")
    private val posixOpenpt: Method = osClass.getMethod("posix_openpt", Int::class.javaPrimitiveType)
    private val grantpt: Method = osClass.getMethod("grantpt", FileDescriptor::class.java)
    private val unlockpt: Method = osClass.getMethod("unlockpt", FileDescriptor::class.java)
    private val ptsname: Method = osClass.getMethod("ptsname", FileDescriptor::class.java)
    private val osRead: Method = osClass.getMethod("read", FileDescriptor::class.java, ByteArray::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
    private val osWrite: Method = osClass.getMethod("write", FileDescriptor::class.java, ByteArray::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
    private val osClose: Method = osClass.getMethod("close", FileDescriptor::class.java)

    val isRunning: Boolean get() = masterFd != null && process?.isAlive == true

    fun start(initialRows: Int = 40, initialCols: Int = 100) {
        // Open PTY master
        val fd = posixOpenpt.invoke(null, OsConstants.O_RDWR or OsConstants.O_NOCTTY) as FileDescriptor
        masterFd = fd
        grantpt.invoke(null, fd)
        unlockpt.invoke(null, fd)
        val slavePath = ptsname.invoke(null, fd) as String

        // Set window size via ioctl
        setWindowSize(initialRows, initialCols)

        // Start shell with stdio redirected to PTY slave
        val slaveFile = File(slavePath)
        val pb = ProcessBuilder(command, *args)
        pb.redirectInput(ProcessBuilder.Redirect.from(slaveFile))
        pb.redirectOutput(ProcessBuilder.Redirect.to(slaveFile))
        pb.redirectError(ProcessBuilder.Redirect.to(slaveFile))
        val envMap = pb.environment()
        for (e in env) {
            val eq = e.indexOf('=')
            if (eq > 0) envMap[e.substring(0, eq)] = e.substring(eq + 1)
        }
        process = pb.start()
        reading = true
    }

    @Suppress("UNCHECKED_CAST")
    fun setWindowSize(rows: Int, cols: Int) {
        val fd = masterFd ?: return
        try {
            val winsizeClass = Class.forName("android.system.StructWinsize")
            val constructor = winsizeClass.getConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            val winsize = constructor.newInstance(rows, cols)
            val ioctlMethod = osClass.getMethod("ioctl", FileDescriptor::class.java, Int::class.javaPrimitiveType, Any::class.java)
            // TIOCSWINSZ = 0x5414
            ioctlMethod.invoke(null, fd, 0x5414, winsize)
        } catch (_: Exception) {
            // Window size setting may not be available on all devices
        }
    }

    suspend fun read(buffer: ByteArray): Int = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val fd = masterFd ?: return@withContext -1
        try {
            osRead.invoke(null, fd, buffer, 0, buffer.size) as Int
        } catch (_: Exception) {
            -1
        }
    }

    suspend fun write(data: ByteArray) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val fd = masterFd ?: return@withContext
        try {
            osWrite.invoke(null, fd, data, 0, data.size)
        } catch (_: Exception) {
        }
    }

    suspend fun write(text: String) {
        write(text.toByteArray(Charsets.UTF_8))
    }

    fun destroy() {
        reading = false
        try { process?.destroy() } catch (_: Exception) {}
        try { masterFd?.let { osClose.invoke(null, it) } } catch (_: Exception) {}
        masterFd = null
        process = null
    }
}
