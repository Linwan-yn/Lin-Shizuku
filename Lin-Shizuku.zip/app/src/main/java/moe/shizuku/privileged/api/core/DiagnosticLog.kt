package moe.shizuku.privileged.api.core

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 统一诊断日志：全部日志写入 /storage/emulated/0/日志.log（用户可直接用文件管理器打开查看）。
 *
 * App 进程（普通应用 uid）在 Android 11+ 默认无权限写公共存储根目录；
 * 因此：
 *  - 有「所有文件访问」权限时写 /storage/emulated/0/日志.log；
 *  - 无权限时降级写到应用专属外部目录 app_logs/日志.log，并在 UI 中提示。
 * server（app_process，uid 2000）可直接写 /storage/emulated/0/日志.log。
 */
object DiagnosticLog {
    const val PUBLIC_LOG_PATH = "/storage/emulated/0/日志.log"

    private const val MAX_LINES = 3000
    private val lock = Any()
    private var fallbackDir: File? = null

    fun setFallbackDir(dir: File) {
        fallbackDir = dir
    }

    /** 当前实际写日志的文件路径（优先公共路径） */
    fun currentPath(): String {
        return if (canWritePublic()) PUBLIC_LOG_PATH
        else fallbackDir?.let { File(it, "日志.log").absolutePath } ?: PUBLIC_LOG_PATH
    }

    fun canWritePublic(): Boolean {
        return try {
            val f = File(PUBLIC_LOG_PATH)
            if (f.exists()) f.canWrite()
            else {
                val p = f.parentFile
                p != null && (p.exists() || p.mkdirs()) && f.createNewFile() && f.canWrite()
            }
        } catch (_: Throwable) { false }
    }

    /** 追加一行（带时间戳）。诊断日志 UI 已下线，本方法为 no-op，不再生成日志文件。 */
    fun append(line: String) {
        // 已禁用：不再写入 /storage/emulated/0/日志.log
    }

    /** 读取最近 N 行 */
    fun readTail(maxLines: Int = 400): String {
        return try {
            val target = if (canWritePublic()) File(PUBLIC_LOG_PATH)
            else fallbackDir?.let { File(it, "日志.log") }
            if (target == null || !target.exists()) return "（暂无日志）"
            target.readLines().takeLast(maxLines).joinToString("\n")
        } catch (_: Throwable) { "（读取日志失败）" }
    }
}
