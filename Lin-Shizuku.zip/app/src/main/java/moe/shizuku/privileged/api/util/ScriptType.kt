package moe.shizuku.privileged.api.util

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import moe.shizuku.privileged.api.core.ShizukuManager
import java.io.File

/**
 * Script type detection and execution, aligned with the "幻·实验室" spec:
 * - RUN type: normal script, single execute button.
 * - TOGGLE type: contains #on and #off blocks, shows a switch.
 */
object ScriptType {

    fun scriptDir(ctx: Context): File =
        File(ctx.filesDir, "modules").apply { mkdirs() }

    fun isToggle(file: File): Boolean {
        return try {
            val content = file.readText()
            val hasOn = content.lines().any { it.trim().equals("#on", ignoreCase = true) }
            val hasOff = content.lines().any { it.trim().equals("#off", ignoreCase = true) }
            hasOn && hasOff
        } catch (_: Throwable) { false }
    }

    fun extractBlock(file: File, on: Boolean): String {
        return try {
            val lines = file.readLines()
            val block = StringBuilder()
            var inBlock = false
            val marker = if (on) "#on" else "#off"
            val other = if (on) "#off" else "#on"
            for (line in lines) {
                val t = line.trim()
                if (t.equals(marker, ignoreCase = true)) { inBlock = true; continue }
                if (inBlock && t.equals(other, ignoreCase = true)) break
                if (inBlock) block.appendLine(line)
            }
            if (block.isBlank()) file.readText() else block.toString()
        } catch (_: Throwable) { "" }
    }

    suspend fun runToggle(ctx: Context, id: String, on: Boolean): String {
        val file = File(scriptDir(ctx), "$id/run.sh")
        val script = extractBlock(file, on)
        return ShizukuManager.runCommand(script)
    }

    suspend fun runScript(ctx: Context, id: String): String {
        val file = File(scriptDir(ctx), "$id/run.sh")
        return ShizukuManager.runCommand(file.readText())
    }

    fun parseMetadata(file: File): Map<String, String> {
        val meta = mutableMapOf<String, String>()
        try {
            val lines = file.readLines()
            var inMeta = false
            for (line in lines) {
                val t = line.trim()
                if (t == "#---") {
                    if (inMeta) break
                    inMeta = true
                    continue
                }
                if (inMeta && t.startsWith("#")) {
                    val content = t.removePrefix("#").trim()
                    val idx = content.indexOf(':')
                    if (idx > 0) {
                        val key = content.substring(0, idx).trim()
                        val value = content.substring(idx + 1).trim()
                        meta[key] = value
                    }
                }
            }
        } catch (_: Throwable) {}
        return meta
    }
}
