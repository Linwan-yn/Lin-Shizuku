package moe.shizuku.privileged.api.util

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import moe.shizuku.manager.adb.AdbClient
import moe.shizuku.manager.adb.AdbKey
import moe.shizuku.manager.adb.PreferenceAdbKeyStore
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import kotlin.coroutines.resume

object AdbStarter {

    private const val TAG = "AdbStarter"
    private const val SERVICE_TYPE = "_adb-tls-connect._tcp."

    suspend fun startViaAdb(ctx: Context, onOutput: (String) -> Unit): Boolean = withContext(Dispatchers.IO) {
        try {
            // Step 1: Discover and validate port (with retries)
            onOutput("正在发现 ADB 服务...\n")
            var port = 0
            repeat(3) { attempt ->
                val discovered = withTimeoutOrNull(6000) { discoverPort(ctx) } ?: 0
                if (discovered > 0 && isPortListening(discovered)) {
                    port = discovered
                    return@repeat
                }
                if (attempt < 2) {
                    onOutput("端口未就绪，重试 (${attempt + 1}/3)...\n")
                    delay(1500)
                }
            }

            if (port <= 0) {
                onOutput("错误：未找到可用的 ADB 端口\n")
                onOutput("请确认：设置 → 开发者选项 → 无线调试 已开启\n")
                return@withContext false
            }
            onOutput("发现 ADB 端口: $port\n")

            // Step 2: Connect - localhost first (official approach), then WiFi IP
            val prefs = ctx.getSharedPreferences("adb_key", Context.MODE_PRIVATE)
            val key = AdbKey(PreferenceAdbKeyStore(prefs), "shizuku")

            val hosts = listOf("127.0.0.1", "::1", getWifiIp(ctx)).distinct().filter { it.isNotEmpty() }
            var client: AdbClient? = null
            for (host in hosts) {
                try {
                    onOutput("正在连接 $host:$port...\n")
                    val c = AdbClient(host, port, key)
                    c.connect()
                    client = c
                    onOutput("ADB 连接成功 ($host)\n")
                    break
                } catch (_: Throwable) {
                    onOutput("连接 $host 失败\n")
                }
            }
            if (client == null) {
                onOutput("错误：无法连接 ADB 服务\n")
                onOutput("请确认无线调试已开启且已完成配对\n")
                return@withContext false
            }

            // Step 3: 执行 Stellar 直连启动命令（libstellar.so）
            val cmd = Starter.getSdcardCommand(ctx)
            onOutput("执行: $cmd\n")

            val startupLog = StringBuilder()
            client.shellCommand(cmd, { data ->
                val text = String(data)
                startupLog.append(text)
                onOutput(text)
                moe.shizuku.privileged.api.core.ShizukuManager.appendStartupLog(text.trim())
            }, timeoutMs = 15_000)
            client.close()

            val log = startupLog.toString()
            if (log.contains("错误：") || log.contains("权限不足") || log.contains("SELinux")) {
                onOutput("\n错误：启动命令执行失败\n" + (log.trim().lines().lastOrNull() ?: ""))
                return@withContext false
            }
            onOutput("\n启动命令执行完毕\n")
            true
        } catch (e: Throwable) {
            onOutput("错误: ${e.message}\n")
            Log.e(TAG, "startViaAdb failed", e)
            false
        }
    }

    /** Check if a port is actually listening on 127.0.0.1 (same as official AdbMdns) */
    private fun isPortListening(port: Int): Boolean = try {
        ServerSocket().use {
            it.bind(InetSocketAddress("127.0.0.1", port), 1)
            false // bind succeeded = port NOT in use
        }
    } catch (e: IOException) {
        true // bind failed = port IS in use (server listening)
    }

    private fun getWifiIp(ctx: Context): String {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val link = cm.getLinkProperties(cm.activeNetwork)
            link?.linkAddresses?.firstOrNull {
                it.address is java.net.Inet4Address && !it.address.isLoopbackAddress
            }?.address?.hostAddress ?: ""
        } catch (_: Throwable) {
            ""
        }
    }

    private suspend fun discoverPort(ctx: Context): Int = suspendCancellableCoroutine { cont ->
        val nsdManager = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        var resolved = false

        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {}
            override fun onDiscoveryStopped(regType: String) {
                if (!resolved) cont.resume(0)
            }
            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType.contains("adb-tls-connect")) {
                    nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            if (!resolved) {
                                resolved = true
                                cont.resume(serviceInfo.port)
                            }
                        }
                    })
                }
            }
            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(regType: String, errorCode: Int) {
                if (!resolved) cont.resume(0)
            }
            override fun onStopDiscoveryFailed(regType: String, errorCode: Int) {}
        }

        try {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
        } catch (e: Throwable) {
            if (!resolved) cont.resume(0)
        }

        cont.invokeOnCancellation {
            try { nsdManager.stopServiceDiscovery(listener) } catch (_: Throwable) {}
        }
    }
}
