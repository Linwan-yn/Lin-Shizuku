package moe.shizuku.privileged.api.ui.modules

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import moe.shizuku.privileged.api.core.ModuleStore
import moe.shizuku.privileged.api.ui.theme.LinShizukuTheme
import moe.shizuku.privileged.api.util.ActivityTransitions
import java.util.UUID

class ScriptEditActivity : ComponentActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var scriptId: String? = null
    private var scriptName by mutableStateOf("新脚本")
    private var scriptContent by mutableStateOf("")

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/x-sh")
    ) { uri ->
        uri?.let { saveToUri(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        scriptId = intent.getStringExtra("script_id")

        scriptId?.let { id ->
            // 已有脚本：shell 读取内容（存储位于 /data/local/tmp/Lin-Shizuku/module/）
            scope.launch(Dispatchers.IO) {
                val content = ModuleStore.scriptContent(this@ScriptEditActivity, id)
                if (content.isNotBlank()) {
                    val name = Regex("#name:\\s*(.+)").find(content)
                        ?.groupValues?.get(1)?.trim() ?: id
                    scriptName = name
                    scriptContent = content
                }
            }
        } ?: run {
            scriptName = "新脚本"
            scriptContent = "#---\n#name: 新脚本\n#description: \n#---\n\necho \"Hello\"\n"
        }

        setContent {
            LinShizukuTheme {
                EditScreen(
                    name = scriptName,
                    content = scriptContent,
                    onNameChange = { scriptName = it },
                    onContentChange = { scriptContent = it },
                    onBack = { finishWithTransition() },
                    onSave = { saveScript() },
                    onRun = { runScript() },
                    onExport = {
                        exportLauncher.launch("${scriptName.ifBlank { "script" }}.sh")
                    }
                )
            }
        }
    }

    private fun saveScript() {
        val id = scriptId ?: UUID.randomUUID().toString().take(8)
        scope.launch {
            val err = withContext(Dispatchers.IO) {
                ModuleStore.saveScript(this@ScriptEditActivity, id, scriptName, scriptContent)
            }
            if (err == null) {
                scriptId = id
                finishWithTransition()
            } else {
                Toast.makeText(this@ScriptEditActivity, err, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun runScript() {
        val id = scriptId ?: UUID.randomUUID().toString().take(8)
        scope.launch {
            val err = withContext(Dispatchers.IO) {
                ModuleStore.saveScript(this@ScriptEditActivity, id, scriptName, scriptContent)
            }
            if (err != null) {
                Toast.makeText(this@ScriptEditActivity, err, Toast.LENGTH_SHORT).show()
                return@launch
            }
            scriptId = id
            val intent = Intent(this@ScriptEditActivity, OutputActivity::class.java)
            intent.putExtra("script_id", id)
            startActivity(intent)
            ActivityTransitions.overrideForward(this@ScriptEditActivity)
        }
    }

    private fun saveToUri(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(scriptContent.toByteArray()) }
        } catch (_: Throwable) {}
    }

    private fun finishWithTransition() {
        ActivityTransitions.finishWithAnimation(this)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditScreen(
    name: String,
    content: String,
    onNameChange: (String) -> Unit,
    onContentChange: (String) -> Unit,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onRun: () -> Unit,
    onExport: () -> Unit
) {
    val scrollBehavior = TopAppBarDefaults.pinnedScrollBehavior()

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            TopAppBar(
                title = { Text("编辑脚本", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "返回")
                    }
                },
                actions = {
                    IconButton(onClick = onExport) { Icon(Icons.Filled.IosShare, "导出") }
                    IconButton(onClick = onRun) { Icon(Icons.Filled.PlayArrow, "运行") }
                    IconButton(onClick = onSave) { Icon(Icons.Filled.Save, "保存") }
                },
                scrollBehavior = scrollBehavior
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = onNameChange,
                label = { Text("脚本名称") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = content,
                onValueChange = onContentChange,
                label = { Text("脚本内容") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(400.dp),
                textStyle = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                )
            )
            Text(
                "支持 #--- 元数据块；含 #on/#off 自动识别为开关型脚本",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
