package moe.shizuku.privileged.api.util

import android.content.Context
import android.os.Build
import java.io.BufferedReader
import java.io.DataInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.zip.ZipFile

object Starter {

    private var sdcardCommand: String? = null

    /**
     * 返回启动命令。优先采用 Stellar 直连方式：直接执行 APK native 库里的
     * libstellar.so（starter 会自行定位 base.apk 并从 APK 加载 Stellar server）。
     * 若 APK 内 so 不可达（异常安装/旧设备），回退到 start.sh 复制方式。
     */
    fun getSdcardCommand(context: Context): String {
        if (sdcardCommand != null) return sdcardCommand!!
        return try {
            val nativeSo = File(context.applicationInfo.nativeLibraryDir, "libstellar.so")
            if (nativeSo.exists()) {
                sdcardCommand = nativeSo.absolutePath
            } else {
                writeSdcardFiles(context)
            }
            sdcardCommand ?: "sh /sdcard/start.sh"
        } catch (_: Throwable) {
            "sh /sdcard/start.sh"
        }
    }

    fun writeSdcardFiles(context: Context): Boolean {
        return try {
            val filesDir = context.getExternalFilesDir(null) ?: return false
            val dir = filesDir.parentFile ?: return false
            val starter = copyStarter(context, File(dir, "starter"))
            val sh = writeScript(context, File(dir, "start.sh"), starter)
            sdcardCommand = "sh $sh"
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun copyStarter(context: Context, out: File): String {
        val abi = Build.SUPPORTED_ABIS[0]
        val soPath = "lib/$abi/libstellar.so"
        val ai = context.applicationInfo
        val fos = FileOutputStream(out)
        val apk = ZipFile(ai.sourceDir)
        val entries = apk.entries()
        while (entries.hasMoreElements()) {
            val entry = entries.nextElement() ?: break
            if (entry.name != soPath) continue
            val buf = ByteArray(entry.size.toInt())
            val dis = DataInputStream(apk.getInputStream(entry))
            dis.readFully(buf)
            fos.write(buf)
            break
        }
        fos.flush()
        fos.close()
        apk.close()
        return out.absolutePath
    }

    private fun writeScript(context: Context, out: File, starter: String): String {
        if (!out.exists()) out.createNewFile()
        val input = BufferedReader(InputStreamReader(context.resources.openRawResource(
            context.resources.getIdentifier("start", "raw", context.packageName)
        )))
        val os = PrintWriter(out)
        var line: String?
        while (input.readLine().also { line = it } != null) {
            os.println(line!!.replace("%%%STARTER_PATH%%%", starter))
        }
        os.flush()
        os.close()
        input.close()
        return out.absolutePath
    }
}
