package moe.shizuku.privileged.api.util

/**
 * Environment helpers — migrated from Stellar `EnvironmentUtils`.
 */
object EnvironmentUtils {

    /**
     * Read the ADB over TCP port configured via system properties
     * (service.adb.tcp.port / persist.adb.tcp.port). Returns -1 when not set.
     */
    fun getAdbTcpPort(): Int {
        return try {
            val clazz = Class.forName("android.os.SystemProperties")
            val get = clazz.getMethod("getInt", String::class.java, Int::class.javaPrimitiveType)
            var port = get.invoke(null, "service.adb.tcp.port", -1) as Int
            if (port == -1) {
                port = get.invoke(null, "persist.adb.tcp.port", -1) as Int
            }
            port
        } catch (_: Throwable) {
            -1
        }
    }
}
