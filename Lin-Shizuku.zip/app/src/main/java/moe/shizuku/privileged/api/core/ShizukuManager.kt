package moe.shizuku.privileged.api.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import moe.shizuku.privileged.api.data.AppInfo
import moe.shizuku.server.IRemoteProcess
import moe.shizuku.server.IShizukuService
import rikka.shizuku.Shizuku

/**
 * Shizuku service manager.
 * Uses the official rikka.shizuku.Shizuku API for binder management
 * and IShizukuService / IRemoteProcess AIDL for privileged operations.
 */
object ShizukuManager {

    enum class Status { RUNNING, STOPPED, UNKNOWN }

    private const val FLAG_ALLOWED = 1 shl 1
    private const val FLAG_DENIED = 1 shl 2
    private const val MASK_PERMISSION = FLAG_ALLOWED or FLAG_DENIED

    private var serviceBinder: IBinder? = null
    private var serviceConnection: ServiceConnection? = null

    /** Get the Shizuku service interface from the current binder. */
    private fun getService(): IShizukuService? {
        val binder = Shizuku.getBinder() ?: return null
        return try { IShizukuService.Stub.asInterface(binder) } catch (_: Throwable) { null }
    }

    // ---------- Stellar server 双通道运行判断 ----------
    // server 现在是 Stellar（.stellar binder，IStellarService 协议）；同时保留 shizuku 兼容通道（.shizuku binder）。
    // 任一通道存活即视为服务运行。
    fun isStellarRunning(): Boolean = try { roro.stellar.Stellar.pingBinder() } catch (_: Throwable) { false }

    fun isRunningCompat(): Boolean =
        isStellarRunning() || (try { Shizuku.pingBinder() } catch (_: Throwable) { false })

    fun getServerVersionCompat(): Int = try {
        if (isStellarRunning()) roro.stellar.Stellar.version else Shizuku.getVersion()
    } catch (_: Throwable) { -1 }

    fun getServerUidCompat(): Int = try {
        if (isStellarRunning()) roro.stellar.Stellar.uid else Shizuku.getUid()
    } catch (_: Throwable) { -1 }

    fun stopServerCompat() {
        try {
            if (isStellarRunning()) {
                roro.stellar.Stellar.exit()
                return
            }
        } catch (_: Throwable) {}
        try { getService()?.exit() } catch (_: Throwable) {}
    }

    fun getStatus(): Status {
        return try {
            if (isRunningCompat()) Status.RUNNING else {
                if (isShizukuServerRunning()) Status.RUNNING else Status.STOPPED
            }
        } catch (_: Throwable) {
            if (isShizukuServerRunning()) Status.RUNNING else Status.UNKNOWN
        }
    }

    /** Check if shizuku server process exists via pidof / ps. */
    private fun isShizukuServerRunning(): Boolean {
        return try {
            val pidof = Runtime.getRuntime().exec(
                arrayOf("sh", "-c",
                    "pidof shizuku_starter 2>/dev/null || pidof shizuku_server 2>/dev/null || echo ''")
            )
            val pidOutput = pidof.inputStream.bufferedReader().readText().trim()
            pidof.waitFor()
            if (pidOutput.isNotEmpty()) return true

            val proc = Runtime.getRuntime().exec(
                arrayOf("sh", "-c",
                    "ps -A 2>/dev/null | grep -E 'shizuku_starter|shizuku_server' | grep -v grep | wc -l")
            )
            val output = proc.inputStream.bufferedReader().readText().trim()
            proc.waitFor()
            output.isNotEmpty() && output != "0"
        } catch (_: Throwable) {
            false
        }
    }

    fun getServerVersion(): Int = getServerVersionCompat()
    fun getServerUid(): Int = getServerUidCompat()
    fun getSELinuxContext(): String? = try {
        if (isStellarRunning()) roro.stellar.Stellar.sELinuxContext else Shizuku.getSELinuxContext()
    } catch (_: Throwable) { null }

    /**
     * Detect whether a su binary is available on PATH.
     * Migrated from official EnvironmentUtils.isRooted().
     */
    fun isRooted(): Boolean {
        return try {
            System.getenv("PATH")
                ?.split(File.pathSeparatorChar)
                ?.any { File("$it/su").exists() } == true
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Poll until the Shizuku binder becomes available (service started), or the timeout is reached.
     * Returns true if the binder is alive when the call finishes.
     */
    suspend fun waitForBinder(timeoutMs: Long = 12_000): Boolean = withContext(Dispatchers.IO) {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (isRunningCompat()) return@withContext true
            delay(300)
        }
        isRunningCompat()
    }

    fun bindService(ctx: Context, onConnected: () -> Unit = {}, onDisconnected: () -> Unit = {}) {
        try {
            val intent = Intent()
            intent.component = ComponentName(ctx, "moe.shizuku.privileged.api.core.EngineService")
            serviceConnection = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                    serviceBinder = service
                    onConnected()
                }
                override fun onServiceDisconnected(name: ComponentName?) {
                    serviceBinder = null
                    onDisconnected()
                }
            }
            ctx.bindService(intent, serviceConnection!!, Context.BIND_AUTO_CREATE)
        } catch (_: Throwable) {}
    }

    fun unbindService(ctx: Context) {
        serviceConnection?.let { ctx.unbindService(it) }
        serviceConnection = null
        serviceBinder = null
    }

    /**
     * Run a shell command via Shizuku service (privileged: shell or root uid).
     * Returns stdout+stderr combined. Falls back to local sh if Shizuku unavailable.
     */
    /**
     * 流式执行单条命令：逐行回调 stdout（isError=false）/ stderr（isError=true），
     * 长驻脚本的输出也能实时显示；超时自动销毁进程。返回是否正常结束（未超时）。
     */
    suspend fun runCommandStreaming(
        cmd: String,
        onLine: suspend (String, Boolean) -> Unit,
        timeoutMs: Long = 30_000
    ): Boolean = withContext(Dispatchers.IO) {
        // Stellar server 优先（manager 直连 stellar 协议）
        if (isStellarRunning()) {
            try {
                val proc = roro.stellar.Stellar.newProcess(arrayOf("sh", "-c", cmd), null, null)
                return@withContext streamProcess(proc, onLine, timeoutMs)
            } catch (_: Throwable) {}
        }
        // Shizuku 兼容通道
        try {
            val service = getService()
            if (service != null && Shizuku.pingBinder()) {
                val remote = service.newProcess(arrayOf("sh", "-c", cmd), null, null)
                if (remote != null) {
                    val input = ParcelFileDescriptor.AutoCloseInputStream(remote.inputStream)
                    val error = ParcelFileDescriptor.AutoCloseInputStream(remote.errorStream)
                    val outJob = launch { streamLines(input, false, onLine) }
                    val errJob = launch { streamLines(error, true, onLine) }
                    val deadline = System.currentTimeMillis() + timeoutMs
                    var finished = false
                    while (true) {
                        val alive = try { remote.alive() } catch (_: Throwable) { false }
                        if (!alive) { finished = true; break }
                        if (System.currentTimeMillis() >= deadline) break
                        delay(100)
                    }
                    if (!finished) runCatching { remote.destroy() }
                    outJob.join(); errJob.join()
                    return@withContext finished
                }
            }
        } catch (_: Throwable) {}
        false
    }

    private suspend fun streamProcess(
        proc: Process,
        onLine: suspend (String, Boolean) -> Unit,
        timeoutMs: Long
    ): Boolean = coroutineScope {
        val outJob = launch { streamLines(proc.inputStream, false, onLine) }
        val errJob = launch { streamLines(proc.errorStream, true, onLine) }
        // 用 alive() 轮询等待（官方 API 全版本兼容），不用 Process.waitFor(timeout)：
        // StellarRemoteProcess 未实现该方法，低版本设备会抛 NoSuchMethodError 导致命令被误杀
        val deadline = System.currentTimeMillis() + timeoutMs
        var finished = false
        while (true) {
            val alive = try {
                if (proc is roro.stellar.StellarRemoteProcess) proc.alive() else proc.isAlive
            } catch (_: Throwable) {
                false
            }
            if (!alive) { finished = true; break }
            if (System.currentTimeMillis() >= deadline) break
            delay(100)
        }
        if (!finished) runCatching { proc.destroy() }
        outJob.join(); errJob.join()
        finished
    }

    private suspend fun streamLines(
        input: java.io.InputStream,
        isError: Boolean,
        onLine: suspend (String, Boolean) -> Unit
    ) {
        try {
            val reader = input.bufferedReader()
            while (true) {
                val line = reader.readLine() ?: break
                withContext(Dispatchers.Main.immediate) { onLine(line, isError) }
            }
        } catch (_: Throwable) {}
    }

    suspend fun runCommand(cmd: String): String = withContext(Dispatchers.IO) {
        // Stellar server 优先（manager 直连 stellar 协议）
        if (isStellarRunning()) {
            try {
                val proc = roro.stellar.Stellar.newProcess(arrayOf("sh", "-c", cmd), null, null)
                val stdout = proc.inputStream.bufferedReader().readText()
                val stderr = proc.errorStream.bufferedReader().readText()
                proc.waitFor()
                return@withContext (stdout + stderr)
            } catch (_: Throwable) {}
        }
        // Try Shizuku second
        try {
            val service = getService()
            if (service != null && Shizuku.pingBinder()) {
                val remote: IRemoteProcess? = service.newProcess(
                    arrayOf("sh", "-c", cmd), null, null
                )
                if (remote != null) {
                    val stdout = try {
                        ParcelFileDescriptor.AutoCloseInputStream(remote.inputStream)
                            .bufferedReader().readText()
                    } catch (_: Throwable) { "" }
                    val stderr = try {
                        ParcelFileDescriptor.AutoCloseInputStream(remote.errorStream)
                            .bufferedReader().readText()
                    } catch (_: Throwable) { "" }
                    try { remote.waitFor() } catch (_: Throwable) {}
                    return@withContext (stdout + stderr).ifEmpty { "" }
                }
            }
        } catch (_: Throwable) {}

        // Fallback: local sh (unprivileged)
        try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            out + err
        } catch (e: Throwable) {
            "Error: ${e.message}"
        }
    }

    /**
     * Start an interactive sh process. Stellar server 优先（manager 直连 stellar 协议），
     * Shizuku 兼容通道次之。返回 [RemoteShell] 持有 stdin/stdout/stderr。
     */
    fun startRemoteShell(): RemoteShell? {
        // Stellar server 优先
        if (isStellarRunning()) {
            try {
                return RemoteShell.fromProcess(roro.stellar.Stellar.newProcess(arrayOf("sh"), null, null))
            } catch (_: Throwable) {}
        }
        // Shizuku 兼容通道
        return try {
            val service = getService() ?: return null
            if (!Shizuku.pingBinder()) return null
            val remote = service.newProcess(arrayOf("sh"), null, null) ?: return null
            RemoteShell.fromIRemoteProcess(remote)
        } catch (_: Throwable) { null }
    }

    /** Holder for a remote shell process with stdin/stdout/stderr. */
    class RemoteShell private constructor(
        private val out: java.io.OutputStream,
        private val input: java.io.InputStream,
        private val error: java.io.InputStream,
        private val onDestroy: () -> Unit,
        private val onAlive: () -> Boolean
    ) {
        val outputStream: java.io.OutputStream get() = out
        val inputStream: java.io.InputStream get() = input
        val errorStream: java.io.InputStream get() = error
        fun waitFor(): Int = 0
        fun destroy() = onDestroy()
        fun alive(): Boolean = onAlive()

        companion object {
            /** 适配标准 [java.lang.Process]（StellarRemoteProcess 等）。 */
            fun fromProcess(p: Process): RemoteShell = RemoteShell(
                out = p.outputStream,
                input = p.inputStream,
                error = p.errorStream,
                onDestroy = { runCatching { p.destroy() } },
                onAlive = { p.isAlive }
            )

            /** 适配官方 shizuku IRemoteProcess。 */
            fun fromIRemoteProcess(remote: IRemoteProcess): RemoteShell = RemoteShell(
                out = ParcelFileDescriptor.AutoCloseOutputStream(remote.outputStream),
                input = ParcelFileDescriptor.AutoCloseInputStream(remote.inputStream),
                error = ParcelFileDescriptor.AutoCloseInputStream(remote.errorStream),
                onDestroy = { try { remote.destroy() } catch (_: Throwable) {} },
                onAlive = { try { remote.alive() } catch (_: Throwable) { false } }
            )
        }
    }

    suspend fun getShizukuApps(ctx: Context): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val shizukuPerm = "moe.shizuku.manager.permission.API_V23"
        // 与 Stellar / 原版 Shizuku 一致：列出「声明」了 Shizuku API 权限的应用
        // （requestedPermissions 包含），而不是已授予权限的应用 —— 未激活时也能显示列表。
        val packages = try {
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
                .filter { it.requestedPermissions?.contains(shizukuPerm) == true }
                .ifEmpty {
                    // fallback 1：部分系统已删除 requestedPermissions，退回已授予列表
                    val granted = pm.getPackagesHoldingPermissions(arrayOf(shizukuPerm), 0)
                    if (granted.isNotEmpty()) granted
                    else {
                        // fallback 2：授权页列出所有应用（与 Stellar 一致，保证列表非空）
                        pm.getInstalledApplications(PackageManager.GET_META_DATA)
                            .mapNotNull { pi -> pm.getPackageInfo(pi.packageName, 0) }
                    }
                }
        } catch (_: Throwable) {
            try {
                val granted = pm.getPackagesHoldingPermissions(arrayOf(shizukuPerm), 0)
                if (granted.isNotEmpty()) granted
                else pm.getInstalledApplications(PackageManager.GET_META_DATA)
                    .mapNotNull { pi -> pm.getPackageInfo(pi.packageName, 0) }
            } catch (_: Throwable) {
                emptyList()
            }
        }
        packages.mapNotNull { packageInfo ->
            val appInfo = packageInfo.applicationInfo ?: return@mapNotNull null
            val state = getAppPermissionState(appInfo.uid, ctx)
            AppInfo(
                packageName = appInfo.packageName,
                name = pm.getApplicationLabel(appInfo).toString(),
                icon = try { pm.getApplicationIcon(appInfo) } catch (_: Throwable) { null },
                state = state,
                uid = appInfo.uid
            )
        }.sortedBy { it.name.lowercase() }
    }

    suspend fun getAllApps(ctx: Context): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        apps.map { appInfo ->
            val state = getAppPermissionState(appInfo.uid, ctx)
            AppInfo(
                packageName = appInfo.packageName,
                name = pm.getApplicationLabel(appInfo).toString(),
                icon = try { pm.getApplicationIcon(appInfo) } catch (_: Throwable) { null },
                state = state,
                uid = appInfo.uid
            )
        }.sortedBy { it.name.lowercase() }
    }

    /**
     * Permission state: 0=unknown, 1=granted, 2=asking, -1=denied
     *
     * 服务运行时以服务端 flags 为准；服务未运行时回退到本地持久化的授权记录
     * （本应用即 Shizuku 服务端，授权状态本地留存，未激活也能显示真实状态）。
     */
    fun getAppPermissionState(uid: Int, ctx: Context? = null): Int {
        // Stellar server 优先（服务端 configManager 是唯一权威）；shizuku 兼容通道次之；最后本地
        if (isStellarRunning()) {
            try {
                // 优先读 shizuku 兼容权限（大多数兼容应用）。
                // 注意：服务端 StellarService 对 "shizuku" 权限返回 shizuku 位掩码协议
                // （FLAG_GRANTED=2 / FLAG_DENIED=4 / FLAG_ASK=0），不能与 stellar 数值（1/2/0）混用。
                val shizukuFlag = roro.stellar.Stellar.getFlagForUid(uid, roro.stellar.server.shizuku.ShizukuApiConstants.PERMISSION_NAME)
                if (shizukuFlag != 0) {
                    return when (shizukuFlag) {
                        roro.stellar.server.shizuku.ShizukuApiConstants.FLAG_GRANTED -> 1
                        roro.stellar.server.shizuku.ShizukuApiConstants.FLAG_DENIED -> -1
                        else -> 2
                    }
                }
                return when (roro.stellar.Stellar.getFlagForUid(uid, roro.stellar.StellarApiConstants.PERMISSION_STELLAR)) {
                    roro.stellar.server.ConfigManager.FLAG_GRANTED -> 1
                    roro.stellar.server.ConfigManager.FLAG_DENIED -> -1
                    else -> 2
                }
            } catch (_: Throwable) {}
        }
        if (Shizuku.pingBinder()) {
            try {
                val flags = Shizuku.getFlagsForUid(uid, MASK_PERMISSION)
                when {
                    (flags and FLAG_ALLOWED) != 0 -> 1
                    (flags and FLAG_DENIED) != 0 -> -1
                    else -> 2
                }
            } catch (_: Throwable) {
                localAuthPrefs(ctx)?.getInt("uid_$uid", 0) ?: 0
            }
        }
        return localAuthPrefs(ctx)?.getInt("uid_$uid", 0) ?: 0
    }

    /** 本地持久化的授权记录（uid -> 1 允许 / -1 拒绝）。 */
    private fun localAuthPrefs(ctx: Context?): android.content.SharedPreferences? {
        return ctx?.getSharedPreferences("auth_state", Context.MODE_PRIVATE)
    }

    fun setAppPermission(uid: Int, allowed: Boolean, ctx: Context? = null) {
        // 先写本地持久化（服务未运行时也能保留授权决定）
        localAuthPrefs(ctx)?.edit()?.putInt("uid_$uid", if (allowed) 1 else -1)?.apply()
        // Stellar server（configManager 权威）优先：双写 stellar + shizuku 两个权限名，
        // 保证 Stellar 客户端（查 "stellar"）与 Shizuku 兼容应用（查 "shizuku"）都生效。
        // 注意：服务端 StellarService 对 "shizuku" 权限要求 shizuku 位掩码（GRANTED=2/DENIED=4），
        // 对 "stellar" 权限要求 stellar 数值（GRANTED=1/DENIED=2），两者协议不同，不能混用。
        if (isStellarRunning()) {
            val stellarFlag = if (allowed) roro.stellar.server.ConfigManager.FLAG_GRANTED
            else roro.stellar.server.ConfigManager.FLAG_DENIED
            val shizukuFlag = if (allowed) roro.stellar.server.shizuku.ShizukuApiConstants.FLAG_GRANTED
            else roro.stellar.server.shizuku.ShizukuApiConstants.FLAG_DENIED
            try {
                roro.stellar.Stellar.updateFlagForUid(uid, roro.stellar.StellarApiConstants.PERMISSION_STELLAR, stellarFlag)
                roro.stellar.Stellar.updateFlagForUid(uid, roro.stellar.server.shizuku.ShizukuApiConstants.PERMISSION_NAME, shizukuFlag)
                return
            } catch (_: Throwable) {}
        }
        try {
            if (!Shizuku.pingBinder()) return
            val service = getService() ?: return
            val value = if (allowed) FLAG_ALLOWED else FLAG_DENIED
            service.updateFlagsForUid(uid, MASK_PERMISSION, value)
        } catch (_: Throwable) {}
    }

    /** 恢复「询问」状态：清除服务端权限标志与本地持久化记录。 */
    fun setAppPermissionAsk(uid: Int, ctx: Context? = null) {
        localAuthPrefs(ctx)?.edit()?.remove("uid_$uid")?.apply()
        if (isStellarRunning()) {
            try {
                roro.stellar.Stellar.updateFlagForUid(uid, roro.stellar.StellarApiConstants.PERMISSION_STELLAR, roro.stellar.server.ConfigManager.FLAG_ASK)
                roro.stellar.Stellar.updateFlagForUid(uid, roro.stellar.server.shizuku.ShizukuApiConstants.PERMISSION_NAME, roro.stellar.server.shizuku.ShizukuApiConstants.FLAG_ASK)
                return
            } catch (_: Throwable) {}
        }
        try {
            if (!Shizuku.pingBinder()) return
            val service = getService() ?: return
            service.updateFlagsForUid(uid, MASK_PERMISSION, 0)
        } catch (_: Throwable) {}
    }

    /**
     * 将授权请求弹窗的用户决定回复给服务端（官方 server 等待的
     * dispatchPermissionConfirmationResult 回调）。
     */
    fun dispatchPermissionResult(
        uid: Int, pid: Int, requestCode: Int, allowed: Boolean, onetime: Boolean,
        permission: String = "shizuku"
    ) {
        // Stellar server 优先（按请求的权限名回复，保证 shizuku/stellar 都正确）
        if (isStellarRunning()) {
            try {
                roro.stellar.Stellar.dispatchPermissionConfirmationResult(
                    uid, pid, requestCode, allowed, onetime, permission
                )
                return
            } catch (_: Throwable) {}
        }
        try {
            val service = getService() ?: return
            val data = android.os.Bundle().apply {
                putBoolean(
                    rikka.shizuku.ShizukuApiConstants.REQUEST_PERMISSION_REPLY_ALLOWED,
                    allowed
                )
                putBoolean(
                    rikka.shizuku.ShizukuApiConstants.REQUEST_PERMISSION_REPLY_IS_ONETIME,
                    onetime
                )
            }
            service.dispatchPermissionConfirmationResult(uid, pid, requestCode, data)
        } catch (_: Throwable) {}
    }

    suspend fun getAuthorizedCount(ctx: Context): Int = withContext(Dispatchers.IO) {
        try {
            // 计数「本地已允许（ALLOWED）」的应用数，不依赖 shizuku/stellar binder 与系统权限扫描
            val prefs = localAuthPrefs(ctx) ?: return@withContext 0
            prefs.all.values.count { it is Int && it == 1 }
        } catch (_: Throwable) { 0 }
    }

    /**
     * Start Shizuku via root (su).
     * Returns the console output from the start script.
     */
    suspend fun startService(ctx: Context): String = withContext(Dispatchers.IO) {
        if (!isRooted()) {
            return@withContext "错误：未检测到 su，无法以 root 启动。\n请确认设备已获取 root 且 su 可用（如 Magisk）。"
        }
        try {
            val cmd = moe.shizuku.privileged.api.util.Starter.getSdcardCommand(ctx)
            appendStartupLog("Root 启动命令: $cmd")
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = proc.inputStream.bufferedReader().readText()
            val err = proc.errorStream.bufferedReader().readText()
            proc.waitFor()
            var result = (out + err).ifEmpty { "启动命令已执行（无输出）" }
            result.lines().forEach { appendStartupLog(it) }
            // 拉取服务端内部日志，便于定位 binder 分发失败原因
            if (!result.contains("进程号") && !result.contains("正常退出")) {
                try {
                    val logProc = Runtime.getRuntime().exec(arrayOf("su", "-c", "echo \"── 服务端日志(/data/local/tmp) ──\"; cat /data/local/tmp/stellar_server.log 2>/dev/null | tail -60; echo \"── 服务端日志(公共) ──\"; cat /storage/emulated/0/日志.log 2>/dev/null | tail -60"))
                    val logOut = logProc.inputStream.bufferedReader().readText()
                    logProc.waitFor()
                    if (logOut.isNotBlank()) {
                        result += "\n\n── 服务端日志 ──\n" + logOut
                        logOut.lines().forEach { appendStartupLog("服务端日志: $it") }
                    }
                } catch (_: Throwable) {}
            }
            result
        } catch (e: Throwable) {
            appendStartupLog("Root 启动异常: ${e.message ?: e.javaClass.simpleName}")
            "启动失败: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    @OptIn(kotlinx.coroutines.DelicateCoroutinesApi::class)
    fun startService(ctx: Context, callback: (String) -> Unit) {
        GlobalScope.launch(Dispatchers.IO) {
            val result = startService(ctx)
            withContext(Dispatchers.Main) { callback(result) }
        }
    }

    fun stopService() {
        stopServerCompat()
    }

    // ---------- 启动诊断日志 ----------
    private val startupLog = java.util.ArrayDeque<String>()

    /** 追加一条启动日志（时间戳 + 内容），全局静态可访问（无线调试/ADB 路径也可写入）。
     *  同时写入统一日志文件 /storage/emulated/0/日志.log */
    fun appendStartupLog(line: String) {
        synchronized(startupLog) {
            startupLog.addLast(java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault())
                .format(java.util.Date()) + " " + line)
            while (startupLog.size > 200) startupLog.removeFirst()
        }
        DiagnosticLog.append("[启动] " + line)
    }

    fun getStartupLog(): String = synchronized(startupLog) { startupLog.joinToString("\n") }
}
