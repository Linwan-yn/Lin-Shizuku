package moe.shizuku.privileged.api.ui.widget

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/**
 * Floating capsule bottom navigation bar with real backdrop blur.
 * Features: smooth pill indicator slide, press-scale feedback, ripple, haptic tick.
 */
@Composable
fun LiquidGlassBottomBar(
    items: List<GlassNavItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    glassEnabled: Boolean = true
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    // 关闭液态玻璃时的底色：跟随当前主题（浅色=浅色底，深色=深色底）
    val solidBackground = MaterialTheme.colorScheme.surface.toArgb()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 2.dp)
    ) {
        // 磨砂玻璃模糊层：AndroidView setBackgroundBlurRadius = 平台级背景模糊(BlurEffect)
        // 仅绘制胶囊本体，无外围扩展色块；clip(CircleShape) 限制模糊在胶囊边界内
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(CircleShape),
            factory = { context ->
                android.view.View(context).apply {
                    if (glassEnabled) {
                        setBackgroundColor(
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                android.graphics.Color.argb(70, 18, 18, 24)
                            } else {
                                android.graphics.Color.argb(200, 28, 28, 32)
                            }
                        )
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            try {
                                val method = android.view.View::class.java
                                    .getMethod("setBackgroundBlurRadius", Int::class.javaPrimitiveType)
                                method.invoke(this, 80)
                            } catch (_: Throwable) {}
                        }
                    } else {
                        // 关闭液态玻璃：主题表面色不透光底
                        setBackgroundColor(solidBackground)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            try {
                                val method = android.view.View::class.java
                                    .getMethod("setBackgroundBlurRadius", Int::class.javaPrimitiveType)
                                method.invoke(this, 0)
                            } catch (_: Throwable) {}
                        }
                    }
                }
            },
            update = { view ->
                if (glassEnabled) {
                    view.setBackgroundColor(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            android.graphics.Color.argb(70, 18, 18, 24)
                        } else {
                            android.graphics.Color.argb(200, 28, 28, 32)
                        }
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            val method = android.view.View::class.java
                                .getMethod("setBackgroundBlurRadius", Int::class.javaPrimitiveType)
                            method.invoke(view, 80)
                        } catch (_: Throwable) {}
                    }
                } else {
                    view.setBackgroundColor(solidBackground)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        try {
                            val method = android.view.View::class.java
                                .getMethod("setBackgroundBlurRadius", Int::class.javaPrimitiveType)
                            method.invoke(view, 0)
                        } catch (_: Throwable) {}
                    }
                }
            }
        )

        // 胶囊细玻璃边缘（胶囊本体的边框，非外围扩展色块）
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .clip(CircleShape)
                .border(
                    width = 0.8.dp,
                    // 描边跟随主题：浅色模式深色边（可见），深色模式浅色边
                    color = onSurface.copy(alpha = 0.15f),
                    shape = CircleShape
                )
        )

        // 导航图标文字层
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(66.dp)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { index, item ->
                GlassNavItem(
                    icon = item.icon,
                    label = item.label,
                    selected = index == selectedIndex,
                    primaryColor = primaryColor,
                    onSurface = onSurface,
                    onClick = { onSelect(index) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun GlassNavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    primaryColor: Color,
    onSurface: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val view = LocalView.current

    val alpha by animateFloatAsState(
        targetValue = if (selected) 1f else 0.55f,
        animationSpec = tween(durationMillis = 200),
        label = "navAlpha"
    )
    val iconScale by animateFloatAsState(
        targetValue = when {
            pressed -> 0.88f
            selected -> 1.12f
            else -> 1f
        },
        animationSpec = tween(durationMillis = 150),
        label = "navIconScale"
    )
    val pillScale by animateFloatAsState(
        targetValue = if (selected) 1f else 0.6f,
        animationSpec = tween(durationMillis = 250),
        label = "navPillScale"
    )
    val pillAlpha by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = tween(durationMillis = 200),
        label = "navPillAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = rememberRipple(
                    bounded = false,
                    radius = 28.dp,
                    color = primaryColor
                ),
                onClick = {
                    // Haptic tick on selection
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        view.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    }
                    onClick()
                }
            )
            .alpha(alpha),
        contentAlignment = Alignment.Center
    ) {
        // Selected pill — liquid glass effect: semi-transparent tint + top highlight + glass edge
        if (selected || pillAlpha > 0.01f) {
            Box(
                modifier = Modifier
                    .height(54.dp)
                    .width(76.dp)
                    .scale(pillScale)
                    .alpha(pillAlpha)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.38f),
                                primaryColor.copy(alpha = 0.18f),
                            )
                        )
                    )
                    .border(
                        width = 0.8.dp,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.35f),
                                Color.White.copy(alpha = 0.04f),
                            )
                        ),
                        shape = CircleShape
                    )
            )
        }
        // Icon on top, label below
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(vertical = 6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) Color.White else onSurface,
                modifier = Modifier
                    .size(24.dp)
                    .scale(iconScale)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = if (selected) Color.White else onSurface,
                fontSize = 11.sp,
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

data class GlassNavItem(
    val icon: ImageVector,
    val label: String
)
