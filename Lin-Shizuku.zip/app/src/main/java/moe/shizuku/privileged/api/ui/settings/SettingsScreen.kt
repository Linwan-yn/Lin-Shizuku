package moe.shizuku.privileged.api.ui.settings

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import moe.shizuku.privileged.api.core.AppThemeState
import moe.shizuku.privileged.api.core.Prefs
import moe.shizuku.privileged.api.ui.browser.BrowserActivity
import moe.shizuku.privileged.api.ui.widget.pressClickable
import moe.shizuku.privileged.api.util.ActivityTransitions
import moe.shizuku.privileged.api.util.SystemSettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onOpenBattery: () -> Unit = {}, onOpenApps: () -> Unit = {}) {
    val ctx = LocalContext.current
    val scrollState = rememberSaveable(saver = ScrollState.Saver) { ScrollState(0) }

    // 所有开关/下拉框直接以 Prefs 真实值初始化：重建（recreate）后立即显示
    // 真实状态，避免先显示默认值再异步同步造成的"关→开"动画。
    var bootStart by remember { mutableStateOf(Prefs.startOnBoot) }
    var wlanAutoStart by remember { mutableStateOf(Prefs.wlanAutoStart) }
    var darkModeOption by remember { mutableStateOf(Prefs.darkModeOption) }
    var amoled by remember { mutableStateOf(Prefs.amoled) }
    var dynamicColor by remember { mutableStateOf(Prefs.dynamicColor) }
    var liquidGlass by remember { mutableStateOf(Prefs.glassEnabled) }
    var hideRecents by remember { mutableStateOf(Prefs.hideRecents) }
    var highRefresh by remember { mutableStateOf(Prefs.highRefresh) }
    var tcpMode by remember { mutableStateOf(Prefs.tcpMode) }
    var tcpPort by remember { mutableStateOf(Prefs.tcpPort) }
    var watchdog by remember { mutableStateOf(Prefs.watchdog) }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = 80.dp)
    ) {
        Text(
            "设置",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(16.dp))

        // === 启动程序 ===
        SectionHeader("启动程序")
        SettingToggle(
            title = "开机启动（Root）",
            subtitle = "已 Root 设备开机后自动启动 Shizuku 服务",
            checked = bootStart,
            onCheckedChange = {
                bootStart = it
                Prefs.startOnBoot = it
            }
        )
        SettingToggle(
            title = "可信 WLAN 自动启动",
            subtitle = "连接可信 WLAN 时自动启动（Android 13+）",
            checked = wlanAutoStart,
            onCheckedChange = {
                wlanAutoStart = it
                Prefs.wlanAutoStart = it
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // === 界面外观 ===
        SectionHeader("界面外观")
        SettingSelector(
            title = "夜间模式",
            subtitle = "选择深色主题触发方式",
            options = listOf("跟随系统", "总是关闭", "总是开启"),
            selected = darkModeOption,
            onSelect = {
                darkModeOption = it
                Prefs.darkModeOption = it
                AppThemeState.darkModeOption.value = it
            }
        )
        val darkThemeDisabled = darkModeOption == "总是关闭"
        SettingToggle(
            title = "黑色夜间主题",
            subtitle = if (darkThemeDisabled) "需启用夜间模式（深色主题）后生效" else "夜间模式启用时使用纯黑背景（AMOLED）",
            checked = amoled,
            enabled = !darkThemeDisabled,
            onCheckedChange = {
                amoled = it
                Prefs.amoled = it
                AppThemeState.amoled.value = it
            }
        )
        SettingToggle(
            title = "使用系统主题颜色",
            subtitle = "Android 12+ 跟随壁纸动态取色",
            checked = dynamicColor,
            onCheckedChange = {
                dynamicColor = it
                Prefs.dynamicColor = it
                AppThemeState.dynamicColor.value = it
            }
        )
        SettingToggle(
            title = "液态玻璃效果",
            subtitle = "底部导航栏启用液态玻璃材质；关闭为不透光底色",
            checked = liquidGlass,
            onCheckedChange = {
                liquidGlass = it
                Prefs.glassEnabled = it
                AppThemeState.glassEnabled.value = it
            }
        )

        Spacer(modifier = Modifier.height(20.dp))


        // === 增强功能 ===
        SectionHeader("增强功能")
        SettingToggle(
            title = "隐藏后台",
            subtitle = "在最近任务列表中完全隐藏本应用，进程继续后台运行",
            checked = hideRecents,
            onCheckedChange = {
                hideRecents = it
                Prefs.hideRecents = it
                SystemSettings.applySystem(ctx)
            }
        )
        SettingToggle(
            title = "高刷新率",
            subtitle = "自动选择设备支持的最高屏幕刷新率（60/90/120/144/165/185/240Hz 及更高）",
            checked = highRefresh,
            onCheckedChange = {
                highRefresh = it
                Prefs.highRefresh = it
                SystemSettings.applySystem(ctx)
            }
        )
        SettingToggle(
            title = "TCP 模式",
            subtitle = "无线调试启动后把 ADB 切换到固定端口，之后无需 WiFi / 无线调试也可重启服务（脱离 WiFi 保持权限）",
            checked = tcpMode,
            onCheckedChange = {
                tcpMode = it
                Prefs.tcpMode = it
            }
        )
        if (tcpMode) {
            SettingSelector(
                title = "TCP 端口",
                subtitle = "adbd 固定监听端口，重启后无需 WiFi 即可通过 127.0.0.1 连接",
                options = listOf("5555", "6666", "7777", "8888"),
                selected = tcpPort.toString(),
                onSelect = {
                    tcpPort = it.toInt()
                    Prefs.tcpPort = it.toInt()
                }
            )
        }
        SettingToggle(
            title = "崩溃自动恢复",
            subtitle = "服务进程异常退出后自动重新启动（Root 设备）",
            checked = watchdog,
            onCheckedChange = {
                watchdog = it
                Prefs.watchdog = it
            }
        )

        Spacer(modifier = Modifier.height(20.dp))

        // === 通知与电池 ===
        SectionHeader("通知与电池")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .pressClickable { onOpenBattery() }
                .padding(vertical = 14.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("电池优化白名单", fontWeight = FontWeight.Medium, fontSize = 16.sp)
                Text(
                    "加入白名单，防止后台被系统清理",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // === 关于 ===
        SectionHeader("关于")
        Text(
            "Lin-Shizuku 1.0.0",
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        Text(
            "基于 Shizuku 13.5.4 与 Sui 并参考 Stellar 深度定制。",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = { openBrowser(ctx, "https://shizuku.rikka.app/zh-hans/") },
                modifier = Modifier.weight(1f)
            ) { Text("Shizuku", fontSize = 13.sp) }
            OutlinedButton(
                onClick = { openBrowser(ctx, "https://github.com/RikkaApps/Shizuku") },
                modifier = Modifier.weight(1f)
            ) { Text("源码", fontSize = 13.sp) }

        }
    }
}

private fun openBrowser(ctx: android.content.Context, url: String) {
    val intent = Intent(ctx, BrowserActivity::class.java)
    intent.putExtra("url", url)
    ctx.startActivity(intent)
    (ctx as? android.app.Activity)?.let { ActivityTransitions.overrideForward(it) }
}

@Composable
private fun SectionHeader(title: String) {
    Column {
        Text(
            title,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )
        HorizontalDivider(
            modifier = Modifier.padding(top = 6.dp, bottom = 4.dp),
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)
        )
    }
}

@Composable
private fun SettingToggle(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                title,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp,
                color = if (enabled) Color.Unspecified else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
            )
            Text(
                subtitle,
                fontSize = 13.sp,
                color = if (enabled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                lineHeight = 18.sp
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked && enabled,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.primary,
                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingSelector(
    title: String,
    subtitle: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var showSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .pressClickable { showSheet = true }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, fontSize = 16.sp)
            Text(
                subtitle,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            selected,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(end = 4.dp)
        )
        Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (showSheet) {
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            sheetState = sheetState
        ) {
            Column(modifier = Modifier.padding(bottom = 24.dp)) {
                Text(
                    title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
                options.forEach { option ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .pressClickable {
                                onSelect(option)
                                showSheet = false
                            }
                            .padding(horizontal = 24.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            option,
                            fontSize = 16.sp,
                            modifier = Modifier.weight(1f),
                            color = if (option == selected)
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.onSurface
                        )
                        if (option == selected) {
                            Icon(
                                Icons.Filled.Done,
                                null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}
