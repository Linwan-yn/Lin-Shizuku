package moe.shizuku.privileged.api.data

import java.io.File

data class ScriptModule(
    val id: String,
    val name: String,
    val author: String = "",
    val description: String = "",
    val brand: String = "",
    val path: File,
    val isToggle: Boolean = false,
    var enabled: Boolean = false
)

data class LinModule(
    val id: String,
    val name: String,
    val description: String = "",
    val version: String = "",
    val author: String = "",
    val path: File,
    var enabled: Boolean = false,
    val webui: String = "",
    val actionScript: String = ""
)
