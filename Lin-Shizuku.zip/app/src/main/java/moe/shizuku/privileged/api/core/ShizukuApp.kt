package moe.shizuku.privileged.api.core

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Environment
import android.os.LocaleList
import java.util.Locale
import moe.shizuku.privileged.api.util.CrashHandler
import org.conscrypt.Conscrypt
import java.security.Security

class ShizukuApp : Application() {

    override fun attachBaseContext(base: Context) {
        // 强制简体中文：不跟随系统、不支持切换
        val wrapped = try {
            val loc = Locale.SIMPLIFIED_CHINESE
            Locale.setDefault(loc)
            val cfg = Configuration(base.resources.configuration)
            if (Build.VERSION.SDK_INT >= 24) {
                cfg.setLocales(LocaleList(loc))
            } else {
                @Suppress("DEPRECATION")
                cfg.locale = loc
            }
            base.createConfigurationContext(cfg)
        } catch (_: Throwable) {
            base
        }
        super.attachBaseContext(wrapped)
    }

    override fun onCreate() {
        super.onCreate()
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
        instance = this
        // Install crash handler BEFORE any other init
        CrashHandler.install(this)
        try {
            Prefs.init(this)
        } catch (_: Throwable) {}
    }

    companion object {
        lateinit var instance: ShizukuApp
            private set
    }
}
