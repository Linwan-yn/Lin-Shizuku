package moe.shizuku.privileged.api.ui.widget

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/**
 * A glass-style card with optional click handling.
 * When [onClick] is provided, the card gets press-scale + ripple feedback.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val surface = MaterialTheme.colorScheme.surface
    val base = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(20.dp))
        .background(
            Brush.verticalGradient(
                colors = listOf(
                    surface.copy(alpha = 0.9f),
                    surface.copy(alpha = 0.75f)
                )
            )
        )
        .padding(16.dp)

    val finalModifier = if (onClick != null) {
        base.pressClickable(role = Role.Button, onClick = onClick)
    } else {
        base
    }

    Column(modifier = modifier.then(finalModifier)) {
        content()
    }
}
