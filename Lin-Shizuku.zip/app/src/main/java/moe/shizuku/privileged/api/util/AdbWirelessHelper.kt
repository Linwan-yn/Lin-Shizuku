package moe.shizuku.privileged.api.util

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import moe.shizuku.manager.adb.AdbClient
import moe.shizuku.manager.adb.AdbKey
import moe.shizuku.manager.adb.AdbKeyException
import moe.shizuku.manager.adb.PreferenceAdbKeyStore
import java.io.EOFException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException

/**
 * Wireless debugging helper — migrated from Stellar `AdbWirelessHelper`.
 *
 * Provides:
 *  - [hasAdbPermission]: probe whether the ADB server is reachable with our key
 *    (i.e. the device has been paired already).
 *  - [startShizukuViaAdb]: wait for the port, connect over ADB and run the
 *    starter script, streaming the console output back to the UI.
 */
class AdbWirelessHelper {

    private fun key(ctx: Context): AdbKey = AdbKey(
        PreferenceAdbKeyStore(ctx.getSharedPreferences("adb_key", Context.MODE_PRIVATE)),
        "shizuku"
    )

    /** True if we can establish an ADB connection (already paired). */
    fun hasAdbPermission(ctx: Context, host: String, port: Int): Boolean {
        if (port !in 1..65535) return false
        val key = try { key(ctx) } catch (_: Throwable) { return false }
        return try {
            AdbClient(host, port, key).use { it.connect() }
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun waitForAdbPortAvailable(host: String, port: Int, timeoutMs: Long): Boolean {
        val intervalMs = 500L
        var elapsed = 0L
        while (elapsed < timeoutMs) {
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), 2000)
                }
                return true
            } catch (_: Exception) {
                elapsed += intervalMs
                try { Thread.sleep(intervalMs) } catch (_: InterruptedException) {}
            }
        }
        return false
    }

    /**
     * Connect to the wireless ADB server and run the starter command.
     *
     * TCP mode (thedjchi feature): when [tcpMode] is on and the detected port
     * differs from [tcpPort], the adbd daemon is first switched to a fixed TCP
     * port via the `tcpip:<port>` transport command, then reconnected on that
     * port to start the service. After the first successful start, Shizuku can
     * be restarted over 127.0.0.1 even with Wi-Fi / wireless debugging off.
     *
     * [onOutput] receives raw chunks of the shell output (called on an IO thread).
     * [onError] is invoked when the connection or the command fails.
     * [onSuccess] is invoked when the shell stream finished (EOFException is normal:
     * the server process has forked and the shell exited).
     */
    fun startShizukuViaAdb(
        ctx: Context,
        host: String,
        port: Int,
        coroutineScope: CoroutineScope,
        onOutput: (String) -> Unit,
        onError: (Throwable) -> Unit,
        onSuccess: () -> Unit = {},
        tcpMode: Boolean = false,
        tcpPort: Int = 5555
    ) {
        coroutineScope.launch(Dispatchers.IO) {
            try {
                val key = try {
                    key(ctx)
                } catch (e: Throwable) {
                    onError(AdbKeyException(e))
                    return@launch
                }

                if (!waitForAdbPortAvailable(host, port, timeoutMs = 15_000L)) {
                    onError(SocketTimeoutException("等待 ADB 端口 $port 可用超时"))
                    return@launch
                }

                var activePort = port

                // TCP mode: switch adbd to a fixed port so Wi-Fi is no longer needed.
                if (tcpMode && activePort != tcpPort) {
                    onOutput("TCP 模式：正在切换 adbd 到固定端口 $tcpPort...\n")
                    try {
                        AdbClient(host, activePort, key).use { client ->
                            client.connect()
                            // adbd restarts itself — EOF / connection reset is expected.
                            try {
                                client.command("tcpip:$tcpPort")
                            } catch (_: EOFException) {
                            } catch (_: SocketException) {
                            }
                        }
                    } catch (_: Throwable) {
                        // fall through; if the switch failed we simply continue on
                        // the original port below
                    }

                    if (waitForAdbPortAvailable(host, tcpPort, timeoutMs = 10_000L)) {
                        activePort = tcpPort
                        onOutput("TCP 模式已启用（固定端口 $tcpPort），之后无需 WiFi 也可重启服务\n")
                    } else {
                        onOutput("TCP 模式切换超时，继续使用端口 $activePort\n")
                    }
                }

                val startupLog = StringBuilder()
                try {
                    AdbClient(host, activePort, key).use { client ->
                        client.connect()
                        val cmd = Starter.getSdcardCommand(ctx)
                        client.shellCommand(cmd, { chunk ->
                            val text = String(chunk)
                            startupLog.append(text)
                            onOutput(text)
                            moe.shizuku.privileged.api.core.ShizukuManager.appendStartupLog(text.trim())
                        }, timeoutMs = 15_000)
                        // 拉取服务端内部日志（/data/local/tmp/stellar_server.log），让启动失败原因可见
                        runCatching {
                            client.shellCommand(
                                "echo \"── 服务端日志(/data/local/tmp) ──\"; cat /data/local/tmp/stellar_server.log 2>/dev/null | tail -60; echo \"── 服务端日志(公共) ──\"; cat /storage/emulated/0/日志.log 2>/dev/null | tail -60",
                                { chunk ->
                                    val text = String(chunk)
                                    onOutput("── 服务端日志 ──\n" + text)
                                    moe.shizuku.privileged.api.core.ShizukuManager.appendStartupLog("服务端日志: " + text.trim())
                                },
                                timeoutMs = 8_000
                            )
                        }
                        // Turn off the wireless-debugging UI switch after a
                        // successful start; the fixed TCP port keeps serving.
                        if (activePort == tcpPort && tcpMode) {
                            runCatching {
                                client.shellCommand("settings put global adb_wifi_enabled 0", null)
                            }
                        }
                    }
                } catch (_: EOFException) {
                    // shell stream closed — the server has forked, this is normal
                } catch (e: Throwable) {
                    onError(e)
                    return@launch
                }

                // 校验 starter 输出：错误/权限不足 → 失败；成功标志（正常退出/进程号）→ 成功
                val log = startupLog.toString()
                if (log.contains("错误：") || log.contains("权限不足") || log.contains("SELinux")) {
                    onError(RuntimeException(log.trim().lines().lastOrNull() ?: "启动失败"))
                    return@launch
                }
                if (log.isNotEmpty() && !log.contains("正常退出") && !log.contains("进程号")) {
                    // 有输出但既无成功也无明确错误（如超时未完成），保守提示
                    onOutput("启动命令已发出，正在等待服务 Binder 就绪...\n")
                }
                onSuccess()
            } catch (e: Throwable) {
                onError(e)
            }
        }
    }
}
