package moe.shizuku.privileged.api.util

import android.app.Activity
import android.content.Context
import moe.shizuku.privileged.api.core.Prefs

/**
 * 即时应用需要在 Activity 级执行的系统设置（隐藏后台、高刷新率）。
 * MainActivity.onCreate 与设置页开关切换共用，保证切换即时生效且无需重建 Activity。
 */
object SystemSettings {

    fun applySystem(ctx: Context) {
        if (ctx !is Activity) return

        // 隐藏后台：从最近任务列表排除本应用；关闭时恢复显示
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            am.appTasks.forEach { it.setExcludeFromRecents(Prefs.hideRecents) }
        } catch (_: Throwable) {}

        // 高刷新率：优先选择设备支持的最高刷新率；关闭时恢复默认
        try {
            val lp = ctx.window.attributes
            if (Prefs.highRefresh) {
                val modes = ctx.window.windowManager.defaultDisplay.supportedModes
                val best = modes.maxByOrNull { it.refreshRate }
                if (best != null) {
                    lp.preferredDisplayModeId = best.modeId
                    lp.preferredRefreshRate = best.refreshRate
                    ctx.window.attributes = lp
                }
            } else {
                lp.preferredDisplayModeId = 0
                lp.preferredRefreshRate = 0f
                ctx.window.attributes = lp
            }
        } catch (_: Throwable) {}
    }
}
