package moe.shizuku.privileged.api.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Process

object RestartUtil {
    fun restart(context: Context) {
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        intent?.addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP or
            Intent.FLAG_ACTIVITY_NEW_TASK or
            Intent.FLAG_ACTIVITY_CLEAR_TASK
        )
        context.startActivity(intent)
        if (context is Activity) context.finishAffinity()
        Process.killProcess(Process.myPid())
    }
}
