package moe.shizuku.privileged.api.ui.terminal

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

data class TerminalLine(val text: String, val isError: Boolean = false)

/**
 * 终端全局缓冲：内容与执行状态保存在进程级单例中，
 * 页面切换不销毁；应用进程完全退出才自然清空；手动清空走 [clear]。
 */
object TerminalBuffer {
    val lines = mutableStateListOf<TerminalLine>().apply {
        add(TerminalLine("Lin-Shizuku — 终端"))
        add(TerminalLine("输入命令回车执行（sh / root 权限）。"))
    }

    /** 是否有命令正在执行（跨页面保留）。 */
    var running by mutableStateOf(false)

    /** 命令执行协程使用进程级作用域，切换页面不中断执行。 */
    val execScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    fun appendLine(text: String, isError: Boolean = false) {
        lines.add(TerminalLine(text, isError))
        // 达到 2 倍上限才批量裁剪一次（clear + addAll 为单次批量通知）
        if (lines.size > MAX_LINES * 2) {
            val keep = lines.subList(lines.size - MAX_LINES, lines.size).toList()
            lines.clear()
            lines.addAll(keep)
        }
    }

    /** 手动清空。 */
    fun clear() {
        lines.clear()
    }

    private const val MAX_LINES = 2000
}
