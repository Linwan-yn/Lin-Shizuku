package moe.shizuku.privileged.api.ui.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import moe.shizuku.privileged.api.core.ShizukuManager

@Composable
fun TerminalScreen() {
    val scope = rememberCoroutineScope()
    // 内容与执行状态提升到进程级全局缓冲：切换页面不清空，完全退出/手动清空才清空
    val lines = TerminalBuffer.lines
    var input by remember { mutableStateOf("") }
    val running = TerminalBuffer.running
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current
    var terminalHeight by remember { mutableStateOf(0) }

    LaunchedEffect(terminalHeight) {
        if (terminalHeight > 0 && lines.isNotEmpty()) {
            kotlinx.coroutines.delay(30)
            listState.scrollToItem(lines.size)
        }
    }

    // 滚动节流：按 20 行为粒度触发，避免每行一次滚动布局拖垮主线程
    LaunchedEffect(lines.size / 20, input) {
        if (lines.isNotEmpty()) listState.scrollToItem(lines.size)
    }

    // 直接执行模式：每条命令通过 Shizuku 特权通道（shell/root）运行一次，输出流式实时显示
    // 执行协程挂在进程级作用域，切换页面不中断执行、不清空内容
    fun sendInput() {
        val cmd = input
        if (cmd.isBlank()) return
        TerminalBuffer.appendLine("$ $cmd")
        input = ""
        if (running) return
        TerminalBuffer.running = true
        TerminalBuffer.execScope.launch {
            try {
                withTimeout(45_000) {
                    ShizukuManager.runCommandStreaming(
                        cmd,
                        onLine = { line, isErr -> TerminalBuffer.appendLine(line, isErr) }
                    )
                }
            } catch (_: Throwable) {
                TerminalBuffer.appendLine("命令执行超时或失败", isError = true)
            }
            TerminalBuffer.running = false
        }
    }

    fun clearTerminal() {
        TerminalBuffer.clear()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "终端",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { clearTerminal() }) {
                Text("清空", fontSize = 13.sp)
            }
        }

        // Terminal — entire area is a transparent BasicTextField, tap anywhere to type
        BasicTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .focusRequester(focusRequester)
                .onGloballyPositioned { terminalHeight = it.size.height }
                .onFocusChanged {
                    if (it.isFocused) {
                        scope.launch {
                            kotlinx.coroutines.delay(30)
                            if (lines.isNotEmpty()) listState.scrollToItem(lines.size)
                        }
                    }
                },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(
                onSend = { sendInput() }
            ),
            singleLine = true,
            cursorBrush = Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
            decorationBox = {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF1A1A24), Color(0xFF0D0D12))
                            )
                        )
                        .border(
                            width = 0.5.dp,
                            color = Color.White.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(14.dp)
                        )
                ) {
                    // Terminal title bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFF5F57))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEBC2E))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF28C840))
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            "sh",
                            color = Color(0xFF666680),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        if (running) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "执行中…",
                                color = Color(0xFF4CAF50),
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    // Terminal output
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(lines) { line ->
                                Text(
                                    text = line.text,
                                    color = if (line.isError) Color(0xFFFF6B6B) else Color(0xFFB8C0D0),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(vertical = 0.5.dp)
                                )
                            }
                            // Current input line（执行中隐藏输入，避免状态矛盾）
                            item {
                                if (running) {
                                    Text(
                                        "… 执行中，请稍候",
                                        color = Color(0xFF666680),
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 13.sp
                                    )
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            "$ ",
                                            color = Color(0xFF4CAF50),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            input,
                                            color = Color(0xFFE0E0E0),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp
                                        )
                                        TerminalCursor()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        )

        Spacer(modifier = Modifier.height(10.dp))
    }
}

@Composable
private fun TerminalCursor() {
    Box(
        modifier = Modifier
            .width(2.dp)
            .height(16.dp)
            .background(Color(0xFFB8C0D0))
    )
}
