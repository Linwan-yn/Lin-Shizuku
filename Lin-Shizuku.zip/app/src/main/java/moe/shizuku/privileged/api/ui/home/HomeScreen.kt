package moe.shizuku.privileged.api.ui.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.SettingsEthernet
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import moe.shizuku.privileged.api.ui.widget.CodeBlock
import moe.shizuku.privileged.api.ui.widget.GlassCard
import moe.shizuku.privileged.api.ui.widget.IconContainer
import moe.shizuku.privileged.api.ui.widget.OutputDialog
import moe.shizuku.privileged.api.ui.widget.StatusDot
import rikka.shizuku.Shizuku

@Composable
fun HomeScreen(
    onManageApps: () -> Unit,
    onPair: () -> Unit,
    onGuide: () -> Unit = {},
    onStartWireless: () -> Unit = {}
) {
    val ctx = LocalContext.current.applicationContext
    val vm: HomeViewModel = viewModel()
    val state by vm.state.collectAsState()

    // Stellar 直连启动命令：直接执行 APK native 库中的 libstellar.so
    val stellarSo = remember {
        try {
            java.io.File(ctx.applicationInfo.nativeLibraryDir, "libstellar.so").absolutePath
        } catch (_: Throwable) { "/sdcard/start.sh" }
    }

    var showStopConfirm by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    // Refresh on binder events (service started / died), same as official HomeActivity.
    DisposableEffect(Unit) {
        val received = Shizuku.OnBinderReceivedListener {
            vm.refresh(ctx, includeCount = true)
        }
        val dead = Shizuku.OnBinderDeadListener {
            vm.refresh(ctx, includeCount = true)
        }
        Shizuku.addBinderReceivedListenerSticky(received)
        Shizuku.addBinderDeadListener(dead)
        onDispose {
            Shizuku.removeBinderReceivedListener(received)
            Shizuku.removeBinderDeadListener(dead)
        }
    }

    // Initial load + light polling fallback while the screen is visible.
    LaunchedEffect(Unit) {
        vm.refresh(ctx, includeCount = true)
        while (true) {
            delay(3000)
            vm.refresh(ctx, includeCount = false)
        }
    }

    val running = state.isRunning

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp)
            .padding(top = 16.dp, bottom = 72.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Lin-Shizuku",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(20.dp))

        // Status card (real binder state)
        GlassCard {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(
                        active = running,
                        size = 14.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Crossfade(
                        targetState = running,
                        animationSpec = tween(durationMillis = 300),
                        label = "statusText"
                    ) { isRunning ->
                        Text(
                            text = if (isRunning) "正在运行" else "未运行",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    AnimatedVisibility(
                        visible = running,
                        enter = fadeIn(tween(220)) + scaleIn(initialScale = 0.9f, animationSpec = tween(220)),
                        exit = fadeOut(tween(160)) + scaleOut(targetScale = 0.9f, animationSpec = tween(160))
                    ) {
                        OutlinedButton(
                            onClick = { showStopConfirm = true },
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFFE53935)
                            )
                        ) {
                            Icon(Icons.Filled.Stop, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("停止", fontSize = 12.sp)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("服务版本", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                    Text(
                        if (running && state.serverVersion > 0) "API 1.0.0" else "—",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("运行身份", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                    Text(
                        state.identityText,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp
                    )
                }
                val seContext = state.seContext
                if (running && seContext != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SELinux", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                        Text(
                            seContext,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Authorized apps entry (real count)
        GlassCard(
            onClick = onManageApps
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconContainer(
                    icon = Icons.Filled.Security,
                    size = 48.dp,
                    iconSize = 26.dp
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("应用授权管理", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "点击以管理 Shizuku 生态应用",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        "已授权",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${state.authorizedCount} 个应用",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Wireless debugging startup
        StartupCard(
            icon = Icons.Filled.Sensors,
            title = "通过无线调试启动",
            subtitle = "免 Root · Android 11+",
            description = "在 Android 11 或更高版本上，您可以直接从您的设备启用无线调试并启动 Shizuku，无需连接到计算机。点击「配对」开启无线调试并完成配对，配对成功后点击「启动」。"
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { showGuide = true },
                    modifier = Modifier.weight(1.4f)
                ) { Text("分步骤指南", fontSize = 12.sp) }
                Button(
                    onClick = { onPair() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) { Text("配对", fontSize = 12.sp) }
                OutlinedButton(
                    onClick = { onStartWireless() },
                    modifier = Modifier.weight(1f),
                    enabled = !state.starting
                ) {
                    Text("启动", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // ADB via PC
        StartupCard(
            icon = Icons.Filled.SettingsEthernet,
            title = "通过连接电脑启动（使用 adb）",
            subtitle = "无 Root 设备",
            description = "对于没有 root 的设备需要借助 adb 来启动 Shizuku（需要连接电脑）。这个过程每次设备重新启动后需要重新进行。请阅读帮助。",
            command = "adb shell $stellarSo"
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Local shell
        StartupCard(
            icon = Icons.Filled.Terminal,
            title = "通过本地 shell 启动",
            subtitle = "终端 App",
            description = "直接执行 APK 内的 libstellar.so 启动 Shizuku 服务。注意：必须使用 root 或 adb（uid 2000）身份执行，普通终端模拟器（应用身份）会因权限不足失败，建议优先使用无线调试。",
            command = stellarSo
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Root startup (real su detection + real start)
        StartupCard(
            icon = Icons.Filled.VpnKey,
            title = "启动（针对已 root 设备）",
            subtitle = if (state.rootAvailable) "已检测到 su" else "未检测到 su",
            description = buildString {
                append("另外，Shizuku 可以在开机时自动启动。如果没有，请检查您的系统或是第三方工具是否限制了 Shizuku。")
                if (running && state.serverUid == 0) {
                    append(" 您正在以 root 身份运行；如果使用 Magisk，可以尝试 Sui。")
                }
            }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = { vm.startRoot(ctx) },
                    modifier = Modifier.width(140.dp),
                    enabled = !state.starting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        when {
                            state.starting && state.startMode == StartMode.ROOT -> "启动中..."
                            running && state.serverUid == 0 -> "重启"
                            else -> "启动"
                        },
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

    }

    // Startup output dialog (real output streamed from the startup flow)
    if (state.dialogVisible) {
        OutputDialog(
            title = when (state.startMode) {
                StartMode.ROOT -> "Root 启动"
                StartMode.WADB -> "无线调试启动"
                else -> "启动服务"
            },
            output = state.output,
            loading = state.starting,
            loadingText = when (state.startMode) {
                StartMode.ROOT -> "正在通过 su 启动 Shizuku..."
                StartMode.WADB -> "正在通过无线调试启动..."
                else -> "正在启动..."
            },
            onDismiss = { vm.dismissDialog() }
        )
    }

    // Wireless debugging step-by-step guide (built-in, no external web)
    if (showGuide) {
        AlertDialog(
            onDismissRequest = { showGuide = false },
            title = { Text("无线调试启动") },
            text = {
                Column {
                    GuideStep(1, "开启无线调试", "进入「设置 → 开发者选项」，打开「无线调试」开关。若未开启开发者选项，先在「关于手机」中连续点击「版本号」7 次。")
                    GuideStep(2, "回到本 App 点「配对」", "点击首页「通过无线调试启动」卡片中的「配对」按钮，App 会请求系统开启无线调试。")
                    GuideStep(3, "输入配对码", "在系统弹出的配对窗口中，输入设备「无线调试」页面里「使用配对码配对设备」显示的 6 位配对码，然后点击「允许」。")
                    GuideStep(4, "点「启动」", "配对成功后回到首页，点击「启动」按钮，Shizuku 服务开始运行，页面显示「正在运行」。")
                    GuideStep(5, "重启后重新启动", "设备每次重启后 Shizuku 服务都会停止，重复第 2、4 步即可（配对信息会保留）。")
                }
            },
            confirmButton = {
                TextButton(onClick = { showGuide = false }) { Text("知道了") }
            }
        )
    }

    // Stop confirmation, same as official dialog_stop_message
    if (showStopConfirm) {
        AlertDialog(
            onDismissRequest = { showStopConfirm = false },
            title = { Text("停止服务") },
            text = { Text("确定要停止 Shizuku 服务吗？此操作会断开所有已授权应用的 Shizuku 连接。") },
            confirmButton = {
                TextButton(onClick = {
                    showStopConfirm = false
                    vm.stop(ctx)
                }) { Text("停止") }
            },
            dismissButton = {
                TextButton(onClick = { showStopConfirm = false }) { Text("取消") }
            }
        )
    }
}

@Composable
private fun GuideStep(number: Int, title: String, description: String) {
    Row(modifier = Modifier.padding(vertical = 6.dp)) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(RoundedCornerShape(11.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(
                number.toString(),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                description,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun StartupCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    description: String,
    command: String? = null,
    actions: @Composable (() -> Unit)? = null
) {
    GlassCard {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconContainer(
                    icon = icon,
                    size = 40.dp,
                    iconSize = 22.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(
                        subtitle,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                description,
                fontSize = 13.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 19.sp
            )
            if (command != null) {
                Spacer(modifier = Modifier.height(12.dp))
                CodeBlock(code = command)
            }
            if (actions != null) {
                Spacer(modifier = Modifier.height(12.dp))
                actions()
            }
        }
    }
}
