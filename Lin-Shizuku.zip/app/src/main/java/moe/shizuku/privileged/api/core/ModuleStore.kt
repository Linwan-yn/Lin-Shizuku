package moe.shizuku.privileged.api.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/** 脚本条目（真实数据，来自 <MODULE_ROOT>/<id>/run.sh）。 */
data class ScriptItem(
    val id: String,
    val name: String,
    val author: String = "",
    val brand: String = "",
    val description: String = "",
    val isToggle: Boolean = false,
    val enabled: Boolean = false
)

/** Lin 模块条目（真实数据，来自 <MODULE_ROOT>/<id>/module.json）。 */
data class LinModuleItem(
    val id: String,
    val name: String,
    val description: String = "",
    val version: String = "",
    val author: String = "",
    val enabled: Boolean = false,
    val webui: String = "",
    val hasAction: Boolean = false,
    val sizeLabel: String = "—"
)

/**
 * 模块页真实数据层：统一管理 Shell 脚本与 Lin 模块。
 *
 * 存储目录：/data/local/tmp/Lin-Shizuku/module/<id>/（Shizuku shell 天然可读写，
 * 脚本可被 `sh run.sh` 直接执行）。目录结构：
 *   - run.sh       脚本或模块动作脚本（可含 #--- 元数据块；含 #on/#off 为开关型）
 *   - module.json  Lin 模块元数据（id/name/version/author/description/webui/action）
 *   - webroot/     Lin 模块 WebUI 静态资源（可选）
 *
 * 所有文件操作均通过 Shizuku shell 完成（app 进程无法直接访问 /data/local/tmp）。
 */
object ModuleStore {

    const val MODULE_ROOT = "/data/local/tmp/Lin-Shizuku/module"

    /** 仅供路径表示（app 不可直接 File 读写该目录）。 */
    fun moduleDir(ctx: Context): File = File(MODULE_ROOT)

    private fun sh(cmd: String): String = runBlocking { ShizukuManager.runCommand(cmd) }

    private fun shOk(cmd: String): Boolean = sh(cmd).trim() == "1"

    // ---------- 开关状态持久化 ----------
    private const val PREFS = "module_states"

    fun isEnabled(ctx: Context, id: String): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(id, false)

    fun setEnabled(ctx: Context, id: String, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(id, on).apply()
    }

    fun clearEnabled(ctx: Context, id: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(id).apply()
    }

    // ---------- 元数据解析（字符串版，对齐 ScriptType 的 File 版） ----------
    private fun parseMetadataText(content: String): Map<String, String> {
        val meta = mutableMapOf<String, String>()
        var inMeta = false
        for (line in content.lines()) {
            val t = line.trim()
            if (t == "#---") {
                if (inMeta) break
                inMeta = true
                continue
            }
            if (inMeta && t.startsWith("#")) {
                val c = t.removePrefix("#").trim()
                val idx = c.indexOf(':')
                if (idx > 0) {
                    meta[c.substring(0, idx).trim()] = c.substring(idx + 1).trim()
                }
            }
        }
        return meta
    }

    private fun isToggleText(content: String): Boolean {
        val lines = content.lines()
        return lines.any { it.trim().equals("#on", ignoreCase = true) } &&
            lines.any { it.trim().equals("#off", ignoreCase = true) }
    }

    /** 提取 #on / #off 块。 */
    fun extractBlockText(content: String, on: Boolean): String {
        val lines = content.lines()
        val block = StringBuilder()
        var inBlock = false
        val marker = if (on) "#on" else "#off"
        val other = if (on) "#off" else "#on"
        for (line in lines) {
            val t = line.trim()
            if (t.equals(marker, ignoreCase = true)) { inBlock = true; continue }
            if (inBlock && t.equals(other, ignoreCase = true)) break
            if (inBlock) block.appendLine(line)
        }
        return if (block.isBlank()) content else block.toString()
    }

    // ---------- Shell 脚本 ----------
    fun listScripts(ctx: Context): List<ScriptItem> {
        val out = sh("ls -d $MODULE_ROOT/*/ 2>/dev/null")
        return out.lines()
            .map { it.trim().removeSuffix("/") }
            .filter { it.startsWith("$MODULE_ROOT/") && it.length > MODULE_ROOT.length + 1 }
            .mapNotNull { d ->
                val id = d.substringAfterLast('/')
                if (!shOk("test -f '$d/run.sh' && echo 1")) return@mapNotNull null
                // 含 module.json 的是 Lin 模块，不混入脚本列表
                if (shOk("test -f '$d/module.json' && echo 1")) return@mapNotNull null
                val content = sh("cat '$d/run.sh' 2>/dev/null")
                if (content.isBlank()) return@mapNotNull null
                val meta = parseMetadataText(content)
                ScriptItem(
                    id = id,
                    name = meta["name"] ?: id,
                    author = meta["author"] ?: "",
                    brand = meta["brand"] ?: "",
                    description = meta["description"] ?: "",
                    isToggle = isToggleText(content),
                    enabled = isEnabled(ctx, id)
                )
            }
            .sortedBy { it.name.lowercase() }
    }

    fun deleteScript(ctx: Context, id: String) {
        sh("rm -rf '$MODULE_ROOT/$id'")
        clearEnabled(ctx, id)
    }

    /**
     * 从文件选择器导入 .sh 脚本：读取文件内容 → 写入 <MODULE_ROOT>/<id>/run.sh。
     * 目录名取自文件名（去 .sh 后缀，非法字符转下划线）。返回 null=成功，否则错误信息。
     */
    fun importScript(ctx: Context, uri: Uri): String? {
        val displayName = try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && !c.isNull(idx)) c.getString(idx) else null
            }
        } catch (_: Throwable) { null } ?: "script.sh"
        val id = displayName
            .removeSuffix(".sh").removeSuffix(".SH")
            .replace(Regex("[^A-Za-z0-9_.-]"), "_")
            .trim('_')
            .ifBlank { "script" }
        // 同名已存在时不覆盖：自动追加序号改名（如 系统信息(1)、系统信息(2)...）
        var finalId = id
        var n = 1
        while (shOk("test -f '$MODULE_ROOT/$finalId/run.sh' && echo 1")) {
            n++
            finalId = "$id($n)"
        }
        val bytes = try {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Throwable) { null }
            ?: return "读取文件失败"
        if (bytes.isEmpty()) return "文件内容为空"
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val r = sh(
            "mkdir -p '$MODULE_ROOT/$finalId' && " +
                "echo '$b64' | base64 -d > '$MODULE_ROOT/$finalId/run.sh' && " +
                "chmod 755 '$MODULE_ROOT/$finalId/run.sh' && echo IMPORT_DONE"
        )
        if (!r.contains("IMPORT_DONE")) {
            return "写入失败: ${r.takeLast(200)}"
        }
        return if (finalId != id) "脚本已导入（同名已存在，已保存为 $finalId）" else null
    }

    /** 脚本 on/off 块内容（开关型脚本）。 */
    fun toggleBlock(ctx: Context, id: String, on: Boolean): String {
        val content = sh("cat '$MODULE_ROOT/$id/run.sh' 2>/dev/null")
        return if (content.isBlank()) "" else extractBlockText(content, on)
    }

    /** 读取脚本 run.sh 内容（shell cat，支持 /data/local/tmp 路径）。 */
    fun scriptContent(ctx: Context, id: String): String =
        sh("cat '$MODULE_ROOT/$id/run.sh' 2>/dev/null")

    /**
     * 保存脚本 run.sh（新建或编辑）。自动维护 #name 元数据。
     * 返回 null=成功，否则错误信息。
     */
    fun saveScript(ctx: Context, id: String, name: String, content: String): String? {
        val final = if (content.contains("#name:")) {
            content.replace(Regex("#name:.*"), "#name: $name")
        } else {
            "#---\n#name: $name\n#---\n\n$content"
        }
        val b64 = Base64.encodeToString(final.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        val r = sh(
            "mkdir -p '$MODULE_ROOT/$id' && " +
                "echo '$b64' | base64 -d > '$MODULE_ROOT/$id/run.sh' && " +
                "chmod 755 '$MODULE_ROOT/$id/run.sh' && echo SAVE_DONE"
        )
        return if (r.contains("SAVE_DONE")) null else "保存失败: ${r.takeLast(200)}"
    }

    /**
     * 停止模块：开关关闭时调用，真正清理模块的后台进程、不允许其继续运行。
     * 优先执行模块自带的 stop.sh（模块可精确停止调度器、清理 pid/标志文件）；
     * 无 stop.sh 时用 pkill 兜底，杀掉命令行引用本模块目录的所有后台进程。
     */
    fun stopModule(ctx: Context, id: String): String {
        return try {
            if (shOk("test -f '$MODULE_ROOT/$id/stop.sh' && echo 1")) {
                sh("sh '$MODULE_ROOT/$id/stop.sh' 2>&1")
            } else {
                // [X] 拆分避免 pkill 匹配到自身命令行
                val pat = "$MODULE_ROOT/[${id.firstOrNull() ?: 'x'}]${id.drop(1)}"
                sh("pkill -f '$pat' 2>/dev/null; echo \"已停止模块进程\"")
            }
        } catch (e: Throwable) {
            "停止模块失败: ${e.message}"
        }
    }

    // ---------- Lin 模块 ----------
    fun listModules(ctx: Context): List<LinModuleItem> {
        val out = sh("ls -d $MODULE_ROOT/*/ 2>/dev/null")
        return out.lines()
            .map { it.trim().removeSuffix("/") }
            .filter { it.startsWith("$MODULE_ROOT/") && it.length > MODULE_ROOT.length + 1 }
            .mapNotNull { d ->
                val id = d.substringAfterLast('/')
                if (!shOk("test -f '$d/module.json' && echo 1")) return@mapNotNull null
                val json = try {
                    JSONObject(sh("cat '$d/module.json' 2>/dev/null"))
                } catch (_: Throwable) { return@mapNotNull null }
                LinModuleItem(
                    id = json.optString("id", id),
                    name = json.optString("name", id),
                    description = json.optString("description", ""),
                    version = json.optString("version", ""),
                    author = json.optString("author", ""),
                    enabled = isEnabled(ctx, id),
                    webui = json.optString("webui", ""),
                    hasAction = json.optBoolean("action", false),
                    sizeLabel = formatSize(dirSizeKb(d))
                )
            }
            .sortedBy { it.name.lowercase() }
    }

    fun deleteModule(ctx: Context, id: String) {
        sh("rm -rf '$MODULE_ROOT/$id'")
        clearEnabled(ctx, id)
    }

    /** 模块 action 脚本内容。 */
    fun moduleActionScript(ctx: Context, id: String): String {
        return sh("cat '$MODULE_ROOT/$id/run.sh' 2>/dev/null")
    }

    /**
     * 解析模块 WebUI 地址：
     * http(s):// 直接返回；本地路径（如 webroot/index.html）通过 shell 同步到
     * app 缓存目录（WebView 只能读 app 私有文件），返回 file:// 绝对路径。
     */
    fun webuiUrl(ctx: Context, module: LinModuleItem): String {
        val raw = module.webui
        if (raw.isBlank()) return ""
        if (raw.startsWith("http://") || raw.startsWith("https://")) return raw
        val dirName = raw.substringBeforeLast('/').ifBlank { "." }
        val out = sh(
            "cd '$MODULE_ROOT/${module.id}' 2>/dev/null && " +
                "find '$dirName' -type f 2>/dev/null | while read f; do " +
                "echo \"\$f|\$(base64 -w0 < \"\$f\" 2>/dev/null)\"; done"
        )
        if (out.isBlank()) return raw
        val dest = File(ctx.cacheDir, "webui_${module.id}")
        dest.deleteRecursively()
        dest.mkdirs()
        for (line in out.lines()) {
            if (line.isBlank()) continue
            val idx = line.indexOf('|')
            if (idx <= 0) continue
            val rel = line.substring(0, idx)
            val b64 = line.substring(idx + 1)
            try {
                val f = File(dest, rel)
                f.parentFile?.mkdirs()
                f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
            } catch (_: Throwable) {}
        }
        return File(dest, raw).toURI().toString()
    }

    /**
     * 从 zip（.lin / .zip）安装 Lin 模块。
     * 要求包内包含 module.json（含合法 id）。返回 null=成功，否则错误信息。
     * 安装流程：app 解压到缓存 → 逐文件 base64 通过 shell 写入目标目录 → chmod。
     */
    fun installModule(ctx: Context, uri: Uri): String? {
        val tmp = File(ctx.cacheDir, "mod_install_${System.currentTimeMillis()}")
        try {
            tmp.mkdirs()
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val outFile = File(tmp, entry.name)
                            outFile.parentFile?.mkdirs()
                            outFile.outputStream().use { out -> zis.copyTo(out) }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            val metaFile = listOf(
                File(tmp, "module.json"),
                File(tmp, "module/module.json")
            ).firstOrNull { it.exists() } ?: return "模块包中未找到 module.json"
            val json = try {
                JSONObject(metaFile.readText())
            } catch (_: Throwable) { return "module.json 解析失败" }
            val id = json.optString("id", "").trim()
            if (id.isBlank() || !id.matches(Regex("[A-Za-z0-9_.-]+"))) {
                return "module.json 缺少合法 id"
            }
            val contentRoot = if (metaFile.parentFile.name == "module") metaFile.parentFile else tmp

            // 安装：目录一次建好，文件分批 base64 写入（避免单条 shell 命令参数过长 E2BIG）
            val mkdirs = StringBuilder("rm -rf '$MODULE_ROOT/$id'; mkdir -p '$MODULE_ROOT/$id'\n")
            contentRoot.walkTopDown().forEach { f ->
                if (f.isDirectory) {
                    mkdirs.append("mkdir -p '$MODULE_ROOT/$id/${f.relativeTo(contentRoot).path}'\n")
                }
            }
            if (!runInstallBatch(sh(mkdirs.toString()))) return "安装失败: shell 执行异常"

            val files = contentRoot.walkTopDown().filter { it.isFile }.toList()
            val batch = StringBuilder()
            for (f in files) {
                val rel = f.relativeTo(contentRoot).path
                val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                val line = "echo '$b64' | base64 -d > '$MODULE_ROOT/$id/$rel'\n"
                if (batch.length + line.length > 30_000 && batch.isNotEmpty()) {
                    if (!runInstallBatch(sh(batch.toString()))) return "安装失败: shell 执行异常"
                    batch.setLength(0)
                }
                batch.append(line)
            }
            if (batch.isNotEmpty() && !runInstallBatch(sh(batch.toString()))) {
                return "安装失败: shell 执行异常"
            }

            val chmodResult = sh(
                "chmod -R 755 '$MODULE_ROOT/$id'; " +
                    "find '$MODULE_ROOT/$id' -type f ! -name '*.sh' -exec chmod 644 {} \\; ; " +
                    "echo INSTALL_DONE"
            )
            if (!chmodResult.contains("INSTALL_DONE")) {
                return "安装失败: shell 执行异常\n${chmodResult.takeLast(300)}"
            }
            return null
        } catch (e: Throwable) {
            return "安装失败: ${e.message}"
        } finally {
            tmp.deleteRecursively()
        }
    }

    /** 检查单批 shell 输出是否异常（失败时 runCommand 返回 "Error: ..."）。 */
    private fun runInstallBatch(out: String): Boolean {
        return !out.startsWith("Error:")
    }

    private fun dirSizeKb(path: String): Long {
        val out = sh("du -sk '$path' 2>/dev/null").trim()
        return out.substringBefore('\t').toLongOrNull() ?: 0L
    }

    private fun formatSize(kb: Long): String = when {
        kb >= 1024 -> "%.1f MB".format(kb / 1024.0)
        kb >= 1 -> "$kb KB"
        else -> "—"
    }
}
