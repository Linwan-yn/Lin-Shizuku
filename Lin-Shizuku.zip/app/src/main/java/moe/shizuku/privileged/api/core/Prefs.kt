package moe.shizuku.privileged.api.core

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE = "lin_shizuku_prefs"
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }

    var dynamicColor: Boolean
        get() = sp.getBoolean("dynamic_color", false)
        set(v) = sp.edit().putBoolean("dynamic_color", v).apply()

    var amoled: Boolean
        get() = sp.getBoolean("amoled", false)
        set(v) = sp.edit().putBoolean("amoled", v).apply()

    var darkMode: Boolean
        get() = sp.getBoolean("night", false)
        set(v) = sp.edit().putBoolean("night", v).apply()

    var hideRecents: Boolean
        get() = sp.getBoolean("hide_bg", false)
        set(v) = sp.edit().putBoolean("hide_bg", v).apply()

    var glassEnabled: Boolean
        get() = sp.getBoolean("glass", true)
        set(v) = sp.edit().putBoolean("glass", v).apply()

    var startOnBoot: Boolean
        get() = sp.getBoolean("start_boot", false)
        set(v) = sp.edit().putBoolean("start_boot", v).apply()

    var highRefresh: Boolean
        get() = sp.getBoolean("high_refresh", false)
        set(v) = sp.edit().putBoolean("high_refresh", v).apply()

    var bootStart: Boolean
        get() = startOnBoot
        set(v) { startOnBoot = v }

    var liquidGlass: Boolean
        get() = glassEnabled
        set(v) { glassEnabled = v }

    var wlanAutoStart: Boolean
        get() = sp.getBoolean("wlan_auto", false)
        set(v) = sp.edit().putBoolean("wlan_auto", v).apply()

    var darkModeOption: String
        get() = sp.getString("dark_option", "跟随系统") ?: "跟随系统"
        set(v) = sp.edit().putString("dark_option", v).apply()

    /** TCP 模式：无线调试启动成功后把 adbd 切换到固定 TCP 端口（thedjchi 特性），
     *  之后无需 WiFi / 无线调试也可通过 127.0.0.1 重启服务。 */
    var tcpMode: Boolean
        get() = sp.getBoolean("tcp_mode", true)
        set(v) = sp.edit().putBoolean("tcp_mode", v).apply()

    /** TCP 模式固定端口（adb tcpip）。 */
    var tcpPort: Int
        get() = sp.getInt("tcp_port", 5555)
        set(v) = sp.edit().putInt("tcp_port", v).apply()

    /** 崩溃自动恢复（watchdog）：服务进程异常退出时自动重新启动。 */
    var watchdog: Boolean
        get() = sp.getBoolean("watchdog", true)
        set(v) = sp.edit().putBoolean("watchdog", v).apply()
}
