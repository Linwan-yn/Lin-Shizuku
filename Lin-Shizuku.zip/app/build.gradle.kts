plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("dev.rikka.tools.refine")
}

android {
    namespace = "moe.shizuku.privileged.api"
    compileSdk = 37

    defaultConfig {
        applicationId = "moe.shizuku.privileged.api"
        minSdk = 24
        targetSdk = 37
        versionCode = 3000
        versionName = "1.0.0-lin-Release"
        // 体积优化：仅保留 64 位 ABI（现代设备均为 arm64），只保留简体中文资源
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
        resourceConfigurations += listOf("zh-rCN")
    }

    signingConfigs {
        create("release") {
            storeFile = file("../release.keystore")
            storePassword = "deepmod2026"
            keyAlias = "shizuku-deepmod"
            keyPassword = "deepmod2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        aidl = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            // 排除 BouncyCastle 后量子密码学静态数据（本应用不需要，节省约 1MB）
            excludes += listOf(
                "org/bouncycastle/pqc/**",
                "META-INF/**/versions/**",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*"
            )
        }
    }
    sourceSets {
        getByName("main") {
            jniLibs.srcDirs("src/main/jniLibs")
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.02.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.navigation:navigation-compose:2.7.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("io.coil-kt:coil-compose:2.5.0")
    implementation("androidx.webkit:webkit:1.10.0")
    // Stellar server 合并依赖（与 Stellar 官方构建一致；shizuku-server.jar 已整体移除，
    // 因其内置的 hidden compat / parcelablelist 为旧版，运行时会让 Stellar server NoSuchMethodError 崩溃）
    compileOnly("dev.rikka.hidden:stub:4.4.0")
    implementation("dev.rikka.hidden:compat:4.4.0")
    implementation("dev.rikka.tools.refine:runtime:4.4.0")
    implementation("dev.rikka.rikkax.parcelablelist:parcelablelist:2.0.1")
    implementation("com.google.code.gson:gson:2.13.1")
    implementation("androidx.annotation:annotation:1.9.1")
    // 约束：hidden compat 传递依赖会拉高 androidx.core，回退到与 AGP 8.2 兼容的版本
    configurations.all {
        resolutionStrategy {
            force("androidx.core:core:1.12.0")
            force("androidx.core:core-ktx:1.12.0")
        }
    }
    implementation("org.bouncycastle:bcpkix-jdk15to18:1.77")
    implementation("org.conscrypt:conscrypt-android:2.5.2")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
