# ---------- 基础 ----------
# Keep native methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# ---------- 本应用（R8 不裁剪，保证全部功能/反射/JS桥稳定） ----------
-keep class moe.shizuku.privileged.api.** { *; }
-keep class moe.shizuku.manager.** { *; }

# ---------- 合入的 Stellar 服务端（自己就是服务端，全部保留） ----------
-keep class roro.stellar.** { *; }
-keep class com.stellar.** { *; }

# ---------- rikka 基础设施（rish/sui/shizuku JNI + refine 运行时） ----------
-keep class rikka.** { *; }
-keep class dev.rikka.** { *; }

# ---------- 反射/动态调用安全 ----------
# WebView JS 桥（ksu 兼容）方法经反射调用
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
# refine 注解生成的 Ref 类
-keepclassmembers class * {
    @dev.rikka.tools.refine.annotation.RefineAs *;
}

# ---------- 依赖库 ----------
# Keep Compose
-dontwarn androidx.compose.**
# BouncyCastle（加解密/证书）
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
# Gson（Stellar 权限配置 JSON 序列化，保留字段）
-keep class com.google.gson.** { *; }
-dontwarn com.google.gson.**
# OkHttp / WebSocket
-dontwarn okhttp3.**
-dontwarn okio.**
# RikkaX ParcelableList
-dontwarn dev.rikka.rikkax.parcelablelist.**
# androidx.webkit
-dontwarn androidx.webkit.**
# conscrypt
-dontwarn org.conscrypt.**
