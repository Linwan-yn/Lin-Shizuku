#---
#name: 系统信息
#description: 输出设备、系统与内存信息
#author: Lin
#brand: 通用
#---
echo "===== 设备信息 ====="
echo "品牌: $(getprop ro.product.brand)"
echo "型号: $(getprop ro.product.model)"
echo ""
echo "===== 系统版本 ====="
echo "Android: $(getprop ro.build.version.release)"
echo "SDK: $(getprop ro.build.version.sdk)"
echo ""
echo "===== 内存信息 ====="
head -n 3 /proc/meminfo
echo ""
echo "执行完成"
