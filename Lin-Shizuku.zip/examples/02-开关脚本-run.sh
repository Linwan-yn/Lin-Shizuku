#---
#name: 飞行模式开关
#description: 演示开关型脚本，开启/关闭飞行模式
#author: Lin
#brand: 通用
#---
#on
echo "正在开启飞行模式..."
cmd connectivity airplane-mode enable
sleep 1
echo "飞行模式状态: $(settings get global airplane_mode_on)"
#off
echo "正在关闭飞行模式..."
cmd connectivity airplane-mode disable
sleep 1
echo "飞行模式状态: $(settings get global airplane_mode_on)"
