#---
#name: 示例 Web 模块
#description: action 输出系统信息；开关演示 on/off 块
#author: Lin
#brand: 通用
#---
echo "===== 示例模块 action 执行 ====="
echo "设备: $(getprop ro.product.brand) $(getprop ro.product.model)"
echo "Android: $(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk))"
echo "时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo ""
echo "WebUI 入口: web/index.html（点击模块卡 WEBUI 按钮打开）"
echo "开关演示: 切换模块开关执行下方 #on/#off 块"
#on
echo "模块已开启"
#off
echo "模块已关闭"
