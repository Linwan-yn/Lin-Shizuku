#---
#name: 网络增强
#description: 5G假满格自动降级4G | 游戏模式锁定LTE | 代理稳定模式 | 双卡运营商识别
#author: 寒碑听风
#brand: 通用
#---
# Lin 模块入口：切换至模块目录后执行 action.sh 菜单。
# 无参数时输出状态检测与操作菜单说明；带数字参数直接执行对应操作，
# 例如：sh run.sh 2（游戏模式）、sh run.sh 9（启用阿里 DNS）、sh run.sh 19（启动调度器）。
BASE="/data/local/tmp/Lin-Shizuku/module/Network_Enhance"
if [ ! -f "$BASE/scripts/common.sh" ]; then
  BASE="$(pwd)"
  [ -f "$BASE/scripts/common.sh" ] || BASE=""
fi
[ -z "$BASE" ] && { echo "模块目录不可达"; exit 1; }
cd "$BASE" 2>/dev/null || { echo "模块目录不可达: $BASE"; exit 1; }
exec sh action.sh "$@"
