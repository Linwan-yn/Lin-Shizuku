# 网络增强模块停止脚本：Lin-Shizuku 开关关闭时自动调用
# 精确停止调度器 + 清理运行时文件 + 兜底清理后台进程
cd /data/local/tmp/Lin-Shizuku/module/Network_Enhance 2>/dev/null || exit 1

# 停止智能调度器（精确：kill + 清理 pid/state 文件）
sh scripts/monitor.sh stop 2>/dev/null

# 停止 DNS 预热进程
if [ -f /data/local/tmp/network_enhance_dns_prefetch.pid ]; then
  PID=$(cat /data/local/tmp/network_enhance_dns_prefetch.pid 2>/dev/null)
  [ -n "$PID" ] && kill "$PID" 2>/dev/null
  rm -f /data/local/tmp/network_enhance_dns_prefetch.pid
fi

# 清理弱网自救互锁标志
rm -f /data/local/tmp/network_enhance_weaknet_active

# 兜底：清理引用本模块目录的后台进程（[N] 拆分避免匹配到自身命令行）
PAT="/data/local/tmp/Lin-Shizuku/module/[N]etwork_Enhance"
pkill -f "$PAT" 2>/dev/null

echo "模块已停止"
